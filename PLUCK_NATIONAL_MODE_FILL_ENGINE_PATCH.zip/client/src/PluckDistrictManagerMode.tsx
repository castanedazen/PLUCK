import React, { useEffect, useMemo, useState } from "react";

type Listing = {
  id: string;
  title: string;
  fruit: string;
  price: number;
  unit?: string;
  image?: string;
  location?: string;
  city?: string;
  state?: string;
  zip?: string;
  inventory?: number;
  sellerId?: string;
  sellerName?: string;
  description?: string;
  pickupWindows?: string[];
  status?: string;
  tags?: string[];
  harvestNote?: string;
  harvestLabel?: string;
  freshnessLabel?: string;
  availabilityLabel?: string;
  sellerVerified?: boolean;
  sellerRating?: number;
  geo?: { lat: number; lng: number } | null;
};

type StoreNeed = {
  id: string;
  name: string;
  city: string;
  region: string;
  lat: number;
  lng: number;
  produce: string;
  needed: number;
};

const shell: React.CSSProperties = {
  minHeight: "100vh",
  fontFamily: "Inter, Arial, sans-serif",
  background: "linear-gradient(180deg, #f7fbff 0%, #edf3f8 100%)",
  color: "#102033",
  padding: 28,
};

const container: React.CSSProperties = {
  maxWidth: 1380,
  margin: "0 auto",
};

const panel: React.CSSProperties = {
  background: "rgba(255,255,255,0.94)",
  border: "1px solid rgba(16,32,51,0.08)",
  borderRadius: 24,
  boxShadow: "0 18px 44px rgba(16,32,51,0.10)",
};

const pill: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  padding: "8px 14px",
  borderRadius: 999,
  background: "rgba(255,255,255,0.92)",
  border: "1px solid rgba(16,32,51,0.08)",
  color: "#102033",
  fontSize: 13,
  fontWeight: 800,
};

function n(v: number) {
  return new Intl.NumberFormat("en-US").format(Math.round(v));
}

function money(v: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(v);
}

function regionForListing(item: Listing) {
  const state = (item.state || "").toUpperCase();
  if (["CA", "OR", "WA", "NV", "AZ"].includes(state)) return "West";
  if (["TX", "OK", "NM", "CO", "UT"].includes(state)) return "Southwest";
  if (["FL", "GA", "NC", "SC", "TN"].includes(state)) return "Southeast";
  if (["IL", "OH", "MI", "MN", "WI", "MO"].includes(state)) return "Midwest";
  if (["NY", "NJ", "PA", "MA", "CT", "MD", "VA"].includes(state)) return "Northeast";
  if (state) return state;
  return "Unassigned";
}

function centroidLabel(region: string) {
  const map: Record<string, { left: string; top: string }> = {
    West: { left: "14%", top: "46%" },
    Southwest: { left: "29%", top: "58%" },
    Midwest: { left: "53%", top: "43%" },
    Southeast: { left: "73%", top: "62%" },
    Northeast: { left: "80%", top: "32%" },
    Unassigned: { left: "50%", top: "75%" },
  };
  return map[region] || { left: "50%", top: "50%" };
}

function distanceMiles(aLat: number, aLng: number, bLat: number, bLng: number) {
  const rad = Math.PI / 180;
  const dLat = (bLat - aLat) * rad;
  const dLng = (bLng - aLng) * rad;
  const lat1 = aLat * rad;
  const lat2 = bLat * rad;
  const sin1 = Math.sin(dLat / 2);
  const sin2 = Math.sin(dLng / 2);
  const aa = sin1 * sin1 + Math.cos(lat1) * Math.cos(lat2) * sin2 * sin2;
  const c = 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa));
  return 3959 * c;
}

function produceFromListing(item: Listing) {
  return (item.fruit || "Produce").trim();
}

function buildStoreNeeds(regions: string[]): StoreNeed[] {
  const seed: StoreNeed[] = [
    { id: "s1", name: "Store 1423", city: "Los Angeles", region: "West", lat: 34.05, lng: -118.25, produce: "Avocados", needed: 180 },
    { id: "s2", name: "Store 2204", city: "Phoenix", region: "Southwest", lat: 33.45, lng: -112.07, produce: "Tomatoes", needed: 150 },
    { id: "s3", name: "Store 3310", city: "Chicago", region: "Midwest", lat: 41.88, lng: -87.63, produce: "Lemons", needed: 120 },
    { id: "s4", name: "Store 4418", city: "Atlanta", region: "Southeast", lat: 33.75, lng: -84.39, produce: "Peaches", needed: 130 },
    { id: "s5", name: "Store 5526", city: "Newark", region: "Northeast", lat: 40.73, lng: -74.17, produce: "Apples", needed: 160 },
  ];
  return seed.filter(s => regions.includes(s.region));
}

function StatCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div style={{ ...panel, padding: 22 }}>
      <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: ".08em", color: "#728195", fontWeight: 800 }}>
        {label}
      </div>
      <div style={{ fontSize: 34, fontWeight: 900, marginTop: 10, lineHeight: 1.05 }}>{value}</div>
      <div style={{ fontSize: 14, color: "#556579", marginTop: 8 }}>{sub}</div>
    </div>
  );
}

function ListCard({ title, items }: { title: string; items: { name: string; sub: string; value: string }[] }) {
  return (
    <div style={{ ...panel, padding: 22 }}>
      <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: ".08em", color: "#728195", fontWeight: 800 }}>
        {title}
      </div>
      <div style={{ display: "grid", gap: 12, marginTop: 16 }}>
        {items.map((item) => (
          <div
            key={item.name + item.sub}
            style={{
              borderRadius: 18,
              padding: 16,
              background: "#f8fbff",
              border: "1px solid rgba(16,32,51,0.06)",
              display: "flex",
              justifyContent: "space-between",
              gap: 12,
            }}
          >
            <div>
              <div style={{ fontWeight: 800, fontSize: 16 }}>{item.name}</div>
              <div style={{ color: "#556579", marginTop: 4, fontSize: 14 }}>{item.sub}</div>
            </div>
            <div style={{ fontWeight: 900, whiteSpace: "nowrap", fontSize: 15 }}>{item.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div style={{ ...panel, padding: 28, textAlign: "center", color: "#556579" }}>
      {text}
    </div>
  );
}

export default function PluckDistrictManagerMode() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [mode, setMode] = useState<"district" | "national">("national");
  const [activeRegion, setActiveRegion] = useState("West");

  useEffect(() => {
    fetch("/api/listings")
      .then((r) => r.json())
      .then((data) => setListings(Array.isArray(data) ? data : []))
      .catch(() => setListings([]));
  }, []);

  const liveListings = useMemo(
    () =>
      listings.filter(
        (l) =>
          l &&
          l.status !== "sold" &&
          Number(l.inventory || 0) > 0
      ),
    [listings]
  );

  const withGeo = useMemo(() => liveListings.filter((l) => l.geo && typeof l.geo?.lat === "number" && typeof l.geo?.lng === "number"), [liveListings]);

  const regionGroups = useMemo(() => {
    const map = new Map<string, Listing[]>();
    for (const item of liveListings) {
      const region = regionForListing(item);
      const arr = map.get(region) || [];
      arr.push(item);
      map.set(region, arr);
    }
    return Array.from(map.entries()).sort((a, b) => b[1].length - a[1].length);
  }, [liveListings]);

  useEffect(() => {
    if (!regionGroups.length) return;
    if (!regionGroups.some(([r]) => r === activeRegion)) {
      setActiveRegion(regionGroups[0][0]);
    }
  }, [regionGroups, activeRegion]);

  const activeRegionListings = useMemo(
    () => liveListings.filter((l) => regionForListing(l) === activeRegion),
    [liveListings, activeRegion]
  );

  const regionsForNeeds = useMemo(
    () => (mode === "district" ? [activeRegion] : ["West", "Southwest", "Midwest", "Southeast", "Northeast"]),
    [mode, activeRegion]
  );

  const storeNeeds = useMemo(() => buildStoreNeeds(regionsForNeeds), [regionsForNeeds]);

  const produceTotals = useMemo(() => {
    const map = new Map<string, number>();
    for (const item of liveListings) {
      const produce = produceFromListing(item);
      map.set(produce, (map.get(produce) || 0) + Number(item.inventory || 0));
    }
    return Array.from(map.entries())
      .map(([produce, qty]) => ({ produce, qty }))
      .sort((a, b) => b.qty - a.qty);
  }, [liveListings]);

  const fillPlans = useMemo(() => {
    return storeNeeds.map((store) => {
      const candidates = withGeo
        .filter((l) => produceFromListing(l).toLowerCase() === store.produce.toLowerCase())
        .map((l) => ({
          listing: l,
          distance: distanceMiles(store.lat, store.lng, l.geo!.lat, l.geo!.lng),
          qty: Number(l.inventory || 0),
        }))
        .sort((a, b) => a.distance - b.distance);

      let remaining = store.needed;
      const picks: { name: string; qty: number; distance: number }[] = [];
      for (const c of candidates) {
        if (remaining <= 0) break;
        const take = Math.min(c.qty, remaining);
        if (take > 0) {
          picks.push({
            name: c.listing.sellerName || c.listing.title || "Grower",
            qty: take,
            distance: c.distance,
          });
          remaining -= take;
        }
      }

      const matched = picks.reduce((s, p) => s + p.qty, 0);
      const coverage = store.needed ? Math.round((matched / store.needed) * 100) : 0;
      const avgDistance =
        picks.length > 0 ? picks.reduce((s, p) => s + p.distance, 0) / picks.length : 0;

      return {
        store,
        picks,
        matched,
        coverage,
        avgDistance,
      };
    });
  }, [storeNeeds, withGeo]);

  const bestFill = useMemo(() => {
    if (!fillPlans.length) return null;
    return [...fillPlans].sort((a, b) => {
      if (b.coverage !== a.coverage) return b.coverage - a.coverage;
      return a.avgDistance - b.avgDistance;
    })[0];
  }, [fillPlans]);

  const fillableStores = fillPlans.filter((p) => p.coverage > 0).length;
  const totalCoverage = fillPlans.length
    ? Math.round(fillPlans.reduce((s, p) => s + p.coverage, 0) / fillPlans.length)
    : 0;

  const totalSupply = liveListings.reduce((s, l) => s + Number(l.inventory || 0), 0);
  const avgPrice = liveListings.length
    ? liveListings.reduce((s, l) => s + Number(l.price || 0), 0) / liveListings.length
    : 0;

  const impliedWasteSavings = totalSupply * 1.8;

  return (
    <div style={shell}>
      <div style={container}>
        <section
          style={{
            borderRadius: 34,
            overflow: "hidden",
            padding: 38,
            display: "grid",
            gridTemplateColumns: "1.18fr 0.82fr",
            gap: 24,
            background:
              "linear-gradient(135deg, #1f6d5b 0%, #2e7d6b 18%, #497fa6 48%, #c16b2f 82%, #d5923a 100%)",
            boxShadow: "0 24px 60px rgba(16,32,51,0.18)",
          }}
        >
          <div>
            <div style={{ ...pill, background: "rgba(255,255,255,0.18)", color: "#ffffff", border: "1px solid rgba(255,255,255,0.22)" }}>
              PLUCK · NATIONAL SUPPLY MODE
            </div>

            <div style={{ marginTop: 18, color: "#ffffff", fontSize: 64, lineHeight: 0.94, fontWeight: 900, letterSpacing: "-0.05em", maxWidth: 800 }}>
              National produce intelligence with live local supply underneath.
            </div>

            <div style={{ marginTop: 18, color: "rgba(255,255,255,0.95)", fontSize: 21, lineHeight: 1.35, maxWidth: 760 }}>
              See where supply lives, group listings into U.S. regions, and model the fastest fill paths from distributed grower inventory into store demand.
            </div>

            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 22 }}>
              <button
                onClick={() => setMode("national")}
                style={{ ...pill, background: mode === "national" ? "#ffffff" : "rgba(255,255,255,0.22)", color: mode === "national" ? "#102033" : "#ffffff", border: "1px solid rgba(255,255,255,0.22)", cursor: "pointer" }}
              >
                National view
              </button>
              <button
                onClick={() => setMode("district")}
                style={{ ...pill, background: mode === "district" ? "#ffffff" : "rgba(255,255,255,0.22)", color: mode === "district" ? "#102033" : "#ffffff", border: "1px solid rgba(255,255,255,0.22)", cursor: "pointer" }}
              >
                Region / district view
              </button>
              <span style={{ ...pill }}>{n(liveListings.length)} live listings</span>
              <span style={{ ...pill }}>{n(totalSupply)} units of supply</span>
            </div>

            {regionGroups.length ? (
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 18 }}>
                {regionGroups.map(([region, items]) => (
                  <button
                    key={region}
                    onClick={() => {
                      setActiveRegion(region);
                      setMode("district");
                    }}
                    style={{
                      ...pill,
                      background: activeRegion === region ? "#ffffff" : "rgba(255,255,255,0.18)",
                      color: activeRegion === region ? "#102033" : "#ffffff",
                      border: "1px solid rgba(255,255,255,0.22)",
                      cursor: "pointer",
                    }}
                  >
                    {region} · {items.length}
                  </button>
                ))}
              </div>
            ) : null}
          </div>

          <div style={{ ...panel, padding: 24, alignSelf: "end" }}>
            <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: ".08em", color: "#728195", fontWeight: 800 }}>
              Fill engine
            </div>
            {bestFill ? (
              <>
                <div style={{ marginTop: 10, fontSize: 30, fontWeight: 900, lineHeight: 1.04 }}>
                  {bestFill.store.name} → {bestFill.store.produce}
                </div>
                <div style={{ marginTop: 10, color: "#556579", fontSize: 16, lineHeight: 1.45 }}>
                  Needs {n(bestFill.store.needed)} units. Matched {n(bestFill.matched)} units with {bestFill.coverage}% coverage at {bestFill.avgDistance ? bestFill.avgDistance.toFixed(1) : "0.0"} miles average route distance.
                </div>
                <div style={{ display: "grid", gap: 10, marginTop: 16 }}>
                  {bestFill.picks.length ? bestFill.picks.map((p) => (
                    <div key={p.name + p.qty} style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: 12, borderRadius: 16, background: "#f8fbff", border: "1px solid rgba(16,32,51,0.06)" }}>
                      <div>
                        <div style={{ fontWeight: 800 }}>{p.name}</div>
                        <div style={{ color: "#556579", fontSize: 14 }}>{p.distance.toFixed(1)} miles away</div>
                      </div>
                      <div style={{ fontWeight: 900 }}>{n(p.qty)} units</div>
                    </div>
                  )) : <div style={{ color: "#556579" }}>No live matching supply yet.</div>}
                </div>
              </>
            ) : (
              <div style={{ marginTop: 10, color: "#556579" }}>No fill opportunities yet.</div>
            )}
          </div>
        </section>

        <section
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(5, minmax(0, 1fr))",
            gap: 18,
            marginTop: 22,
          }}
        >
          <StatCard label="Regions Active" value={n(regionGroups.length)} sub="U.S. supply regions with listings" />
          <StatCard label="Live Listings" value={n(liveListings.length)} sub="Active marketplace supply points" />
          <StatCard label="Supply Units" value={n(totalSupply)} sub="Live inventory from listings" />
          <StatCard label="Fillable Stores" value={n(fillableStores)} sub="Store needs with matched supply" />
          <StatCard label="Implied Waste Offset" value={money(impliedWasteSavings)} sub="Illustrative national savings view" />
        </section>

        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.15fr 0.85fr",
            gap: 22,
            marginTop: 22,
          }}
        >
          <div style={{ ...panel, padding: 24 }}>
            <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: ".08em", color: "#728195", fontWeight: 800 }}>
              {mode === "national" ? "National supply map" : "Region supply map"}
            </div>
            <div style={{ fontSize: 34, fontWeight: 900, marginTop: 10, lineHeight: 1.04 }}>
              {mode === "national" ? "United States supply network" : `${activeRegion} supply layer`}
            </div>
            <div style={{ color: "#556579", marginTop: 8, fontSize: 16 }}>
              Listings roll up into regions, then down into store demand and fill paths.
            </div>

            <div
              style={{
                marginTop: 18,
                height: 410,
                borderRadius: 24,
                position: "relative",
                overflow: "hidden",
                background: "linear-gradient(180deg, #e8f1fb 0%, #f7fbff 100%)",
                border: "1px solid rgba(16,32,51,0.08)",
              }}
            >
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  backgroundImage:
                    "linear-gradient(rgba(16,32,51,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(16,32,51,0.04) 1px, transparent 1px)",
                  backgroundSize: "56px 56px",
                }}
              />
              <div style={{ position: "absolute", inset: 24, borderRadius: 24, background: "linear-gradient(180deg, #fef3c7 0%, #eef7dd 46%, #dcecff 100%)", opacity: 0.7 }} />

              {regionGroups.map(([region, items]) => {
                const pos = centroidLabel(region);
                const active = activeRegion === region;
                return (
                  <button
                    key={region}
                    onClick={() => {
                      setActiveRegion(region);
                      setMode("district");
                    }}
                    style={{
                      position: "absolute",
                      left: pos.left,
                      top: pos.top,
                      transform: "translate(-50%,-50%)",
                      background: "transparent",
                      border: 0,
                      cursor: "pointer",
                    }}
                  >
                    <div
                      style={{
                        width: active ? 28 : 22,
                        height: active ? 28 : 22,
                        borderRadius: 999,
                        background: active ? "#d34a37" : "#2f8c63",
                        boxShadow: active ? "0 0 0 14px rgba(211,74,55,0.18)" : "0 0 0 12px rgba(47,140,99,0.16)",
                        margin: "0 auto",
                      }}
                    />
                    <div
                      style={{
                        marginTop: 12,
                        padding: "8px 12px",
                        borderRadius: 999,
                        background: "rgba(255,255,255,0.96)",
                        fontSize: 12,
                        fontWeight: 900,
                        whiteSpace: "nowrap",
                        boxShadow: "0 8px 20px rgba(16,32,51,0.08)",
                        color: "#102033",
                      }}
                    >
                      {region} · {items.length} listings
                    </div>
                  </button>
                );
              })}

              {fillPlans.slice(0, 4).map((plan, idx) => {
                const start = centroidLabel(plan.store.region);
                const end = { left: `${18 + idx * 18}%`, top: `${72 - idx * 7}%` };
                return (
                  <svg key={plan.store.id} width="100%" height="100%" style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
                    <line x1={start.left} y1={start.top} x2={end.left} y2={end.top} stroke="#497fa6" strokeWidth="3" strokeDasharray="8 8" />
                  </svg>
                );
              })}
            </div>
          </div>

          <div style={{ display: "grid", gap: 18 }}>
            {produceTotals.length ? (
              <ListCard
                title="Top live produce supply"
                items={produceTotals.slice(0, 5).map((item) => ({
                  name: item.produce,
                  sub: "Live inventory from marketplace listings",
                  value: `${n(item.qty)} units`,
                }))}
              />
            ) : (
              <EmptyState text="No live produce totals yet." />
            )}

            {fillPlans.length ? (
              <ListCard
                title="Store fill opportunities"
                items={fillPlans.slice(0, 4).map((plan) => ({
                  name: `${plan.store.name} · ${plan.store.city}`,
                  sub: `${plan.store.produce} · ${plan.coverage}% coverage`,
                  value: `${n(plan.matched)}/${n(plan.store.needed)}`,
                }))}
              />
            ) : (
              <EmptyState text="No fill opportunities yet." />
            )}

            <div style={{ ...panel, padding: 22 }}>
              <div style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: ".08em", color: "#728195", fontWeight: 800 }}>
                National posture
              </div>
              <div style={{ fontSize: 32, fontWeight: 900, marginTop: 10, lineHeight: 1.04 }}>
                Built for local action, framed for national scale.
              </div>
              <div style={{ color: "#556579", marginTop: 8, fontSize: 16, lineHeight: 1.5 }}>
                This view treats each listing as a supply node, each region as a district layer, and each store need as fillable demand. That makes PLUCK legible as a national product instead of just a neighborhood marketplace.
              </div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 16 }}>
                <span style={pill}>National framing</span>
                <span style={pill}>Live listing supply</span>
                <span style={pill}>First-pass fill engine</span>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
