# PLUCK Surgical UI Bundle

This bundle is designed as a low-risk overlay.

## Files
- `client/src/debug/pluckSurgicalUiPatch.ts`
- `client/src/debug/pluckSurgicalUiPatch.css`

## Import into PLUCK

Add these two lines near the top of `client/src/main.tsx`:

```ts
import './debug/pluckSurgicalUiPatch.css';
import './debug/pluckSurgicalUiPatch';
```

## What it targets
- clears likely gray slab wrappers under home fruit cards
- forces likely card grids to 4-up on desktop / 2-up tablet / 1-up mobile
- replaces likely route hero areas with fruit-only artwork
- gives profile a fruit banner
- avoids remote assets by using inline SVG art

## Rollback
Remove the two import lines from `client/src/main.tsx`.
