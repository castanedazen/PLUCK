const svg = (markup: string) => `data:image/svg+xml;utf8,${encodeURIComponent(markup)}`;

const heroFruitBanner = svg(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 560">
  <defs>
    <linearGradient id="g" x1="0" x2="1">
      <stop offset="0%" stop-color="#fff5e9"/>
      <stop offset="50%" stop-color="#fff0e1"/>
      <stop offset="100%" stop-color="#fff7ed"/>
    </linearGradient>
  </defs>
  <rect width="1600" height="560" fill="url(#g)"/>
  <g opacity=".95">
    <circle cx="240" cy="280" r="148" fill="#ff9f1c"/>
    <circle cx="240" cy="280" r="108" fill="#ffd166"/>
    <path d="M240 172 L240 388 M132 280 L348 280 M165 205 L315 355 M315 205 L165 355" stroke="#fff4d6" stroke-width="14" stroke-linecap="round"/>
    <ellipse cx="336" cy="152" rx="44" ry="18" fill="#76a94f" transform="rotate(-22 336 152)"/>
  </g>
  <g opacity=".95">
    <ellipse cx="650" cy="330" rx="115" ry="140" fill="#7a4b2f"/>
    <ellipse cx="650" cy="330" rx="78" ry="92" fill="#a3cf5f"/>
    <circle cx="650" cy="330" r="24" fill="#7a4b2f"/>
    <ellipse cx="726" cy="190" rx="46" ry="18" fill="#76a94f" transform="rotate(-20 726 190)"/>
  </g>
  <g opacity=".95">
    <circle cx="1020" cy="292" r="112" fill="#f28482"/>
    <circle cx="1020" cy="292" r="92" fill="#f6bd60" opacity=".35"/>
    <circle cx="1020" cy="292" r="10" fill="#7a3e12"/>
    <path d="M1020 180 C1025 145 1050 128 1088 120" stroke="#6b8e23" stroke-width="10" fill="none" stroke-linecap="round"/>
    <ellipse cx="1098" cy="116" rx="30" ry="14" fill="#77a94d" transform="rotate(18 1098 116)"/>
  </g>
  <g opacity=".95">
    <circle cx="1332" cy="286" r="108" fill="#c1121f"/>
    <circle cx="1332" cy="286" r="82" fill="#f94144" opacity=".45"/>
    <g fill="#ffd6a5">
      <circle cx="1298" cy="256" r="7"/><circle cx="1335" cy="246" r="7"/><circle cx="1367" cy="270" r="7"/>
      <circle cx="1288" cy="302" r="7"/><circle cx="1328" cy="312" r="7"/><circle cx="1365" cy="320" r="7"/>
    </g>
    <path d="M1332 176 C1332 144 1352 126 1382 118" stroke="#6b8e23" stroke-width="10" fill="none" stroke-linecap="round"/>
  </g>
</svg>
`);

const citrusSlice = svg(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 700">
  <rect width="1200" height="700" fill="#fff7ed"/>
  <circle cx="600" cy="350" r="260" fill="#ff9f1c"/>
  <circle cx="600" cy="350" r="205" fill="#ffd166"/>
  <circle cx="600" cy="350" r="188" fill="#fff1bf"/>
  <g stroke="#fff8de" stroke-width="18" stroke-linecap="round">
    <path d="M600 350 L600 145"/><path d="M600 350 L777 219"/><path d="M600 350 L805 350"/>
    <path d="M600 350 L777 481"/><path d="M600 350 L600 555"/><path d="M600 350 L423 481"/>
    <path d="M600 350 L395 350"/><path d="M600 350 L423 219"/>
  </g>
  <circle cx="865" cy="155" r="48" fill="#7cb342"/>
  <ellipse cx="930" cy="120" rx="72" ry="24" fill="#6aa84f" transform="rotate(-18 930 120)"/>
</svg>
`);

const orchardFruit = svg(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 700">
  <rect width="1200" height="700" fill="#fff8f0"/>
  <g transform="translate(140,170)">
    <circle cx="120" cy="180" r="110" fill="#f77f00"/><circle cx="120" cy="180" r="82" fill="#ffd166"/>
    <path d="M120 98 L120 262 M38 180 L202 180 M62 122 L178 238 M178 122 L62 238" stroke="#fff5dd" stroke-width="12" stroke-linecap="round"/>
  </g>
  <g transform="translate(430,150)">
    <ellipse cx="120" cy="210" rx="102" ry="122" fill="#7a4b2f"/>
    <ellipse cx="120" cy="210" rx="70" ry="82" fill="#9bd35d"/>
    <circle cx="120" cy="210" r="22" fill="#7a4b2f"/>
  </g>
  <g transform="translate(760,150)">
    <circle cx="120" cy="190" r="105" fill="#c1121f"/>
    <g fill="#ffd6a5">
      <circle cx="82" cy="150" r="6"/><circle cx="124" cy="140" r="6"/><circle cx="162" cy="166" r="6"/>
      <circle cx="74" cy="206" r="6"/><circle cx="124" cy="220" r="6"/><circle cx="165" cy="228" r="6"/>
    </g>
  </g>
  <text x="80" y="610" font-family="Inter, Arial" font-size="48" font-weight="800" fill="#22334a">Fruit growers. Fruit conversations. Fruit-first market.</text>
</svg>
`);

const avocadoBanner = svg(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 420">
  <rect width="1200" height="420" fill="#f5f0e8"/>
  <g transform="translate(160,45)">
    <ellipse cx="220" cy="165" rx="138" ry="165" fill="#335c3a"/>
    <ellipse cx="220" cy="165" rx="98" ry="118" fill="#9ccc65"/>
    <circle cx="220" cy="210" r="42" fill="#7a4b2f"/>
  </g>
  <g transform="translate(600,70) scale(.9)">
    <ellipse cx="220" cy="165" rx="138" ry="165" fill="#335c3a"/>
    <ellipse cx="220" cy="165" rx="98" ry="118" fill="#aed581"/>
    <circle cx="220" cy="210" r="42" fill="#6d4528"/>
  </g>
</svg>
`);

function setStyle(el: HTMLElement, img: string) {
  el.style.backgroundImage = `linear-gradient(135deg, rgba(255,247,237,.85), rgba(255,240,225,.88)), url("${img}")`;
  el.style.backgroundSize = 'cover';
  el.style.backgroundPosition = 'center';
  el.style.backgroundRepeat = 'no-repeat';
}

function textOf(el: Element | null) {
  return (el?.textContent || '').trim().toLowerCase();
}

function pickArt(label: string) {
  if (label.includes('map') || label.includes('route')) return citrusSlice;
  if (label.includes('board')) return orchardFruit;
  if (label.includes('message') || label.includes('chat')) return avocadoBanner;
  if (label.includes('store') || label.includes('shop') || label.includes('market')) return citrusSlice;
  if (label.includes('profile') || label.includes('account')) return heroFruitBanner;
  return heroFruitBanner;
}

function patchRouteHeroes() {
  const heroCandidates = Array.from(document.querySelectorAll<HTMLElement>([
    '.route-hero', '.hero-card', '.hero-band', '.profile-banner', '.profile-hero',
    '.page-hero', '.page-banner', '.hero-image', '.header-image'
  ].join(',')));

  heroCandidates.forEach((el) => {
    const context = [
      textOf(el),
      textOf(el.closest('[data-route]')),
      textOf(el.closest('main')?.querySelector('h1')),
      textOf(document.querySelector('.bottom-nav .active, nav a.active, nav button.active')),
      textOf(document.querySelector('h1')),
    ].join(' ');

    const art = pickArt(context);
    setStyle(el, art);
    el.style.minHeight = el.classList.contains('profile-banner') ? '220px' : '260px';
    el.style.border = '1px solid rgba(210, 163, 92, 0.24)';
    el.style.overflow = 'hidden';
  });
}

function patchGraySlabs() {
  const selectors = [
    '.home-page', '.home-shell', '.landing-page', '.landing-shell', '.discover-page',
    '.hero-wrap', '.hero-media-wrap', '.card-row-wrap', '.cards-section', '.fruit-section',
    '.listing-section', '.market-strip', '.section-shell'
  ];
  document.querySelectorAll<HTMLElement>(selectors.join(',')).forEach((el) => {
    const style = window.getComputedStyle(el);
    const bg = style.backgroundColor.replace(/\s+/g, '');
    if (bg === 'rgb(238,238,238)' || bg === 'rgb(240,240,240)' || bg === 'rgb(245,245,245)' || bg === 'rgb(232,232,232)') {
      el.style.background = 'transparent';
      el.style.boxShadow = 'none';
      el.style.border = '0';
    }
  });
}

function patchCardGrids() {
  const selectors = [
    '.fruit-grid', '.orchard-grid', '.listing-grid', '.cards-grid', '.card-grid', '.market-grid',
    '.home-grid', '.featured-grid', '.product-grid', '.listing-row', '.fruit-row'
  ];

  document.querySelectorAll<HTMLElement>(selectors.join(',')).forEach((grid) => {
    const items = Array.from(grid.children).filter((child) => child instanceof HTMLElement) as HTMLElement[];
    if (items.length < 4) return;
    grid.style.display = 'grid';
    grid.style.gap = '18px';
    grid.style.alignItems = 'stretch';
    grid.style.gridTemplateColumns = window.innerWidth >= 1180
      ? 'repeat(4, minmax(0, 1fr))'
      : window.innerWidth >= 840
      ? 'repeat(2, minmax(0, 1fr))'
      : '1fr';

    items.forEach((item) => {
      item.style.minWidth = '0';
      item.style.width = '100%';
      item.style.maxWidth = 'none';
    });
  });
}

function patchNavTiles() {
  const tileSelectors = ['.bottom-nav a', '.bottom-nav button', 'nav a', 'nav button'];
  document.querySelectorAll<HTMLElement>(tileSelectors.join(',')).forEach((el) => {
    const label = textOf(el);
    if (!label) return;
    if (!/(map|board|messages|message|store|profile)/.test(label)) return;
    const art = pickArt(label);
    el.style.position = 'relative';
    el.style.overflow = 'hidden';
    el.style.borderRadius = '18px';
    const existing = el.querySelector<HTMLElement>('.pluck-fruit-tint');
    if (!existing) {
      const tint = document.createElement('span');
      tint.className = 'pluck-fruit-tint';
      Object.assign(tint.style, {
        position: 'absolute', inset: '0', backgroundImage: `linear-gradient(180deg, rgba(255,255,255,.72), rgba(255,255,255,.82)), url("${art}")`,
        backgroundSize: 'cover', backgroundPosition: 'center', opacity: '0.9', pointerEvents: 'none', zIndex: '0'
      });
      el.prepend(tint);
      Array.from(el.childNodes).forEach((node) => {
        if (node !== tint) {
          if (node instanceof HTMLElement) {
            node.style.position = 'relative';
            node.style.zIndex = '1';
          }
        }
      });
    }
  });
}

function runPatch() {
  patchGraySlabs();
  patchCardGrids();
  patchRouteHeroes();
  patchNavTiles();
}

export function installPluckSurgicalUiPatch() {
  const apply = () => requestAnimationFrame(runPatch);
  apply();
  const observer = new MutationObserver(apply);
  observer.observe(document.body, { childList: true, subtree: true });
  window.addEventListener('resize', apply);
  console.log('[PLUCK] surgical UI patch installed');
}

installPluckSurgicalUiPatch();
