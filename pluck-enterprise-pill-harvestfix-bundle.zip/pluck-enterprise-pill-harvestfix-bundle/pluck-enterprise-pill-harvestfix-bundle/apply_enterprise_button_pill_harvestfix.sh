#!/usr/bin/env bash
set -e
python3 "$(dirname "$0")/apply_enterprise_button_pill_harvestfix.py" "$@"
