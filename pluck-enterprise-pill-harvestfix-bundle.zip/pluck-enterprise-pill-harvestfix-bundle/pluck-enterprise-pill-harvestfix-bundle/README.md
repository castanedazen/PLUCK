PLUCK enterprise button + dark pill text + harvest image sizing fix
