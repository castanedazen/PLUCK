#!/usr/bin/env python3
from pathlib import Path
import sys, shutil

repo = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
app = repo / 'client/src/App.tsx'
css = repo / 'client/src/styles.css'

if not app.exists() or not css.exists():
    raise SystemExit('Expected client/src/App.tsx and client/src/styles.css')

# backups
for p, suffix in [(app, '.before-enterprise-button-pill-harvestfix.bak'), (css, '.before-enterprise-button-pill-harvestfix.bak')]:
    backup = p.with_name(p.name + suffix)
    if not backup.exists():
        shutil.copy2(p, backup)

s = app.read_text()

button_markup = """              <button className=\"ghost enterprise-link-btn\" onClick={() => goTo('/enterprise')}>
                For retailers
              </button>
"""

# add button to unauth topbar actions
unauth_block = """          {!authUser ? (
            <>
              <button className=\"ghost\" onClick={() => goTo('/login')}>
                Log in
              </button>
              <button className=\"primary\" onClick={() => goTo('/signup')}>
                Create account
              </button>
            </>
"""
unauth_repl = """          {!authUser ? (
            <>
""" + button_markup + """              <button className=\"ghost\" onClick={() => goTo('/login')}>
                Log in
              </button>
              <button className=\"primary\" onClick={() => goTo('/signup')}>
                Create account
              </button>
            </>
"""

# add button to auth topbar actions too
auth_block = """          ) : (
            <>
              <button className=\"ghost\" onClick={() => goTo('/favorites')}>
                Saved {favoriteListings.length ? `({favoriteListings.length})` : ''}
              </button>
"""
auth_repl = """          ) : (
            <>
""" + button_markup + """              <button className=\"ghost\" onClick={() => goTo('/favorites')}>
                Saved {favoriteListings.length ? `({favoriteListings.length})` : ''}
              </button>
"""

if 'For retailers' not in s:
    if unauth_block in s:
        s = s.replace(unauth_block, unauth_repl, 1)
    if auth_block in s:
        s = s.replace(auth_block, auth_repl, 1)

app.write_text(s)

c = css.read_text()
fix_block = """

/* enterprise button + overlay pill readability + harvest feed image sizing */
.topbar-actions{
  display:flex !important;
  align-items:center !important;
  gap:12px !important;
  flex-wrap:wrap !important;
}

.enterprise-link-btn{
  white-space:nowrap !important;
}

.trust-pill,
.hero-live-card__overlay .trust-pill,
.hero-live-card__overlay .trust-strip span,
.hero-live-card__overlay .trust-strip em,
.cinematic-link-card .trust-pill,
.cinematic-link-card .trust-strip span,
.cinematic-link-card .trust-strip em{
  background: var(--pill) !important;
  color: var(--ink) !important;
  border: 1px solid #cdd8e6 !important;
  opacity: 1 !important;
}

.hero-live-card__overlay .trust-strip,
.cinematic-link-card .trust-strip{
  gap: 8px !important;
}

.social-grid{
  align-items:start !important;
}

.social-card{
  overflow:hidden !important;
}

.social-image{
  width:100% !important;
  max-height:340px !important;
  height:340px !important;
  object-fit:cover !important;
  object-position:center !important;
  border-radius:18px !important;
}

@media (max-width: 720px){
  .social-image{
    max-height:240px !important;
    height:240px !important;
  }

  .topbar-actions{
    width:100% !important;
    justify-content:flex-start !important;
  }
}
"""

if 'enterprise button + overlay pill readability + harvest feed image sizing' not in c:
    c += fix_block
css.write_text(c)
print('Applied enterprise button + pill contrast + harvest feed image fix.')
