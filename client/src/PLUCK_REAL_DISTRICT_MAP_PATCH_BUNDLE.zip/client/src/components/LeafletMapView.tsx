
import { useEffect, useMemo, useRef, useState } from 'react'
import { MapContainer, Marker, Popup, TileLayer, ZoomControl, useMap } from 'react-leaflet'
import L from 'leaflet'
import type { Listing } from '../types'

const defaultCenter: [number, number] = [37.0902, -95.7129]

const pluckIcon = L.divIcon({
  className: 'pluck-marker-shell',
  html: '<div class="pluck-marker-dot"></div>',
  iconSize: [24, 24],
  iconAnchor: [12, 12],
})

function hasGeo(listing: Listing) {
  return (
    typeof listing.geo?.lat === 'number' &&
    Number.isFinite(listing.geo.lat) &&
    typeof listing.geo?.lng === 'number' &&
    Number.isFinite(listing.geo.lng)
  )
}

function prettyLocation(listing: Listing) {
  const parts = [listing.city || '', listing.state || ''].filter(Boolean)
  if (parts.length) return parts.join(', ')
  return listing.location
}

function ResizeAndFit({
  center,
  zoom,
  points,
  searchMode,
}: {
  center: [number, number]
  zoom: number
  points: [number, number][]
  searchMode: boolean
}) {
  const map = useMap()

  useEffect(() => {
    const resize = () => map.invalidateSize()
    const t1 = window.setTimeout(resize, 80)
    const t2 = window.setTimeout(resize, 260)
    window.addEventListener('resize', resize)
    return () => {
      window.clearTimeout(t1)
      window.clearTimeout(t2)
      window.removeEventListener('resize', resize)
    }
  }, [map])

  useEffect(() => {
    if (!points.length) {
      map.setView(center, zoom, { animate: true })
      return
    }

    if (searchMode || points.length === 1) {
      map.flyTo(center, zoom, { animate: true, duration: 0.6 })
      return
    }

    const bounds = L.latLngBounds(points)
    map.fitBounds(bounds, { padding: [42, 42], maxZoom: 10, animate: true })
  }, [map, center, zoom, points, searchMode])

  return null
}

function MapButtons({
  defaultPoints,
  onLocate,
  locating,
}: {
  defaultPoints: [number, number][]
  onLocate: () => void
  locating: boolean
}) {
  const map = useMap()

  const btn: React.CSSProperties = {
    border: '1px solid rgba(16,24,40,0.08)',
    background: 'rgba(255,255,255,0.94)',
    borderRadius: 12,
    padding: '10px 12px',
    fontSize: 13,
    fontWeight: 700,
    color: '#203022',
    cursor: 'pointer',
  }

  return (
    <div style={{ position: 'absolute', right: 14, top: 64, zIndex: 500, display: 'grid', gap: 8 }}>
      <button type="button" style={btn} onClick={() => map.zoomIn()}>
        Zoom in
      </button>
      <button type="button" style={btn} onClick={() => map.zoomOut()}>
        Zoom out
      </button>
      <button
        type="button"
        style={btn}
        onClick={() => {
          if (defaultPoints.length > 1) {
            map.fitBounds(L.latLngBounds(defaultPoints), { padding: [42, 42], maxZoom: 10, animate: true })
          } else {
            map.flyTo(defaultCenter, 5, { animate: true, duration: 0.6 })
          }
        }}
      >
        Reset
      </button>
      <button type="button" style={btn} onClick={onLocate}>
        {locating ? 'Locating…' : 'Locate me'}
      </button>
    </div>
  )
}

type SearchTarget = {
  center: [number, number]
  label: string
  zoom: number
} | null

export function LeafletMapView({
  listings,
  searchQuery,
  onOpenListing,
}: {
  listings: Listing[]
  searchQuery?: string
  onOpenListing: (listingId: string) => void
}) {
  const geoListings = useMemo(() => listings.filter(hasGeo), [listings])
  const [searchTarget, setSearchTarget] = useState<SearchTarget>(null)
  const [userTarget, setUserTarget] = useState<SearchTarget>(null)
  const [locating, setLocating] = useState(false)
  const requestId = useRef(0)

  const averageCenter = useMemo<[number, number]>(() => {
    if (!geoListings.length) return defaultCenter
    const lat = geoListings.reduce((sum, item) => sum + (item.geo?.lat || 0), 0) / geoListings.length
    const lng = geoListings.reduce((sum, item) => sum + (item.geo?.lng || 0), 0) / geoListings.length
    return [lat, lng]
  }, [geoListings])

  const pointList = useMemo<[number, number][]>(() => geoListings.map((item) => [item.geo!.lat, item.geo!.lng]), [geoListings])

  useEffect(() => {
    const raw = (searchQuery || '').trim()
    if (!raw) {
      setSearchTarget(null)
      return
    }

    const matchingListing = listings.find((item) =>
      [item.zip, item.city, item.state, item.location]
        .filter(Boolean)
        .some((value) => value!.toLowerCase() === raw.toLowerCase()) && hasGeo(item)
    )
    if (matchingListing?.geo) {
      setSearchTarget({
        center: [matchingListing.geo.lat, matchingListing.geo.lng],
        label: prettyLocation(matchingListing),
        zoom: 11,
      })
      return
    }

    const currentRequest = ++requestId.current
    const controller = new AbortController()
    const isZip = /^\d{5}$/.test(raw)
    const q = isZip ? `${raw}, USA` : raw

    const timer = window.setTimeout(async () => {
      try {
        const url = new URL('https://nominatim.openstreetmap.org/search')
        url.searchParams.set('format', 'jsonv2')
        url.searchParams.set('countrycodes', 'us')
        url.searchParams.set('limit', '1')
        url.searchParams.set('q', q)

        const res = await fetch(url.toString(), {
          signal: controller.signal,
          headers: {
            Accept: 'application/json',
          },
        })

        if (!res.ok) return

        const data = (await res.json()) as Array<{ lat: string; lon: string; display_name: string }>
        if (!data.length || currentRequest !== requestId.current) return

        const first = data[0]
        setSearchTarget({
          center: [Number(first.lat), Number(first.lon)],
          label: isZip ? raw : first.display_name.split(',').slice(0, 2).join(', '),
          zoom: isZip ? 11 : 10,
        })
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          console.warn('Map recenter lookup failed', error)
        }
      }
    }, 350)

    return () => {
      controller.abort()
      window.clearTimeout(timer)
    }
  }, [listings, searchQuery])

  async function handleLocateMe() {
    if (!navigator.geolocation) return
    setLocating(true)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserTarget({
          center: [pos.coords.latitude, pos.coords.longitude],
          label: 'your location',
          zoom: 12,
        })
        setLocating(false)
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 9000, maximumAge: 0 },
    )
  }

  const activeTarget = userTarget || searchTarget
  const activeCenter = activeTarget?.center || averageCenter
  const activeZoom = activeTarget?.zoom || (geoListings.length > 1 ? 5 : 9)

  if (!geoListings.length) {
    return (
      <div className="leaflet-map-shell premium-leaflet-shell empty-map-shell">
        <div className="empty-panel">Try another ZIP, city, or neighborhood to see fruit land on the map.</div>
      </div>
    )
  }

  return (
    <div className="leaflet-map-shell premium-leaflet-shell">
      <div className="map-floating-head">
        <div>
          <span className="map-floating-kicker">Live orchard map</span>
          <strong>{activeTarget ? `Viewing near ${activeTarget.label}` : 'Fruit-ready neighborhoods'}</strong>
        </div>
        <span className="map-floating-count">{geoListings.length} live listings</span>
      </div>

      <MapContainer
        center={activeCenter}
        zoom={activeZoom}
        scrollWheelZoom
        className="leaflet-map"
        zoomControl={false}
        style={{ height: '100%', width: '100%' }}
      >
        <ResizeAndFit center={activeCenter} zoom={activeZoom} points={pointList} searchMode={Boolean(activeTarget)} />
        <ZoomControl position="bottomright" />
        <MapButtons defaultPoints={pointList} onLocate={handleLocateMe} locating={locating} />
        <TileLayer
          attribution='&copy; OpenStreetMap contributors &copy; CARTO'
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
        />

        {geoListings.map((listing) => (
          <Marker key={listing.id} position={[listing.geo!.lat, listing.geo!.lng]} icon={pluckIcon}>
            <Popup>
              <div className="map-popup">
                <img src={listing.image} alt={listing.title} />
                <strong>{listing.title}</strong>
                <span>
                  {prettyLocation(listing)} • ${listing.price}/{listing.unit}
                </span>
                <div className="map-popup-trust">
                  {listing.sellerVerified ? <em>Verified grower</em> : null}
                  {listing.sellerRating ? <em>★ {listing.sellerRating.toFixed(1)}</em> : null}
                </div>
                <button type="button" className="primary popup-btn" onClick={() => onOpenListing(listing.id)}>
                  View listing
                </button>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}
