
import React, { useMemo } from 'react'
import type { Listing } from './types'

type StoreNode = {
  id: string
  name: string
  city: string
  shortageFruit: string
  shortageQty: number
  x: number
  y: number
}

const storeNodes: StoreNode[] = [
  { id: '1423', name: 'Store 1423', city: 'North Hills', shortageFruit: 'Avocados', shortageQty: 180, x: 22, y: 50 },
  { id: '1049', name: 'Store 1049', city: 'Reseda', shortageFruit: 'Tomatoes', shortageQty: 95, x: 35, y: 63 },
  { id: '1182', name: 'Store 1182', city: 'Van Nuys', shortageFruit: 'Lemons', shortageQty: 70, x: 50, y: 56 },
]

function hasGeo(listing: Listing) {
  return (
    typeof listing.geo?.lat === 'number' &&
    Number.isFinite(listing.geo.lat) &&
    typeof listing.geo?.lng === 'number' &&
    Number.isFinite(listing.geo.lng)
  )
}

function shortLocation(listing: Listing) {
  return listing.city || listing.location || 'Local supply'
}

function colorForFruit(fruit: string) {
  const key = fruit.toLowerCase()
  if (key.includes('avocado')) return '#2f8c63'
  if (key.includes('lemon') || key.includes('citrus')) return '#d5923a'
  if (key.includes('tomato')) return '#d34a37'
  return '#497fa6'
}

function nearestStoreIndex(listing: Listing) {
  if (!listing.geo) return 0
  const lat = listing.geo.lat
  const lng = listing.geo.lng
  const anchors = [
    { lat: 34.24, lng: -118.48 },
    { lat: 34.20, lng: -118.54 },
    { lat: 34.20, lng: -118.45 },
  ]
  let best = 0
  let bestDist = Number.POSITIVE_INFINITY
  anchors.forEach((a, idx) => {
    const d = Math.hypot(lat - a.lat, lng - a.lng)
    if (d < bestDist) {
      bestDist = d
      best = idx
    }
  })
  return best
}

function Pill({ children, dark = false }: { children: React.ReactNode; dark?: boolean }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '8px 14px',
        borderRadius: 999,
        background: dark ? 'rgba(255,255,255,0.18)' : 'rgba(255,255,255,0.94)',
        border: dark ? '1px solid rgba(255,255,255,0.20)' : '1px solid rgba(16,32,51,0.08)',
        color: dark ? '#ffffff' : '#102033',
        fontSize: 13,
        fontWeight: 800,
      }}
    >
      {children}
    </span>
  )
}

function StatCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div
      style={{
        background: 'rgba(255,255,255,0.92)',
        border: '1px solid rgba(16,32,51,0.08)',
        borderRadius: 22,
        boxShadow: '0 18px 44px rgba(16,32,51,0.08)',
        padding: 22,
      }}
    >
      <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '.08em', color: '#728195', fontWeight: 800 }}>
        {label}
      </div>
      <div style={{ fontSize: 34, fontWeight: 900, marginTop: 10, lineHeight: 1.05 }}>{value}</div>
      <div style={{ fontSize: 14, color: '#556579', marginTop: 8 }}>{sub}</div>
    </div>
  )
}

function ListCard({
  title,
  items,
}: {
  title: string
  items: { name: string; sub: string; value: string; accent?: string }[]
}) {
  return (
    <div
      style={{
        background: 'rgba(255,255,255,0.92)',
        border: '1px solid rgba(16,32,51,0.08)',
        borderRadius: 22,
        boxShadow: '0 18px 44px rgba(16,32,51,0.08)',
        padding: 22,
      }}
    >
      <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '.08em', color: '#728195', fontWeight: 800 }}>
        {title}
      </div>
      <div style={{ display: 'grid', gap: 12, marginTop: 16 }}>
        {items.map((item) => (
          <div
            key={item.name + item.sub}
            style={{
              borderRadius: 18,
              padding: 16,
              background: '#f8fbff',
              border: '1px solid rgba(16,32,51,0.06)',
              display: 'flex',
              justifyContent: 'space-between',
              gap: 12,
              alignItems: 'center',
            }}
          >
            <div>
              <div style={{ fontWeight: 800, fontSize: 16 }}>{item.name}</div>
              <div style={{ color: item.accent || '#556579', marginTop: 4, fontSize: 14 }}>{item.sub}</div>
            </div>
            <div style={{ fontWeight: 900, whiteSpace: 'nowrap', fontSize: 15 }}>{item.value}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function DistrictManagerMode({ listings }: { listings: Listing[] }) {
  const geoListings = useMemo(() => listings.filter(hasGeo), [listings])

  const growerCards = useMemo(() => {
    const base = geoListings.length ? geoListings : listings
    return base.slice(0, 3).map((item) => ({
      name: item.sellerName,
      sub: item.fruit,
      value: `${item.inventory} ${item.unit === 'each' ? 'units' : 'lbs'}`,
      accent: colorForFruit(item.fruit),
    }))
  }, [geoListings, listings])

  const stats = useMemo(() => {
    const growers = new Set(listings.map((item) => item.sellerId)).size || 0
    const supply = listings.reduce((sum, item) => sum + (Number(item.inventory) || 0), 0)
    return {
      stores: '12',
      growers: growers.toString(),
      supply: `${supply.toLocaleString()} units`,
      opportunities: `${Math.min(23, Math.max(6, listings.length * 2))}`,
    }
  }, [listings])

  const plottedGrowers = useMemo(() => {
    const base = geoListings.length ? geoListings : listings
    return base.slice(0, 6).map((item, idx) => {
      const storeIdx = nearestStoreIndex(item)
      const store = storeNodes[storeIdx]
      const offsetX = [ -4, 2, 5, -3, 4, 1 ][idx % 6]
      const offsetY = [ -5, 4, -10, 6, -2, 8 ][idx % 6]
      return {
        label: item.sellerName,
        fruit: item.fruit,
        x: store.x + offsetX,
        y: store.y + offsetY,
        color: colorForFruit(item.fruit),
        targetX: store.x,
        targetY: store.y,
      }
    })
  }, [geoListings, listings])

  return (
    <div
      style={{
        minHeight: '100vh',
        fontFamily: 'Inter, Arial, sans-serif',
        background: 'linear-gradient(180deg, #f8fbff 0%, #edf3f8 100%)',
        color: '#102033',
        padding: 28,
      }}
    >
      <div style={{ maxWidth: 1360, margin: '0 auto' }}>
        <section
          style={{
            borderRadius: 34,
            overflow: 'hidden',
            padding: 38,
            display: 'grid',
            gridTemplateColumns: '1.2fr 0.8fr',
            gap: 24,
            background:
              'linear-gradient(135deg, #1f6d5b 0%, #2e7d6b 18%, #497fa6 48%, #c16b2f 82%, #d5923a 100%)',
            boxShadow: '0 24px 60px rgba(16,32,51,0.18)',
          }}
        >
          <div>
            <Pill dark>PLUCK · DISTRICT</Pill>
            <div style={{ marginTop: 18, color: '#ffffff', fontSize: 68, lineHeight: 0.92, fontWeight: 900, letterSpacing: '-0.05em', maxWidth: 780 }}>
              Hyperlocal supply intelligence for food retail.
            </div>
            <div style={{ marginTop: 18, color: 'rgba(255,255,255,0.95)', fontSize: 22, lineHeight: 1.35, maxWidth: 760 }}>
              See store shortages, nearby grower supply, and the fastest local fill opportunities across a district in one clean view.
            </div>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 22 }}>
              <Pill>{stats.stores} stores</Pill>
              <Pill>{stats.growers} growers</Pill>
              <Pill>{stats.supply} live supply</Pill>
            </div>
          </div>

          <div
            style={{
              background: 'rgba(255,255,255,0.92)',
              border: '1px solid rgba(16,32,51,0.08)',
              borderRadius: 22,
              boxShadow: '0 18px 44px rgba(16,32,51,0.10)',
              padding: 24,
              alignSelf: 'end',
            }}
          >
            <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '.08em', color: '#728195', fontWeight: 800 }}>
              Best local fill opportunity
            </div>
            <div style={{ marginTop: 10, fontSize: 30, fontWeight: 900, lineHeight: 1.04 }}>
              Store 1423 → Avocados
            </div>
            <div style={{ marginTop: 10, color: '#556579', fontSize: 16, lineHeight: 1.45 }}>
              180 lbs short. Nearby growers in your live network can cover today’s best fill route.
            </div>
            <button
              style={{
                marginTop: 18,
                border: 0,
                borderRadius: 16,
                padding: '14px 18px',
                background: '#102033',
                color: '#ffffff',
                fontWeight: 800,
                fontSize: 16,
                cursor: 'pointer',
              }}
            >
              Request Local Fill
            </button>
          </div>
        </section>

        <section
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
            gap: 18,
            marginTop: 22,
          }}
        >
          <StatCard label="Stores Active" value={stats.stores} sub="Participating in district pilot" />
          <StatCard label="Growers" value={stats.growers} sub="Verified local supply points" />
          <StatCard label="Available Produce" value={stats.supply} sub="Live seller inventory" />
          <StatCard label="Fill Opportunities" value={stats.opportunities} sub="Store shortages matchable today" />
        </section>

        <section
          style={{
            display: 'grid',
            gridTemplateColumns: '1.15fr 0.85fr',
            gap: 22,
            marginTop: 22,
          }}
        >
          <div
            style={{
              background: 'rgba(255,255,255,0.92)',
              border: '1px solid rgba(16,32,51,0.08)',
              borderRadius: 22,
              boxShadow: '0 18px 44px rgba(16,32,51,0.08)',
              padding: 24,
            }}
          >
            <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '.08em', color: '#728195', fontWeight: 800 }}>
              District map
            </div>
            <div style={{ fontSize: 34, fontWeight: 900, marginTop: 10, lineHeight: 1.04 }}>
              San Fernando Valley district
            </div>
            <div style={{ color: '#556579', marginTop: 8, fontSize: 16 }}>
              Store pressure, grower clusters, and route-ready coverage from your live listings.
            </div>

            <div
              style={{
                marginTop: 18,
                height: 390,
                borderRadius: 24,
                position: 'relative',
                overflow: 'hidden',
                background: 'linear-gradient(180deg, #fef3c7 0%, #e9f7db 44%, #dcecff 100%)',
                border: '1px solid rgba(16,32,51,0.08)',
              }}
            >
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  backgroundImage:
                    'linear-gradient(rgba(16,32,51,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(16,32,51,0.05) 1px, transparent 1px)',
                  backgroundSize: '54px 54px',
                }}
              />

              <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0 }}>
                {plottedGrowers.map((g, idx) => (
                  <line key={idx} x1={`${g.targetX}%`} y1={`${g.targetY}%`} x2={`${g.x}%`} y2={`${g.y}%`} stroke="#2f8c63" strokeWidth="3" strokeDasharray="8 8" />
                ))}
              </svg>

              {storeNodes.map((store) => (
                <div key={store.id} style={{ position: 'absolute', left: `${store.x}%`, top: `${store.y}%`, transform: 'translate(-50%,-50%)' }}>
                  <div style={{ width: 18, height: 18, borderRadius: 999, background: '#d34a37', boxShadow: '0 0 0 10px rgba(211,74,55,0.12)' }} />
                  <div style={{ marginTop: 10, padding: '7px 11px', borderRadius: 999, background: 'rgba(255,255,255,0.94)', fontSize: 12, fontWeight: 800, whiteSpace: 'nowrap', boxShadow: '0 8px 20px rgba(16,32,51,0.08)' }}>
                    {store.name}
                  </div>
                </div>
              ))}

              {plottedGrowers.map((g) => (
                <div key={g.label + g.fruit} style={{ position: 'absolute', left: `${g.x}%`, top: `${g.y}%`, transform: 'translate(-50%,-50%)' }}>
                  <div style={{ width: 16, height: 16, borderRadius: 999, background: g.color, boxShadow: `0 0 0 9px ${g.color}22` }} />
                  <div style={{ marginTop: 8, padding: '6px 10px', borderRadius: 999, background: 'rgba(255,255,255,0.92)', fontSize: 11, fontWeight: 800, whiteSpace: 'nowrap' }}>
                    {g.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: 'grid', gap: 18 }}>
            <ListCard
              title="Store shortages"
              items={storeNodes.map((store) => ({
                name: store.name,
                sub: store.shortageFruit,
                value: `${store.shortageQty} lbs`,
                accent: colorForFruit(store.shortageFruit),
              }))}
            />

            <ListCard title="Nearby growers" items={growerCards} />

            <div
              style={{
                background: 'rgba(255,255,255,0.92)',
                border: '1px solid rgba(16,32,51,0.08)',
                borderRadius: 22,
                boxShadow: '0 18px 44px rgba(16,32,51,0.08)',
                padding: 22,
              }}
            >
              <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: '.08em', color: '#728195', fontWeight: 800 }}>
                Suggested fill plan
              </div>
              <div style={{ fontSize: 32, fontWeight: 900, marginTop: 10, lineHeight: 1.04 }}>
                Route ready
              </div>
              <div style={{ color: '#556579', marginTop: 8, fontSize: 16, lineHeight: 1.5 }}>
                Use district data to move supply faster, shrink waste, and test store-by-store local fill.
              </div>
              <button
                style={{
                  marginTop: 16,
                  border: 0,
                  borderRadius: 16,
                  padding: '14px 18px',
                  background: 'linear-gradient(135deg, #2f8c63 0%, #497fa6 100%)',
                  color: '#ffffff',
                  fontWeight: 800,
                  fontSize: 16,
                  cursor: 'pointer',
                }}
              >
                Build Pickup Route
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
