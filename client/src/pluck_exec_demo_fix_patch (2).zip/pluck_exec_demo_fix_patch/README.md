Run in Codespaces:

cd /workspaces/PLUCK
unzip -o pluck_exec_demo_fix_patch.zip -d /workspaces/PLUCK/pluck_exec_demo_fix_patch
bash /workspaces/PLUCK/pluck_exec_demo_fix_patch/scripts/apply-exec-demo-fix.sh /workspaces/PLUCK
cd /workspaces/PLUCK/client
npm run dev -- --host 0.0.0.0

Then open /district and look under Execute Local Fill for Run Executive Demo.
