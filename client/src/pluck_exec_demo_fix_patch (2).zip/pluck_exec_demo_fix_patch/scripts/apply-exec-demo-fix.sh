#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-/workspaces/PLUCK}"
FILE="$ROOT/client/src/DistrictManagerMode.tsx"
if [ ! -f "$FILE" ]; then
  echo "DistrictManagerMode.tsx not found at $FILE" >&2
  exit 1
fi
cp "$FILE" "$FILE.bak.$(date +%s)"
python3 - <<'PY' "$FILE"
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
if 'Run Executive Demo' in s and 'runAutoPlay' in s and 'autoPlay' in s:
    print('Autoplay already present')
    raise SystemExit(0)
# add autoPlay state
needle = "const [summary, setSummary] = useState('District idle. Ready to execute local fill.')"
repl = needle + "\n  const [autoPlay, setAutoPlay] = useState(false)"
if needle in s:
    s = s.replace(needle, repl, 1)
else:
    raise SystemExit('Could not find summary state insertion point')
# add runAutoPlay after runExecution
needle = "  async function runExecution() {"
start = s.find(needle)
if start == -1:
    raise SystemExit('Could not find runExecution')
# find end of function by locating buttonLabel declaration after it
marker = "\n\n  const buttonLabel ="
mid = s.find(marker, start)
if mid == -1:
    raise SystemExit('Could not find buttonLabel marker')
func_block = s[start:mid]
insert = """

  async function runAutoPlay() {
    if (isRunning || autoPlay) return
    setAutoPlay(true)

    const runDistrict = async (nextRole: BuyerRole, nextDistrict: string) => {
      setRole(nextRole)
      setDistrictId(nextDistrict)
      await new Promise((r) => setTimeout(r, 900))
      await runExecution()
      await new Promise((r) => setTimeout(r, 900))
    }

    await runDistrict('national-retail', 'sfv')
    await runDistrict('regional-vp', 'la-core')
    await runDistrict('district-manager', 'pasadena')

    setAutoPlay(false)
  }"""
s = s[:mid] + insert + s[mid:]
# add button below execute local fill button in execution summary card
button_snippet = """            <button
              onClick={runExecution}
              disabled={isRunning}
              style={{
                marginTop: 18,
                border: 0,
                borderRadius: 16,
                padding: '14px 18px',
                background: isRunning ? '#6b7280' : '#102033',
                color: '#ffffff',
                fontWeight: 800,
                fontSize: 16,
                cursor: isRunning ? 'default' : 'pointer',
              }}
            >
              {buttonLabel}
            </button>"""
replace_snippet = button_snippet + """
            <button
              onClick={runAutoPlay}
              disabled={isRunning || autoPlay}
              style={{
                marginTop: 10,
                border: 0,
                borderRadius: 14,
                padding: '12px 16px',
                background: autoPlay ? '#6b7280' : '#2f8c63',
                color: '#ffffff',
                fontWeight: 800,
                fontSize: 14,
                cursor: isRunning || autoPlay ? 'default' : 'pointer',
              }}
            >
              {autoPlay ? 'Running Executive Demo...' : 'Run Executive Demo'}
            </button>"""
if button_snippet in s:
    s = s.replace(button_snippet, replace_snippet, 1)
else:
    raise SystemExit('Could not find Execute Local Fill button block')
# reset autoPlay when district/role changes effect
needle = "    setSummary(`Ready to execute local fill in ${district.name}.`)"
repl = needle + "\n    setAutoPlay(false)"
if needle in s:
    s = s.replace(needle, repl, 1)
else:
    raise SystemExit('Could not find reset summary line')
p.write_text(s)
print('Patched DistrictManagerMode.tsx successfully')
PY

grep -n "Run Executive Demo\|runAutoPlay\|autoPlay" "$FILE" || true
