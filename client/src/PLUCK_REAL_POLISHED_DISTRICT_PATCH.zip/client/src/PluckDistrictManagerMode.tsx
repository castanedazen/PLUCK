import React from "react";

const cardStyle: React.CSSProperties = {
  background: "rgba(255,255,255,0.92)",
  border: "1px solid rgba(15,23,42,0.08)",
  borderRadius: 24,
  padding: 22,
  boxShadow: "0 12px 30px rgba(15,23,42,0.08)",
};

const pillStyle: React.CSSProperties = {
  display: "inline-block",
  padding: "8px 12px",
  borderRadius: 999,
  background: "rgba(255,255,255,0.9)",
  border: "1px solid rgba(15,23,42,0.08)",
  fontWeight: 700,
  fontSize: 13,
  color: "#1f2937",
};

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div style={cardStyle}>
      <div style={{ fontSize: 13, color: "#6b7280", fontWeight: 700, letterSpacing: ".04em", textTransform: "uppercase" }}>{label}</div>
      <div style={{ fontSize: 34, lineHeight: 1.1, marginTop: 10, fontWeight: 800, color: "#0f172a" }}>{value}</div>
    </div>
  );
}

export default function PluckDistrictManagerMode() {
  return (
    <div
      style={{
        minHeight: "100vh",
        fontFamily: "Inter, Arial, sans-serif",
        background:
          "linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%)",
        color: "#0f172a",
        padding: 24,
      }}
    >
      <div style={{ maxWidth: 1320, margin: "0 auto" }}>
        <section
          style={{
            borderRadius: 32,
            overflow: "hidden",
            padding: 36,
            minHeight: 300,
            display: "grid",
            gridTemplateColumns: "1.2fr .8fr",
            gap: 24,
            background:
              "linear-gradient(135deg, rgba(16,185,129,0.94) 0%, rgba(14,165,233,0.92) 45%, rgba(249,115,22,0.90) 100%)",
            boxShadow: "0 22px 60px rgba(15,23,42,0.16)",
          }}
        >
          <div>
            <div style={{ ...pillStyle, background: "rgba(255,255,255,0.2)", color: "white", border: "1px solid rgba(255,255,255,0.2)" }}>
              PLUCK • DISTRICT MANAGER MODE
            </div>
            <h1 style={{ fontSize: 62, lineHeight: 0.95, margin: "18px 0 14px", color: "white", fontWeight: 900, letterSpacing: "-0.04em" }}>
              Hyperlocal supply intelligence for food retail.
            </h1>
            <p style={{ fontSize: 22, lineHeight: 1.35, color: "rgba(255,255,255,0.96)", maxWidth: 700, margin: 0 }}>
              See store shortages, nearby grower supply, and best-fill routes across a district in one clean view.
            </p>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 22 }}>
              <span style={{ ...pillStyle, background: "white" }}>12 Stores</span>
              <span style={{ ...pillStyle, background: "white" }}>184 Growers</span>
              <span style={{ ...pillStyle, background: "white" }}>4,280 lbs live supply</span>
            </div>
          </div>

          <div style={{ ...cardStyle, alignSelf: "end" }}>
            <div style={{ fontWeight: 800, fontSize: 15, color: "#0f172a" }}>Top district opportunity</div>
            <div style={{ fontSize: 28, fontWeight: 900, marginTop: 8 }}>Store 1423 → Avocados</div>
            <div style={{ marginTop: 8, color: "#475569", fontSize: 16 }}>180 lbs short • 3 local growers can cover 185 lbs within 2.3 miles avg.</div>
            <button
              style={{
                marginTop: 18,
                border: 0,
                borderRadius: 16,
                padding: "14px 18px",
                background: "#0f172a",
                color: "white",
                fontWeight: 800,
                fontSize: 16,
                cursor: "pointer",
              }}
            >
              Request Local Fill
            </button>
          </div>
        </section>

        <section
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
            gap: 18,
            marginTop: 22,
          }}
        >
          <StatCard label="Stores Active" value="12" />
          <StatCard label="Growers" value="184" />
          <StatCard label="Available Produce" value="4,280 lbs" />
          <StatCard label="Fill Opportunities" value="23" />
        </section>

        <section
          style={{
            display: "grid",
            gridTemplateColumns: "1.15fr .85fr",
            gap: 22,
            marginTop: 22,
          }}
        >
          <div style={{ ...cardStyle, minHeight: 500 }}>
            <div style={{ fontSize: 13, color: "#6b7280", fontWeight: 700, letterSpacing: ".04em", textTransform: "uppercase" }}>District map</div>
            <h2 style={{ fontSize: 32, margin: "10px 0 8px", fontWeight: 900 }}>San Fernando Valley district</h2>
            <p style={{ color: "#64748b", marginTop: 0, fontSize: 16 }}>Store pressure, grower clusters, and route-ready coverage.</p>

            <div
              style={{
                marginTop: 16,
                height: 360,
                borderRadius: 24,
                position: "relative",
                overflow: "hidden",
                background:
                  "linear-gradient(180deg, #fef3c7 0%, #ecfccb 40%, #dbeafe 100%)",
                border: "1px solid rgba(15,23,42,0.08)",
              }}
            >
              <div style={{ position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(15,23,42,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(15,23,42,0.05) 1px, transparent 1px)", backgroundSize: "56px 56px" }} />
              {[
                { left: "22%", top: "48%", color: "#ef4444", label: "Store 1423" },
                { left: "34%", top: "62%", color: "#ef4444", label: "Store 1049" },
                { left: "48%", top: "56%", color: "#ef4444", label: "Store 1182" },
                { left: "20%", top: "44%", color: "#10b981", label: "Hernandez Yard" },
                { left: "31%", top: "58%", color: "#10b981", label: "Valley Co-op" },
                { left: "26%", top: "39%", color: "#10b981", label: "North Hills Harvest" },
              ].map((p, i) => (
                <div key={i} style={{ position: "absolute", left: p.left, top: p.top, transform: "translate(-50%,-50%)" }}>
                  <div style={{ width: 18, height: 18, borderRadius: 999, background: p.color, boxShadow: `0 0 0 8px ${p.color}22` }} />
                  <div style={{ marginTop: 8, padding: "6px 10px", borderRadius: 999, background: "rgba(255,255,255,0.92)", fontSize: 12, fontWeight: 800, whiteSpace: "nowrap" }}>{p.label}</div>
                </div>
              ))}
              <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
                <line x1="22%" y1="48%" x2="20%" y2="44%" stroke="#10b981" strokeWidth="3" strokeDasharray="8 8"/>
                <line x1="22%" y1="48%" x2="26%" y2="39%" stroke="#10b981" strokeWidth="3" strokeDasharray="8 8"/>
                <line x1="34%" y1="62%" x2="31%" y2="58%" stroke="#10b981" strokeWidth="3" strokeDasharray="8 8"/>
              </svg>
            </div>
          </div>

          <div style={{ display: "grid", gap: 18 }}>
            <div style={cardStyle}>
              <div style={{ fontSize: 13, color: "#6b7280", fontWeight: 700, letterSpacing: ".04em", textTransform: "uppercase" }}>Store shortages</div>
              <div style={{ marginTop: 14, display: "grid", gap: 12 }}>
                {[
                  ["Store 1423", "Avocados", "180 lbs"],
                  ["Store 1049", "Tomatoes", "95 lbs"],
                  ["Store 1182", "Lemons", "70 lbs"],
                ].map(([store, item, qty]) => (
                  <div key={store + item} style={{ padding: 16, borderRadius: 18, background: "#f8fafc", border: "1px solid rgba(15,23,42,0.06)", display: "flex", justifyContent: "space-between", gap: 12 }}>
                    <div>
                      <div style={{ fontWeight: 800 }}>{store}</div>
                      <div style={{ color: "#475569", marginTop: 3 }}>{item}</div>
                    </div>
                    <div style={{ fontWeight: 900 }}>{qty}</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={cardStyle}>
              <div style={{ fontSize: 13, color: "#6b7280", fontWeight: 700, letterSpacing: ".04em", textTransform: "uppercase" }}>Nearby growers</div>
              <div style={{ marginTop: 14, display: "grid", gap: 12 }}>
                {[
                  ["Hernandez Yard", "Avocados", "60 lbs"],
                  ["Valley Co-op", "Tomatoes", "100 lbs"],
                  ["North Hills Harvest", "Lemons", "80 lbs"],
                ].map(([grower, item, qty]) => (
                  <div key={grower + item} style={{ padding: 16, borderRadius: 18, background: "#f8fafc", border: "1px solid rgba(15,23,42,0.06)", display: "flex", justifyContent: "space-between", gap: 12 }}>
                    <div>
                      <div style={{ fontWeight: 800 }}>{grower}</div>
                      <div style={{ color: "#475569", marginTop: 3 }}>{item}</div>
                    </div>
                    <div style={{ fontWeight: 900 }}>{qty}</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={cardStyle}>
              <div style={{ fontSize: 13, color: "#6b7280", fontWeight: 700, letterSpacing: ".04em", textTransform: "uppercase" }}>Suggested fill plan</div>
              <div style={{ fontSize: 28, fontWeight: 900, marginTop: 10 }}>185 lbs matched</div>
              <p style={{ color: "#475569", fontSize: 16, lineHeight: 1.5 }}>
                Best route combines three nearby growers and covers the full avocado shortage at Store 1423.
              </p>
              <button
                style={{
                  border: 0,
                  borderRadius: 16,
                  padding: "14px 18px",
                  background: "linear-gradient(135deg, #10b981 0%, #0ea5e9 100%)",
                  color: "white",
                  fontWeight: 800,
                  fontSize: 16,
                  cursor: "pointer",
                }}
              >
                Build Pickup Route
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
