PLUCK Executive Demo Fix Patch

What this does:
- adds the missing Run Executive Demo button
- adds autoplay demo logic to DistrictManagerMode.tsx
- keeps a backup before patching

How to use in Codespaces:
1. Drag pluck_exec_demo_fix_patch.zip into /workspaces/PLUCK
2. Run:

cd /workspaces/PLUCK
unzip -o pluck_exec_demo_fix_patch.zip -d /workspaces/PLUCK/pluck_exec_demo_fix_patch
bash /workspaces/PLUCK/pluck_exec_demo_fix_patch/scripts/apply-exec-demo-fix.sh /workspaces/PLUCK
cd /workspaces/PLUCK/client
npm run dev -- --host 0.0.0.0

Then open /district.
The Run Executive Demo button should appear under Execute Local Fill / Fill Executed.
