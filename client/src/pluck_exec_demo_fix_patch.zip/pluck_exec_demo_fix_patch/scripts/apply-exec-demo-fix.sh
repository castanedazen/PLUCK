#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-/workspaces/PLUCK}"
TARGET="$REPO_ROOT/client/src/DistrictManagerMode.tsx"
BACKUP="$REPO_ROOT/client/src/DistrictManagerMode.tsx.exec-demo-fix.bak"

if [ ! -f "$TARGET" ]; then
  echo "Target file not found: $TARGET"
  exit 1
fi

cp "$TARGET" "$BACKUP"

python3 - <<'PY' "$TARGET"
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
text = p.read_text()
orig = text

# 1) add autoPlay state after isRunning if not present
if "const [autoPlay, setAutoPlay]" not in text:
    text = text.replace(
        "  const [isRunning, setIsRunning] = useState(false)\n",
        "  const [isRunning, setIsRunning] = useState(false)\n  const [autoPlay, setAutoPlay] = useState(false)\n",
        1,
    )

# 2) reset autoplay on district/role reset
if "setAutoPlay(false)" not in text:
    text = text.replace(
        "    setIsRunning(false)\n",
        "    setIsRunning(false)\n    setAutoPlay(false)\n",
        1,
    )

# 3) inject autoplay function after runExecution function
if "async function runAutoPlay()" not in text:
    marker = "  const buttonLabel ="
    autoplay_fn = '''\n  async function runAutoPlay() {\n    if (isRunning || autoPlay) return\n\n    setAutoPlay(true)\n    try {\n      setRole('national-retail')\n      setDistrictId('sfv')\n      await new Promise((r) => setTimeout(r, 800))\n\n      await runExecution()\n      await new Promise((r) => setTimeout(r, 1200))\n\n      setDistrictId('la-core')\n      await new Promise((r) => setTimeout(r, 700))\n      await runExecution()\n      await new Promise((r) => setTimeout(r, 1200))\n\n      setDistrictId('pasadena')\n      await new Promise((r) => setTimeout(r, 700))\n      await runExecution()\n      await new Promise((r) => setTimeout(r, 800))\n    } finally {\n      setAutoPlay(false)\n    }\n  }\n\n'''
    if marker in text:
        text = text.replace(marker, autoplay_fn + marker, 1)
    else:
        raise SystemExit("Could not find insertion marker for runAutoPlay")

# 4) update button disabled condition to include autoPlay
text = text.replace("disabled={isRunning}", "disabled={isRunning || autoPlay}")
text = text.replace("cursor: isRunning ? 'default' : 'pointer'", "cursor: isRunning || autoPlay ? 'default' : 'pointer'")

# 5) add Run Executive Demo button below main execution button
if "Run Executive Demo" not in text:
    pattern = re.compile(r"(\n\s*</button>\n\s*</div>\n\s*</section>)", re.M)
    replacement = '''\n            </button>\n            <button\n              onClick={runAutoPlay}\n              disabled={isRunning || autoPlay}\n              style={{\n                marginTop: 10,\n                border: 0,\n                borderRadius: 14,\n                padding: '12px 16px',\n                background: '#2f8c63',\n                color: '#ffffff',\n                fontWeight: 800,\n                fontSize: 14,\n                cursor: isRunning || autoPlay ? 'default' : 'pointer',\n              }}\n            >\n              {autoPlay ? 'Running Executive Demo...' : 'Run Executive Demo'}\n            </button>\n          </div>\n        </section>'''
    text, count = pattern.subn(replacement, text, count=1)
    if count == 0:
        raise SystemExit("Could not insert Run Executive Demo button")

if text == orig:
    print("No changes were needed.")
else:
    p.write_text(text)
    print("Patched:", p)
PY

echo "\nVerification:" 
grep -n "Run Executive Demo\|runAutoPlay\|autoPlay" "$TARGET" || true

echo "\nDone. Backup saved to: $BACKUP"
