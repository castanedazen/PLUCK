export default function PluckDistrictManagerMode() {
  const kpis = [
    { label: 'Stores live', value: '12', note: 'pilot locations' },
    { label: 'Active growers', value: '184', note: 'verified nearby' },
    { label: 'Open fill chances', value: '23', note: 'today' },
    { label: 'Local fill rate', value: '38%', note: 'of flagged needs' },
  ]

  const shortages = [
    { store: 'Store 1423', city: 'North Hills', item: 'Avocados', need: '180 lbs', fill: '82% fillable', miles: '2.3 mi avg' },
    { store: 'Store 1049', city: 'Reseda', item: 'Tomatoes', need: '95 lbs', fill: '64% fillable', miles: '3.8 mi avg' },
    { store: 'Store 1182', city: 'Van Nuys', item: 'Lemons', need: '70 lbs', fill: '100% fillable', miles: '2.1 mi avg' },
  ]

  const growers = [
    { name: 'Hernandez Yard', city: 'North Hills', item: 'Avocados', qty: '60 lbs', trust: '96% reliable' },
    { name: 'Valley Co-op', city: 'Reseda', item: 'Tomatoes', qty: '100 lbs', trust: '92% reliable' },
    { name: 'Citrus Block', city: 'Van Nuys', item: 'Lemons', qty: '85 lbs', trust: '94% reliable' },
  ]

  return (
    <div style={styles.page}>
      <div style={styles.shell}>
        <section style={styles.hero}>
          <img
            src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1600&q=80"
            alt="Fresh produce"
            style={styles.heroImage}
          />
          <div style={styles.heroOverlay} />
          <div style={styles.heroContent}>
            <div style={styles.eyebrow}>PLUCK · DISTRICT MANAGER MODE</div>
            <h1 style={styles.heroTitle}>Hyperlocal supply intelligence for food retail.</h1>
            <p style={styles.heroText}>
              See store shortages, nearby grower supply, and the fastest local fill plan in one clean view.
            </p>
            <div style={styles.heroButtons}>
              <button style={styles.primaryButton}>Open district brief</button>
              <button style={styles.secondaryButton}>View local fill plan</button>
            </div>
          </div>
        </section>

        <section style={styles.kpiGrid}>
          {kpis.map((kpi) => (
            <div key={kpi.label} style={styles.kpiCard}>
              <div style={styles.kpiLabel}>{kpi.label}</div>
              <div style={styles.kpiValue}>{kpi.value}</div>
              <div style={styles.kpiNote}>{kpi.note}</div>
            </div>
          ))}
        </section>

        <section style={styles.mainGrid}>
          <div style={styles.leftCol}>
            <div style={styles.panel}>
              <div style={styles.panelHeaderRow}>
                <div>
                  <div style={styles.panelEyebrow}>District overview</div>
                  <h2 style={styles.panelTitle}>San Fernando Valley district</h2>
                </div>
                <div style={styles.badge}>Demo cluster</div>
              </div>

              <div style={styles.mapMock}>
                <div style={{ ...styles.mapBubble, left: '18%', top: '62%' }}>Store 1423</div>
                <div style={{ ...styles.mapBubble, left: '52%', top: '56%' }}>Store 1049</div>
                <div style={{ ...styles.mapBubble, left: '72%', top: '34%' }}>Store 1182</div>

                <div style={{ ...styles.mapGrower, left: '25%', top: '52%' }}>🌿</div>
                <div style={{ ...styles.mapGrower, left: '58%', top: '64%' }}>🌿</div>
                <div style={{ ...styles.mapGrower, left: '77%', top: '44%' }}>🌿</div>

                <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={styles.mapSvg}>
                  <line x1="18" y1="62" x2="25" y2="52" stroke="rgba(16,185,129,.5)" strokeWidth="1.2" strokeDasharray="3 3" />
                  <line x1="52" y1="56" x2="58" y2="64" stroke="rgba(16,185,129,.5)" strokeWidth="1.2" strokeDasharray="3 3" />
                  <line x1="72" y1="34" x2="77" y2="44" stroke="rgba(16,185,129,.5)" strokeWidth="1.2" strokeDasharray="3 3" />
                </svg>
              </div>
            </div>

            <div style={styles.panel}>
              <div style={styles.panelEyebrow}>Store shortages</div>
              <h2 style={styles.panelTitle}>Best local fill opportunities today</h2>
              <div style={styles.listStack}>
                {shortages.map((row) => (
                  <div key={row.store + row.item} style={styles.rowCard}>
                    <div>
                      <div style={styles.rowTitle}>{row.store} · {row.city}</div>
                      <div style={styles.rowMeta}>{row.item} · needs {row.need}</div>
                    </div>
                    <div style={styles.rowStats}>
                      <span style={styles.greenPill}>{row.fill}</span>
                      <span style={styles.grayPill}>{row.miles}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div style={styles.rightCol}>
            <div style={styles.panel}>
              <div style={styles.panelEyebrow}>Nearby supply</div>
              <h2 style={styles.panelTitle}>Growers ready now</h2>
              <div style={styles.listStack}>
                {growers.map((grower) => (
                  <div key={grower.name} style={styles.supplyCard}>
                    <div>
                      <div style={styles.rowTitle}>{grower.name}</div>
                      <div style={styles.rowMeta}>{grower.city} · {grower.item}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={styles.qty}>{grower.qty}</div>
                      <div style={styles.trust}>{grower.trust}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div style={styles.panelAccent}>
              <div style={styles.panelEyebrowDark}>Suggested fill plan</div>
              <h2 style={styles.panelTitleDark}>Request local fill</h2>
              <p style={styles.darkText}>
                Combine 3 nearby growers and fill 185 lbs of avocado demand with short drive time and stronger freshness.
              </p>
              <div style={styles.planBox}>
                <div style={styles.planRow}><span>Hernandez Yard</span><strong>60 lbs</strong></div>
                <div style={styles.planRow}><span>Valley Grove Co-op</span><strong>80 lbs</strong></div>
                <div style={styles.planRow}><span>North Hills Harvest</span><strong>45 lbs</strong></div>
              </div>
              <button style={styles.primaryButtonFull}>Create district pickup plan</button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: 'linear-gradient(180deg, #f7faf8 0%, #eef3f1 100%)',
    padding: '24px',
    fontFamily: 'Inter, Arial, sans-serif',
    color: '#10231a',
  },
  shell: {
    maxWidth: '1380px',
    margin: '0 auto',
  },
  hero: {
    position: 'relative',
    borderRadius: '28px',
    overflow: 'hidden',
    minHeight: '360px',
    boxShadow: '0 20px 60px rgba(15, 23, 42, 0.12)',
    marginBottom: '22px',
    background: '#20352a',
  },
  heroImage: {
    position: 'absolute',
    inset: 0,
    width: '100%',
    height: '100%',
    objectFit: 'cover',
  },
  heroOverlay: {
    position: 'absolute',
    inset: 0,
    background: 'linear-gradient(90deg, rgba(7,23,17,0.82) 0%, rgba(7,23,17,0.48) 42%, rgba(7,23,17,0.18) 100%)',
  },
  heroContent: {
    position: 'relative',
    zIndex: 1,
    maxWidth: '700px',
    padding: '42px',
    color: 'white',
  },
  eyebrow: {
    fontSize: '12px',
    letterSpacing: '0.18em',
    textTransform: 'uppercase',
    fontWeight: 800,
    color: '#f5c14c',
    marginBottom: '16px',
  },
  heroTitle: {
    fontSize: '64px',
    lineHeight: 0.95,
    margin: '0 0 18px 0',
    fontWeight: 800,
  },
  heroText: {
    fontSize: '22px',
    lineHeight: 1.35,
    color: 'rgba(255,255,255,0.92)',
    margin: 0,
    maxWidth: '640px',
  },
  heroButtons: {
    display: 'flex',
    gap: '12px',
    marginTop: '24px',
    flexWrap: 'wrap',
  },
  primaryButton: {
    background: '#f4a321',
    color: '#fff',
    border: 'none',
    borderRadius: '999px',
    padding: '14px 22px',
    fontWeight: 700,
    fontSize: '16px',
    cursor: 'pointer',
  },
  secondaryButton: {
    background: 'rgba(255,255,255,0.14)',
    color: '#fff',
    border: '1px solid rgba(255,255,255,0.26)',
    borderRadius: '999px',
    padding: '14px 22px',
    fontWeight: 700,
    fontSize: '16px',
    cursor: 'pointer',
    backdropFilter: 'blur(10px)',
  },
  kpiGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, minmax(0, 1fr))',
    gap: '16px',
    marginBottom: '22px',
  },
  kpiCard: {
    background: '#fff',
    borderRadius: '24px',
    padding: '24px',
    boxShadow: '0 12px 34px rgba(16,24,40,0.08)',
    border: '1px solid rgba(15,23,42,0.06)',
  },
  kpiLabel: { fontSize: '14px', color: '#5a6a61', fontWeight: 600, marginBottom: '8px' },
  kpiValue: { fontSize: '42px', lineHeight: 1, fontWeight: 800, color: '#142a1f' },
  kpiNote: { fontSize: '14px', color: '#7a8a82', marginTop: '8px' },
  mainGrid: {
    display: 'grid',
    gridTemplateColumns: '1.35fr 0.9fr',
    gap: '18px',
  },
  leftCol: { display: 'grid', gap: '18px' },
  rightCol: { display: 'grid', gap: '18px' },
  panel: {
    background: '#fff',
    borderRadius: '28px',
    padding: '24px',
    border: '1px solid rgba(15,23,42,0.06)',
    boxShadow: '0 12px 34px rgba(16,24,40,0.08)',
  },
  panelAccent: {
    background: 'linear-gradient(135deg, #153e2c 0%, #1c5a41 100%)',
    color: '#fff',
    borderRadius: '28px',
    padding: '24px',
    boxShadow: '0 18px 40px rgba(21,62,44,0.24)',
  },
  panelHeaderRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '12px', marginBottom: '16px' },
  panelEyebrow: { fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.14em', color: '#7b8c83', fontWeight: 800, marginBottom: '8px' },
  panelEyebrowDark: { fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.14em', color: 'rgba(255,255,255,0.72)', fontWeight: 800, marginBottom: '8px' },
  panelTitle: { margin: 0, fontSize: '30px', lineHeight: 1.05, color: '#12261c' },
  panelTitleDark: { margin: 0, fontSize: '32px', lineHeight: 1.05, color: '#fff' },
  badge: { background: '#eef8f2', color: '#19724a', padding: '10px 14px', borderRadius: '999px', fontWeight: 700, fontSize: '13px' },
  mapMock: {
    position: 'relative',
    minHeight: '320px',
    borderRadius: '24px',
    overflow: 'hidden',
    background: 'linear-gradient(180deg, #eff7f2 0%, #f8fbf9 100%)',
    border: '1px solid rgba(16,24,40,0.06)',
  },
  mapSvg: { position: 'absolute', inset: 0, width: '100%', height: '100%' },
  mapBubble: {
    position: 'absolute',
    transform: 'translate(-50%, -50%)',
    background: '#15281f',
    color: '#fff',
    borderRadius: '999px',
    padding: '10px 14px',
    fontSize: '13px',
    fontWeight: 700,
    boxShadow: '0 12px 24px rgba(16,24,40,0.18)',
  },
  mapGrower: {
    position: 'absolute',
    transform: 'translate(-50%, -50%)',
    width: '42px',
    height: '42px',
    borderRadius: '999px',
    background: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 10px 20px rgba(16,24,40,0.12)',
    border: '1px solid rgba(16,24,40,0.06)',
    fontSize: '20px',
  },
  listStack: { display: 'grid', gap: '12px', marginTop: '16px' },
  rowCard: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '14px',
    alignItems: 'center',
    background: '#f9fbfa',
    borderRadius: '20px',
    padding: '16px 18px',
    border: '1px solid rgba(16,24,40,0.05)',
  },
  supplyCard: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: '14px',
    alignItems: 'center',
    background: '#f9fbfa',
    borderRadius: '20px',
    padding: '16px 18px',
    border: '1px solid rgba(16,24,40,0.05)',
  },
  rowTitle: { fontSize: '18px', fontWeight: 800, color: '#15281f' },
  rowMeta: { fontSize: '14px', color: '#6d7b73', marginTop: '4px' },
  rowStats: { display: 'flex', gap: '8px', flexWrap: 'wrap', justifyContent: 'flex-end' },
  greenPill: { background: '#eaf8ef', color: '#1a7c4d', borderRadius: '999px', padding: '9px 12px', fontSize: '13px', fontWeight: 700 },
  grayPill: { background: '#edf1ef', color: '#41524a', borderRadius: '999px', padding: '9px 12px', fontSize: '13px', fontWeight: 700 },
  qty: { fontSize: '20px', fontWeight: 800, color: '#15281f' },
  trust: { fontSize: '13px', color: '#6d7b73', marginTop: '4px' },
  darkText: { fontSize: '17px', lineHeight: 1.45, color: 'rgba(255,255,255,0.86)', marginTop: '12px' },
  planBox: { background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '18px', padding: '16px', marginTop: '18px', marginBottom: '18px' },
  planRow: { display: 'flex', justifyContent: 'space-between', fontSize: '15px', padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.12)', color: '#fff' },
  primaryButtonFull: { width: '100%', background: '#f4a321', color: '#fff', border: 'none', borderRadius: '18px', padding: '16px 18px', fontWeight: 800, fontSize: '16px', cursor: 'pointer' },
}
