import PluckDistrictManagerMode from './PluckDistrictManagerMode'

export default function App() {
  return <PluckDistrictManagerMode />
}
