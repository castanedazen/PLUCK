# PLUCK Autoplay Final Patch

This patch upgrades the working `/district` demo to a true autoplay executive presentation mode.

## What it adds
- `Run Executive Demo` button
- automatic role switch to National Retail
- autoplay sequence across:
  - San Fernando Valley
  - Los Angeles Core
  - Pasadena District
- live KPI updates across all three runs
- no manual file editing required

## Codespaces steps
1. Drag this zip into `/workspaces/PLUCK`
2. Run:

```bash
cd /workspaces/PLUCK
unzip -o pluck_autoplay_final_patch.zip -d /workspaces/PLUCK/pluck_autoplay_final_patch
bash /workspaces/PLUCK/pluck_autoplay_final_patch/scripts/apply-autoplay-final.sh /workspaces/PLUCK
cd /workspaces/PLUCK/client
npm run dev -- --host 0.0.0.0
```

## What to test on `/district`
- Click `Run Executive Demo`
- Watch role switch to `National Retail`
- Watch district rotate through 3 presets
- Watch button states, KPIs, summary text, and map lines update automatically
