import PluckDistrictManagerMode from "./PluckDistrictManagerMode";

export default function App() {
  const SHOW_DISTRICT_MODE = true;

  if (SHOW_DISTRICT_MODE) {
    return <PluckDistrictManagerMode />;
  }

  return <div style={{padding:40}}>Your original app runs here (toggle off to restore)</div>;
}
