export default function PluckDistrictManagerMode() {
  return (
    <div style={{ padding: "40px", fontFamily: "Arial" }}>
      <h1>PLUCK — District Manager Mode</h1>
      <h2>San Fernando Valley District</h2>

      <h3>📊 Snapshot</h3>
      <ul>
        <li>Stores: 12</li>
        <li>Growers: 184</li>
        <li>Available Produce: 4,280 lbs</li>
        <li>Fill Opportunities: 23</li>
      </ul>

      <h3>🏬 Store Shortages</h3>
      <ul>
        <li>Store 1423 — Avocados — 180 lbs</li>
        <li>Store 1049 — Tomatoes — 95 lbs</li>
      </ul>

      <h3>🌱 Nearby Growers</h3>
      <ul>
        <li>Hernandez Yard — Avocados (60 lbs)</li>
        <li>Valley Co-op — Tomatoes (100 lbs)</li>
      </ul>

      <button style={{marginTop:20,padding:10}}>Request Local Fill</button>
    </div>
  );
}
