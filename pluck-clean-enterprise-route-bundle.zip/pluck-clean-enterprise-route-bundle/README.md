Apply clean enterprise route only. No homepage restyle.
