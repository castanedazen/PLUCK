#!/usr/bin/env python3
from pathlib import Path
import shutil
import sys

repo = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
app = repo / 'client/src/App.tsx'
styles = repo / 'client/src/styles.css'
pages_dir = repo / 'client/src/pages'
enterprise_src = repo / 'client/src/pages/Enterprise.tsx'
css_src = Path(__file__).resolve().parent / 'enterprise-route.css'
bundle_enterprise = Path(__file__).resolve().parent / 'client/src/pages/Enterprise.tsx'

if not app.exists() or not styles.exists():
    raise SystemExit('Could not find client/src/App.tsx or client/src/styles.css')

pages_dir.mkdir(parents=True, exist_ok=True)
shutil.copy2(bundle_enterprise, enterprise_src)

app_backup = repo / 'client/src/App.tsx.before-clean-enterprise.bak'
styles_backup = repo / 'client/src/styles.css.before-clean-enterprise.bak'
if not app_backup.exists():
    shutil.copy2(app, app_backup)
if not styles_backup.exists():
    shutil.copy2(styles, styles_backup)

s = app.read_text()
if "./pages/Enterprise" not in s:
    s = s.replace("import CommunityBoard from './components/CommunityBoard'", "import CommunityBoard from './components/CommunityBoard'\nimport Enterprise from './pages/Enterprise'")

route_meta_block = """  {
    match: /^\/profile/,
    eyebrow: 'Reputation',
    title: 'Let your reputation travel ahead of you.',
    subtitle: 'Clear signals. Known locally. Easy to trust.',
  },
"""
enterprise_meta = """  {
    match: /^\/enterprise/,
    eyebrow: 'Retail mode',
    title: 'Hyperlocal supply intelligence for future retail partners.',
    subtitle: 'A clean enterprise layer built on top of the marketplace, not instead of it.',
  },
"""
if "match: /^\\/enterprise/" not in s:
    s = s.replace(route_meta_block, route_meta_block + enterprise_meta)

route_action_profile = """    if (/^\/profile/.test(location.pathname)) return { primary: ['View profile', () => scrollToId('profile-shell')], secondary: ['Saved fruit', () => goTo('/favorites', 'favorites-shell')] } as const
    return { primary: ['Browse fruit', () => scrollToId('listing-feed')], secondary: ['Open map', () => goTo('/map', 'map-panel')] } as const
"""
route_action_enterprise = """    if (/^\/profile/.test(location.pathname)) return { primary: ['View profile', () => scrollToId('profile-shell')], secondary: ['Saved fruit', () => goTo('/favorites', 'favorites-shell')] } as const
    if (/^\/enterprise/.test(location.pathname)) return { primary: ['Open enterprise view', () => scrollToId('enterprise-shell')], secondary: ['Back to market', () => goTo('/', 'listing-feed')] } as const
    return { primary: ['Browse fruit', () => scrollToId('listing-feed')], secondary: ['Open map', () => goTo('/map', 'map-panel')] } as const
"""
if "Open enterprise view" not in s:
    s = s.replace(route_action_profile, route_action_enterprise)

old_topbar = """        <div className=\"topbar-actions\">\n          {!authUser ? (\n            <>\n              <button className=\"ghost\" onClick={() => goTo('/login')}>\n                Log in\n              </button>\n              <button className=\"primary\" onClick={() => goTo('/signup')}>\n                Create account\n              </button>\n            </>\n          ) : (\n            <>\n              <button className=\"ghost\" onClick={() => goTo('/favorites')}>\n                Saved {favoriteListings.length ? `(${favoriteListings.length})` : ''}\n              </button>\n              <button className=\"ghost\" onClick={() => goTo('/alerts')}>\n                Alerts {unreadNotifications.length ? `(${unreadNotifications.length})` : ''}\n              </button>\n              <button className=\"ghost\" onClick={() => goTo('/profile')}>\n                Profile\n              </button>\n              <button className=\"ghost\" onClick={onLogout}>\n                Log out\n              </button>\n            </>\n          )}\n        </div>"""
new_topbar = """        <div className=\"topbar-actions\">\n          <button className=\"ghost enterprise-link\" onClick={() => goTo('/enterprise')}>\n            For retailers\n          </button>\n          {!authUser ? (\n            <>\n              <button className=\"ghost\" onClick={() => goTo('/login')}>\n                Log in\n              </button>\n              <button className=\"primary\" onClick={() => goTo('/signup')}>\n                Create account\n              </button>\n            </>\n          ) : (\n            <>\n              <button className=\"ghost\" onClick={() => goTo('/favorites')}>\n                Saved {favoriteListings.length ? `(${favoriteListings.length})` : ''}\n              </button>\n              <button className=\"ghost\" onClick={() => goTo('/alerts')}>\n                Alerts {unreadNotifications.length ? `(${unreadNotifications.length})` : ''}\n              </button>\n              <button className=\"ghost\" onClick={() => goTo('/profile')}>\n                Profile\n              </button>\n              <button className=\"ghost\" onClick={onLogout}>\n                Log out\n              </button>\n            </>\n          )}\n        </div>"""
if 'For retailers' not in s:
    s = s.replace(old_topbar, new_topbar)

route_marker = '<Route path="*" element={<Navigate to="/" replace />} />'
enterprise_route = '          <Route path="/enterprise" element={<Enterprise />} />\n\n          ' + route_marker
if '/enterprise" element={<Enterprise />}' not in s:
    s = s.replace(route_marker, enterprise_route)

app.write_text(s)

style_text = styles.read_text()
append = css_src.read_text()
if 'Clean enterprise route only' not in style_text:
    styles.write_text(style_text.rstrip() + '\n\n' + append + '\n')

print('Clean enterprise route applied.')
