import { useNavigate } from 'react-router-dom'

const signalCards = [
  {
    eyebrow: 'Local supply signals',
    title: 'See what is growing before the chain sees it.',
    copy:
      'Surface neighborhood-level fruit availability, repeat growers, crop density, and seasonal shifts that rarely appear in traditional sourcing views.',
  },
  {
    eyebrow: 'Impact and ESG',
    title: 'Turn local participation into visible proof.',
    copy:
      'Show community activation, estimated food miles avoided, local grower participation, and surplus recirculation in one clear operating view.',
  },
  {
    eyebrow: 'Customer demand',
    title: 'Understand what food-conscious local shoppers actually want.',
    copy:
      'Track search behavior, saved produce, unavailable items, and category momentum to spot demand signals before they become mainstream retail asks.',
  },
  {
    eyebrow: 'Retail pipeline',
    title: 'Bridge backyard supply to future retail opportunity.',
    copy:
      'Pluck can become the layer that translates scattered local supply and demand into trend visibility, partnership opportunities, and future sourcing intelligence.',
  },
]

const metrics = [
  { label: 'Active local growers', value: '124+' },
  { label: 'Seasonal produce categories', value: '18' },
  { label: 'Neighborhood signal zones', value: '32' },
  { label: 'Estimated low-mile pickups', value: '4.8k' },
]

export default function Enterprise() {
  const navigate = useNavigate()

  return (
    <div className="enterprise-shell" id="enterprise-shell">
      <section className="enterprise-hero">
        <div className="enterprise-kicker">Pluck for retail and grocery partners</div>
        <h2>Hyperlocal supply intelligence for the next generation of fresh food.</h2>
        <p className="enterprise-lead">
          Pluck is not just a marketplace for backyard fruit. It is a signal layer for hyperlocal supply,
          neighborhood demand, and community-scale food movement that larger retailers rarely see in time.
        </p>

        <div className="enterprise-cta-row">
          <button className="primary" onClick={() => window.alert('Partner flow coming next.')}>
            Request partner access
          </button>
          <button className="ghost" onClick={() => navigate('/')}>Back to marketplace</button>
        </div>
      </section>

      <section className="enterprise-stat-strip" aria-label="Enterprise metrics preview">
        {metrics.map((item) => (
          <article className="enterprise-stat-card" key={item.label}>
            <span>{item.label}</span>
            <strong>{item.value}</strong>
          </article>
        ))}
      </section>

      <section className="enterprise-grid">
        {signalCards.map((item) => (
          <article className="enterprise-panel" key={item.title}>
            <p className="enterprise-panel-kicker">{item.eyebrow}</p>
            <h3>{item.title}</h3>
            <p>{item.copy}</p>
          </article>
        ))}
      </section>

      <section className="enterprise-flow-card">
        <p className="enterprise-panel-kicker">Local to retail pipeline</p>
        <h3>From backyard listing to retail signal, without losing the community layer.</h3>
        <div className="enterprise-flow">
          <div className="enterprise-flow-step">
            <strong>1</strong>
            <span>Growers list produce close to where it is actually grown.</span>
          </div>
          <div className="enterprise-flow-step">
            <strong>2</strong>
            <span>Pluck detects neighborhood demand, crop momentum, and repeat activity.</span>
          </div>
          <div className="enterprise-flow-step">
            <strong>3</strong>
            <span>Retail partners gain visibility into trends, engagement, and future sourcing opportunities.</span>
          </div>
        </div>
      </section>
    </div>
  )
}
