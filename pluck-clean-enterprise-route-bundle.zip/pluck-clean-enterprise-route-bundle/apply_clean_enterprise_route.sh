#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-$(pwd)}"
python3 "$(dirname "$0")/apply_clean_enterprise_route.py" "$REPO"
