#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_DIR="/workspaces/PLUCK"
SRC="$SCRIPT_DIR/payload/client/src/styles.css"
DST="$REPO_DIR/client/src/styles.css"
if [ ! -f "$SRC" ]; then
  echo "Source stylesheet not found: $SRC" >&2
  exit 1
fi
if [ ! -d "$REPO_DIR/client/src" ]; then
  echo "Repo path not found: $REPO_DIR/client/src" >&2
  exit 1
fi
if [ -f "$DST" ]; then
  cp "$DST" "$DST.before-real-fix.bak"
fi
cp "$SRC" "$DST"
echo "PLUCK real fix applied to client/src/styles.css"
