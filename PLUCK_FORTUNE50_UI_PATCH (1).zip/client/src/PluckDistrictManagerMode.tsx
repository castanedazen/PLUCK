import React from "react";

export default function PluckDistrictManagerMode() {
  return (
    <div style={{fontFamily:"Inter, Arial", background:"#f6f8fb", minHeight:"100vh", padding:24}}>
      <div style={{maxWidth:1300, margin:"0 auto"}}>

        <div style={{
          background:"linear-gradient(135deg,#1f6d5b,#497fa6,#d5923a)",
          borderRadius:28,
          padding:36,
          color:"white",
          display:"grid",
          gridTemplateColumns:"1.2fr .8fr",
          gap:24
        }}>
          <div>
            <div style={{fontSize:64, fontWeight:900}}>
              Fill store demand with local supply in real time.
            </div>
            <div style={{marginTop:16, fontSize:20}}>
              See shortages, match nearby inventory, and execute local fill in minutes.
            </div>
          </div>

          <div style={{background:"white", color:"#102033", borderRadius:20, padding:20}}>
            <div style={{fontWeight:800}}>Store 1423 — Avocados</div>
            <div>Needed: 180 lbs</div>
            <div>Matched: 185 lbs</div>
            <div><b>100% Covered</b></div>
            <button style={{marginTop:16, width:"100%", padding:12, borderRadius:12, background:"#102033", color:"white"}}>
              Execute Local Fill
            </button>
          </div>
        </div>

        <div style={{display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:16, marginTop:20}}>
          {[
            ["Stores Covered","12"],
            ["Live Supply","4,280 lbs"],
            ["Fill Rate","92%"],
            ["Waste Reduction","$7,200"]
          ].map(([label,val])=>(
            <div key={label} style={{background:"white", padding:20, borderRadius:18}}>
              <div style={{fontSize:12}}>{label}</div>
              <div style={{fontSize:32, fontWeight:900}}>{val}</div>
            </div>
          ))}
        </div>

        <div style={{marginTop:20, background:"white", borderRadius:20, padding:16}}>
          <div style={{height:500, background:"#e6eef7", borderRadius:16, display:"flex", alignItems:"center", justifyContent:"center"}}>
            MAP
          </div>
        </div>

      </div>
    </div>
  );
}
