#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(pwd)}"
PATCH_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CLIENT_DIR="$ROOT/client"
COMP_DIR="$CLIENT_DIR/src/components/district"
STYLE_DIR="$CLIENT_DIR/src/styles"

if [ ! -d "$CLIENT_DIR" ]; then
  echo "Could not find client directory at: $CLIENT_DIR"
  echo "Run this from your PLUCK repo root or pass the repo path explicitly:"
  echo "  bash scripts/apply-one-click-demo.sh /workspaces/PLUCK"
  exit 1
fi

mkdir -p "$COMP_DIR" "$STYLE_DIR"

cp "$PATCH_DIR/client/src/components/district/FortuneDistrictExecutionDemo.tsx" "$COMP_DIR/FortuneDistrictExecutionDemo.tsx"
cp "$PATCH_DIR/client/src/styles/pluck-execution-demo.css" "$STYLE_DIR/pluck-execution-demo.css"

echo "Copied FortuneDistrictExecutionDemo.tsx + pluck-execution-demo.css into client/src."
echo

echo "Next, wire it into your district page:"
echo "  import FortuneDistrictExecutionDemo from '../components/district/FortuneDistrictExecutionDemo'"
echo "  import '../styles/pluck-execution-demo.css'   # only if your page does not already pick up component CSS imports"
echo "  <FortuneDistrictExecutionDemo />"
echo

echo "If needed, install map packages:"
echo "  cd $CLIENT_DIR && npm install react-leaflet leaflet"
