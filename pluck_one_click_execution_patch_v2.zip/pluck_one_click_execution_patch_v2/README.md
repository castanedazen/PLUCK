# PLUCK one-click execution demo patch

This patch gives your district page a buyer-facing execution demo with:

- interactive real map tiles
- `Execute Local Fill` button with state changes
- animated grower-to-store route lines
- live execution summary updates
- live coverage / matched / ETA / suppliers notified values
- national framing for PLUCK as an execution layer

## Files

- `client/src/components/district/FortuneDistrictExecutionDemo.tsx`
- `client/src/styles/pluck-execution-demo.css`
- `scripts/apply-one-click-demo.sh`

## Fastest install in Codespaces

From your extracted patch folder:

```bash
bash scripts/apply-one-click-demo.sh /workspaces/PLUCK
```

If map packages are not already installed:

```bash
cd /workspaces/PLUCK/client
npm install react-leaflet leaflet
```

## Wire into your district page

Example:

```tsx
import FortuneDistrictExecutionDemo from '../components/district/FortuneDistrictExecutionDemo';

export default function DistrictPage() {
  return <FortuneDistrictExecutionDemo />;
}
```

If your district route already has existing layout, drop the component into the hero/body region where you want the demo block to appear.

## Notes

- This patch is drag-drop friendly.
- It does not assume a specific router setup.
- It is framed nationally so the story is about district execution at scale, not just a local marketplace view.
