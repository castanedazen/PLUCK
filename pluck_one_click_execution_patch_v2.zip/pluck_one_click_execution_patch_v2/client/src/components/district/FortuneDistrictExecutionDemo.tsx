import React, { useEffect, useMemo, useState } from 'react';
import { CircleMarker, MapContainer, Marker, Pane, Polyline, Popup, TileLayer, Tooltip } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import '../../styles/pluck-execution-demo.css';

type StoreNode = {
  id: string;
  name: string;
  district: string;
  metro: string;
  lat: number;
  lng: number;
  targetDemand: number;
};

type GrowerNode = {
  id: string;
  name: string;
  state: string;
  lat: number;
  lng: number;
  category: string;
  capacity: number;
  responseMinutes: number;
};

type RouteState = {
  growerId: string;
  storeId: string;
  volume: number;
  distanceMiles: number;
  etaMinutes: number;
  priorityScore: number;
  colorBand: 'tight' | 'good' | 'wide';
};

type SummaryState = {
  coverage: string;
  matched: string;
  eta: string;
  suppliersNotified: string;
  executionLabel: string;
  narrative: string;
};

const storeIcon = new L.DivIcon({
  className: 'pluck-map-pin pluck-map-pin--store',
  html: '<div class="pluck-map-pin__inner">Store hub</div>',
  iconSize: [88, 34],
  iconAnchor: [44, 17],
});

const growerIcon = new L.DivIcon({
  className: 'pluck-map-pin pluck-map-pin--grower',
  html: '<div class="pluck-map-pin__inner">Grower</div>',
  iconSize: [80, 34],
  iconAnchor: [40, 17],
});

const stores: StoreNode[] = [
  {
    id: 'store-denver-001',
    name: 'Front Range Retail Hub',
    district: 'Mountain / Plains District',
    metro: 'Denver',
    lat: 39.7392,
    lng: -104.9903,
    targetDemand: 920,
  },
  {
    id: 'store-atl-001',
    name: 'Southeast Retail Hub',
    district: 'Southeast District',
    metro: 'Atlanta',
    lat: 33.749,
    lng: -84.388,
    targetDemand: 810,
  },
  {
    id: 'store-dal-001',
    name: 'South Central Retail Hub',
    district: 'Texas / South Central District',
    metro: 'Dallas',
    lat: 32.7767,
    lng: -96.797,
    targetDemand: 860,
  },
];

const growers: GrowerNode[] = [
  { id: 'g-ca-fresno', name: 'Fresno Valley Citrus Collective', state: 'California', lat: 36.7378, lng: -119.7871, category: 'Citrus + stone fruit', capacity: 360, responseMinutes: 4 },
  { id: 'g-wa-yakima', name: 'Yakima Orchard Network', state: 'Washington', lat: 46.6021, lng: -120.5059, category: 'Apples + pears', capacity: 290, responseMinutes: 6 },
  { id: 'g-mi-grandrapids', name: 'Lake Michigan Fruit Guild', state: 'Michigan', lat: 42.9634, lng: -85.6681, category: 'Apples + cherries', capacity: 240, responseMinutes: 5 },
  { id: 'g-ga-macon', name: 'Peach State Farm Ring', state: 'Georgia', lat: 32.8407, lng: -83.6324, category: 'Peaches + mixed produce', capacity: 180, responseMinutes: 4 },
  { id: 'g-az-phoenix', name: 'Sonoran Harvest Partners', state: 'Arizona', lat: 33.4484, lng: -112.074, category: 'Melons + specialty crops', capacity: 120, responseMinutes: 9 },
  { id: 'g-tx-austin', name: 'Hill Country Growers Exchange', state: 'Texas', lat: 30.2672, lng: -97.7431, category: 'Seasonal produce', capacity: 210, responseMinutes: 5 },
  { id: 'g-or-medford', name: 'Rogue Valley Farm Network', state: 'Oregon', lat: 42.3265, lng: -122.8756, category: 'Pears + specialty fruit', capacity: 170, responseMinutes: 7 },
  { id: 'g-fl-lakeland', name: 'Sunbelt Produce Partners', state: 'Florida', lat: 28.0395, lng: -81.9498, category: 'Citrus + mixed produce', capacity: 160, responseMinutes: 6 },
];

function toRadians(value: number) {
  return (value * Math.PI) / 180;
}

function haversineMiles(aLat: number, aLng: number, bLat: number, bLng: number) {
  const R = 3958.8;
  const dLat = toRadians(bLat - aLat);
  const dLng = toRadians(bLng - aLng);
  const lat1 = toRadians(aLat);
  const lat2 = toRadians(bLat);

  const h =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);

  return 2 * R * Math.asin(Math.sqrt(h));
}

function getRouteColor(colorBand: RouteState['colorBand']) {
  switch (colorBand) {
    case 'tight':
      return '#2563eb';
    case 'good':
      return '#0f766e';
    default:
      return '#f59e0b';
  }
}

function formatEta(totalMinutes: number) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
}

function buildRoutes(store: StoreNode, nodes: GrowerNode[]): RouteState[] {
  return nodes
    .map((grower) => {
      const distanceMiles = haversineMiles(grower.lat, grower.lng, store.lat, store.lng);
      const etaMinutes = Math.round(distanceMiles / 9.5 + grower.responseMinutes + 14);
      const priorityScore = Math.round(grower.capacity * 1.45 - etaMinutes * 0.55 - distanceMiles * 0.08);
      const colorBand: RouteState['colorBand'] = etaMinutes <= 120 ? 'tight' : etaMinutes <= 180 ? 'good' : 'wide';

      return {
        growerId: grower.id,
        storeId: store.id,
        volume: Math.min(grower.capacity, Math.round(store.targetDemand / 2.8)),
        distanceMiles: Math.round(distanceMiles),
        etaMinutes,
        priorityScore,
        colorBand,
      };
    })
    .sort((a, b) => b.priorityScore - a.priorityScore);
}

function useExecutionProgress(isExecuting: boolean) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!isExecuting) {
      setProgress(0);
      return;
    }

    const steps = [8, 15, 24, 33, 45, 56, 68, 79, 88, 95, 100];
    let idx = 0;

    const timer = window.setInterval(() => {
      setProgress(steps[idx]);
      idx += 1;
      if (idx >= steps.length) {
        window.clearInterval(timer);
      }
    }, 260);

    return () => window.clearInterval(timer);
  }, [isExecuting]);

  return progress;
}

export default function FortuneDistrictExecutionDemo() {
  const [selectedStoreId, setSelectedStoreId] = useState(stores[0].id);
  const [isExecuting, setIsExecuting] = useState(false);
  const [hasExecuted, setHasExecuted] = useState(false);
  const [summary, setSummary] = useState<SummaryState>({
    coverage: '42 districts online',
    matched: '0 suppliers matched',
    eta: 'Awaiting execution',
    suppliersNotified: '0 notified',
    executionLabel: 'Ready',
    narrative: 'PLUCK is standing by to translate national produce supply into live retail execution.',
  });

  const selectedStore = useMemo(
    () => stores.find((store) => store.id === selectedStoreId) ?? stores[0],
    [selectedStoreId],
  );

  const routes = useMemo(() => buildRoutes(selectedStore, growers), [selectedStore]);
  const progress = useExecutionProgress(isExecuting);

  const visibleRouteCount = hasExecuted
    ? Math.min(5, routes.length)
    : isExecuting
      ? Math.min(routes.length, Math.max(1, Math.ceil((progress / 100) * 5)))
      : 0;

  const topRoutes = routes.slice(0, 5);
  const totalMatchedVolume = topRoutes.reduce((sum, route) => sum + route.volume, 0);
  const averageEtaMinutes = Math.round(topRoutes.reduce((sum, route) => sum + route.etaMinutes, 0) / topRoutes.length);
  const networkCoverage = 42 + stores.length;

  useEffect(() => {
    if (!isExecuting) return;

    const matchedCount = Math.min(topRoutes.length, Math.max(1, Math.ceil((progress / 100) * topRoutes.length)));
    const notifiedCount = Math.min(growers.length, Math.max(1, Math.ceil((progress / 100) * 7)));
    const liveCoverage = `${networkCoverage} districts scanning`;
    const liveMatched = `${matchedCount} suppliers matched`;
    const liveEta = progress < 40 ? 'Calculating lanes' : formatEta(averageEtaMinutes);
    const liveNotified = `${notifiedCount} suppliers notified`;

    let narrative = 'Scanning national supply graph for high-confidence fill across district demand.';
    if (progress >= 28 && progress < 60) {
      narrative = 'Ranking suppliers by response speed, lane distance, and store-level fill fit.';
    } else if (progress >= 60 && progress < 95) {
      narrative = 'Notifying priority growers and activating supply lanes into the selected district hub.';
    } else if (progress >= 95) {
      narrative = `Execution complete. ${selectedStore.metro} is now backed by live, district-ready national fill coverage.`;
    }

    setSummary({
      coverage: liveCoverage,
      matched: liveMatched,
      eta: liveEta,
      suppliersNotified: liveNotified,
      executionLabel: progress >= 100 ? 'Executed' : 'Executing',
      narrative,
    });

    if (progress >= 100) {
      setIsExecuting(false);
      setHasExecuted(true);
    }
  }, [progress, isExecuting, topRoutes, averageEtaMinutes, selectedStore.metro, networkCoverage, growers.length]);

  const handleExecute = () => {
    setHasExecuted(false);
    setIsExecuting(true);
    setSummary({
      coverage: `${networkCoverage} districts scanning`,
      matched: '1 supplier matched',
      eta: 'Calculating lanes',
      suppliersNotified: '1 supplier notified',
      executionLabel: 'Executing',
      narrative: `Launching one-click execution for ${selectedStore.metro} using PLUCK's national grower network.`,
    });
  };

  const handleStoreChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const nextId = event.target.value;
    setSelectedStoreId(nextId);
    setIsExecuting(false);
    setHasExecuted(false);
    setSummary({
      coverage: '42 districts online',
      matched: '0 suppliers matched',
      eta: 'Awaiting execution',
      suppliersNotified: '0 notified',
      executionLabel: 'Ready',
      narrative: 'District changed. PLUCK is ready to execute a fresh national fill simulation.',
    });
  };

  return (
    <section className="pluck-exec-shell">
      <div className="pluck-exec-hero">
        <div>
          <div className="pluck-exec-eyebrow">PLUCK district execution</div>
          <h1>One click turns national grower supply into store-ready district execution.</h1>
          <p>
            This Fortune 50 demo view shows PLUCK as an execution system, not just a listing marketplace:
            live map coverage, route activation, supplier notifications, and measurable store-level fill outcomes.
          </p>
        </div>

        <div className="pluck-exec-actions">
          <label className="pluck-exec-select-wrap">
            <span>District hub</span>
            <select value={selectedStoreId} onChange={handleStoreChange} disabled={isExecuting}>
              {stores.map((store) => (
                <option key={store.id} value={store.id}>
                  {store.metro} · {store.district}
                </option>
              ))}
            </select>
          </label>

          <button
            className={`pluck-exec-button ${isExecuting ? 'is-running' : ''} ${hasExecuted ? 'is-complete' : ''}`}
            type="button"
            onClick={handleExecute}
            disabled={isExecuting}
          >
            {isExecuting ? `Executing... ${progress}%` : hasExecuted ? 'Execution Complete — Run Again' : 'Execute Local Fill'}
          </button>

          <div className="pluck-exec-microcopy">National framing · interactive map · live execution proof</div>
        </div>
      </div>

      <div className="pluck-exec-grid">
        <div className="pluck-exec-map-card">
          <div className="pluck-exec-card-head">
            <div>
              <h2>National supply execution map</h2>
              <span>{selectedStore.name} · {selectedStore.district}</span>
            </div>
            <div className="pluck-exec-kicker">Real map tiles</div>
          </div>

          <div className="pluck-exec-map-frame">
            <MapContainer center={[39.5, -98.35]} zoom={4} minZoom={3} scrollWheelZoom className="pluck-exec-map">
              <TileLayer
                attribution='&copy; OpenStreetMap contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />

              <Pane name="routes" style={{ zIndex: 450 }} />
              <Pane name="markers" style={{ zIndex: 650 }} />

              <Marker position={[selectedStore.lat, selectedStore.lng]} icon={storeIcon} pane="markers">
                <Popup>
                  <strong>{selectedStore.name}</strong>
                  <br />
                  {selectedStore.district}
                  <br />
                  Target demand: {selectedStore.targetDemand} crates
                </Popup>
              </Marker>

              {growers.map((grower) => (
                <Marker key={grower.id} position={[grower.lat, grower.lng]} icon={growerIcon} pane="markers">
                  <Tooltip direction="top" offset={[0, -12]} opacity={1}>
                    {grower.name}
                  </Tooltip>
                  <Popup>
                    <strong>{grower.name}</strong>
                    <br />
                    {grower.state}
                    <br />
                    {grower.category}
                    <br />
                    Capacity: {grower.capacity} crates
                  </Popup>
                </Marker>
              ))}

              {routes.slice(0, visibleRouteCount).map((route) => {
                const grower = growers.find((node) => node.id === route.growerId);
                if (!grower) return null;

                const progressFactor = hasExecuted ? 1 : Math.min(progress / 100, 1);
                const liveLat = grower.lat + (selectedStore.lat - grower.lat) * progressFactor;
                const liveLng = grower.lng + (selectedStore.lng - grower.lng) * progressFactor;
                const color = getRouteColor(route.colorBand);

                return (
                  <React.Fragment key={`${route.growerId}-${selectedStore.id}`}>
                    <Polyline
                      positions={[
                        [grower.lat, grower.lng],
                        [selectedStore.lat, selectedStore.lng],
                      ]}
                      pathOptions={{
                        color,
                        weight: 4,
                        opacity: 0.86,
                        dashArray: '10 12',
                        className: isExecuting ? 'pluck-route-live' : 'pluck-route-static',
                      }}
                      pane="routes"
                    />
                    <CircleMarker
                      center={[liveLat, liveLng]}
                      radius={6}
                      pathOptions={{ color, weight: 2, fillOpacity: 1 }}
                      pane="routes"
                    />
                  </React.Fragment>
                );
              })}
            </MapContainer>
          </div>
        </div>

        <aside className="pluck-exec-side-stack">
          <div className="pluck-exec-summary-card">
            <div className="pluck-exec-card-head">
              <div>
                <h2>Execution summary</h2>
                <span>Live buyer-facing proof that the network can execute now</span>
              </div>
              <div className={`pluck-status-pill ${isExecuting ? 'is-running' : hasExecuted ? 'is-complete' : ''}`}>
                {summary.executionLabel}
              </div>
            </div>

            <div className="pluck-exec-metrics">
              <div className="pluck-metric-box">
                <span>Coverage</span>
                <strong>{summary.coverage}</strong>
              </div>
              <div className="pluck-metric-box">
                <span>Matched</span>
                <strong>{summary.matched}</strong>
              </div>
              <div className="pluck-metric-box">
                <span>ETA</span>
                <strong>{summary.eta}</strong>
              </div>
              <div className="pluck-metric-box">
                <span>Suppliers notified</span>
                <strong>{summary.suppliersNotified}</strong>
              </div>
            </div>

            <div className="pluck-live-bar">
              <div className="pluck-live-bar__fill" style={{ width: `${hasExecuted ? 100 : progress}%` }} />
            </div>

            <p className="pluck-exec-narrative">{summary.narrative}</p>

            <div className="pluck-exec-footer-stats">
              <div>
                <span>Store demand</span>
                <strong>{selectedStore.targetDemand} crates</strong>
              </div>
              <div>
                <span>Matched fill</span>
                <strong>{totalMatchedVolume} crates</strong>
              </div>
            </div>
          </div>

          <div className="pluck-exec-supplier-card">
            <div className="pluck-exec-card-head">
              <div>
                <h2>Matched supplier lanes</h2>
                <span>Top national suppliers ranked for this district hub</span>
              </div>
              <div className="pluck-exec-kicker">{totalMatchedVolume} crates</div>
            </div>

            <div className="pluck-lane-list">
              {topRoutes.map((route, index) => {
                const grower = growers.find((node) => node.id === route.growerId);
                if (!grower) return null;

                const isVisible = hasExecuted || (isExecuting && index < visibleRouteCount);
                const statusLabel = hasExecuted || (isExecuting && index < visibleRouteCount)
                  ? index < 2
                    ? 'Activated'
                    : 'Queued'
                  : 'Standby';

                return (
                  <div key={`${route.growerId}-lane`} className={`pluck-lane-item ${isVisible ? 'is-visible' : ''}`}>
                    <div>
                      <strong>{grower.name}</strong>
                      <span>{grower.category} · {grower.state}</span>
                    </div>
                    <div className="pluck-lane-stats">
                      <span>{route.volume} crates</span>
                      <span>{route.distanceMiles} mi</span>
                      <span>{formatEta(route.etaMinutes)}</span>
                      <span>{statusLabel}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </aside>
      </div>
    </section>
  );
}
