#!/usr/bin/env bash
set -euo pipefail
python3 apply_pluck_nuclear_reset.py
