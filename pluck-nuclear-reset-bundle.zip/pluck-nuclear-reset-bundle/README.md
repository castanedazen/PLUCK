PLUCK Nuclear Reset Bundle

Use from /workspaces/PLUCK:
unzip -o pluck-nuclear-reset-bundle.zip
bash apply_pluck_nuclear_reset.sh
npm run dev
