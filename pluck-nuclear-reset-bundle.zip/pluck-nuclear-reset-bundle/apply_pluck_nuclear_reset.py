#!/usr/bin/env python3
from pathlib import Path
import shutil
import re

root = Path.cwd()
index_file = root / 'client' / 'index.html'
styles_file = root / 'client' / 'src' / 'styles.css'
debug_dir = root / 'client' / 'src' / 'debug'

if not index_file.exists():
    raise SystemExit('Missing client/index.html')
if not styles_file.exists():
    raise SystemExit('Missing client/src/styles.css')

debug_dir.mkdir(parents=True, exist_ok=True)

src_css = Path(__file__).parent / 'client' / 'src' / 'debug' / 'pluckNuclearReset.css'
src_js = Path(__file__).parent / 'client' / 'src' / 'debug' / 'pluckNuclearReset.ts'

dst_css = debug_dir / 'pluckNuclearReset.css'
dst_js = debug_dir / 'pluckNuclearReset.ts'

shutil.copy2(src_css, dst_css)
shutil.copy2(src_js, dst_js)

for f in [index_file, styles_file]:
    bak = Path(str(f) + '.nuclear.bak')
    if not bak.exists():
        shutil.copy2(f, bak)

index = index_file.read_text(encoding='utf-8')
index = re.sub(r"\s*<script type=\"module\">\s*import '/src/debug/pluckSurgicalUiPatch\.ts';\s*import '/src/debug/pluckSurgicalUiPatch\.css';\s*</script>\s*", "\n", index, flags=re.S)
index = re.sub(r'\s*<script type=\"module\">\s*import \"/src/debug/pluckSurgicalUiPatch\.ts\";\s*import \"/src/debug/pluckSurgicalUiPatch\.css\";\s*</script>\s*', '\n', index, flags=re.S)

inject = """  <script type=\"module\">
    import '/src/debug/pluckNuclearReset.ts';
    import '/src/debug/pluckNuclearReset.css';
  </script>
"""

if 'pluckNuclearReset.ts' not in index:
    index = index.replace('</body>', inject + '</body>')

index_file.write_text(index, encoding='utf-8')

styles = styles_file.read_text(encoding='utf-8')
marker = '/* PLUCK NUCLEAR RESET IMPORT */'
if marker not in styles:
    styles += f'\n\n{marker}\n@import \'./debug/pluckNuclearReset.css\';\n'
styles_file.write_text(styles, encoding='utf-8')

print('Applied PLUCK nuclear reset.')
print('Backups created:')
print(f' - {index_file}.nuclear.bak')
print(f' - {styles_file}.nuclear.bak')
