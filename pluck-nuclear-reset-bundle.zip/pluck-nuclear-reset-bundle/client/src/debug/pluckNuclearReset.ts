const log = (...args) => console.log('[PLUCK nuclear reset]', ...args);

function pathKey() {
  const p = location.pathname.toLowerCase();
  if (p.includes('map')) return 'map';
  if (p.includes('board')) return 'board';
  if (p.includes('message')) return 'messages';
  if (p.includes('store') || p.includes('shop')) return 'store';
  if (p.includes('profile') || p.includes('account')) return 'profile';
  return 'home';
}

function ensureRouteArt() {
  const key = pathKey();
  if (key === 'home') return;

  const existing = document.querySelector('.pluck-route-art');
  if (existing) {
    existing.className = `pluck-route-art pluck-route-art--${key}`;
    return;
  }

  const heading = Array.from(document.querySelectorAll('h1,h2')).find(el => {
    const t = (el.textContent || '').trim().toLowerCase();
    return t && (location.pathname.toLowerCase().includes(t) || ['map','board','messages','store','profile'].some(k => t.includes(k)));
  });

  const target = heading?.closest('section,div,main') || document.querySelector('main') || document.body;
  if (!target) return;

  const art = document.createElement('div');
  art.className = `pluck-route-art pluck-route-art--${key}`;
  if (target.firstChild) target.insertBefore(art, target.firstChild);
  else target.appendChild(art);
}

function normalizeHome() {
  const p = location.pathname.toLowerCase();
  if (p !== '/' && !p.includes('home')) return;

  const main = document.querySelector('main') || document.body;
  if (!main) return;

  Array.from(main.querySelectorAll('section,div')).forEach(el => {
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    if (
      rect.height > 40 &&
      rect.height < 220 &&
      style.backgroundColor &&
      /rgb\((22[0-9]|23[0-5]),\s*(22[0-9]|23[0-5]),\s*(22[0-9]|23[0-5])\)/.test(style.backgroundColor) &&
      !el.querySelector('img') &&
      !el.textContent.trim()
    ) {
      el.style.display = 'none';
    }
  });

  Array.from(main.querySelectorAll('section,div')).forEach(el => {
    const cards = el.querySelectorAll(':scope > .listing-card, :scope > .market-card, :scope > .fruit-card, :scope > .card');
    if (cards.length >= 4) {
      el.style.display = 'grid';
      el.style.gridTemplateColumns = 'repeat(4, minmax(0, 1fr))';
      el.style.gap = '18px';
      el.style.alignItems = 'stretch';
    }
  });

  const heroImg = Array.from(main.querySelectorAll('img')).find(img => {
    const rect = img.getBoundingClientRect();
    return rect.width > 700 && rect.height > 350;
  });
  if (heroImg) {
    heroImg.style.maxHeight = '360px';
    heroImg.style.width = '100%';
    heroImg.style.objectFit = 'cover';
    heroImg.style.objectPosition = 'center';
    heroImg.style.borderRadius = '26px';
  }
}

function tick() {
  ensureRouteArt();
  normalizeHome();
}

let lastPath = location.pathname;
const obs = new MutationObserver(() => {
  if (location.pathname !== lastPath) lastPath = location.pathname;
  tick();
});
obs.observe(document.documentElement, { childList: true, subtree: true });

window.addEventListener('load', tick);
window.addEventListener('popstate', tick);
setInterval(tick, 900);

log('installed');
