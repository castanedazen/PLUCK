import type { Listing } from '../types'

type LeafletMapViewProps = {
  listings: Listing[]
  onOpenListing: (listingId: string) => void
}

function buildEmbedUrl(listings: Listing[]) {
  const geoListings = listings.filter(
    (item) => typeof item.geo?.lat === 'number' && typeof item.geo?.lng === 'number',
  )

  if (!geoListings.length) return ''

  const lats = geoListings.map((item) => item.geo!.lat)
  const lngs = geoListings.map((item) => item.geo!.lng)

  const minLat = Math.min(...lats) - 1.5
  const maxLat = Math.max(...lats) + 1.5
  const minLng = Math.min(...lngs) - 1.5
  const maxLng = Math.max(...lngs) + 1.5

  return `https://www.openstreetmap.org/export/embed.html?bbox=${minLng}%2C${minLat}%2C${maxLng}%2C${maxLat}&layer=mapnik`
}

function buildOpenStreetMapLink(listing: Listing) {
  if (!listing.geo) return '#'
  return `https://www.openstreetmap.org/?mlat=${listing.geo.lat}&mlon=${listing.geo.lng}#map=13/${listing.geo.lat}/${listing.geo.lng}`
}

export function LeafletMapView({ listings, onOpenListing }: LeafletMapViewProps) {
  const geoListings = listings.filter(
    (item) => typeof item.geo?.lat === 'number' && typeof item.geo?.lng === 'number',
  )

  if (!geoListings.length) {
    return <div className="empty-panel">No geo-tagged listings yet. Add coordinates to unlock map discovery.</div>
  }

  const embedUrl = buildEmbedUrl(geoListings)

  return (
    <div className="leaflet-shell">
      <iframe
        className="leaflet-map"
        src={embedUrl}
        title="PLUCK map discovery"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      />

      <div className="map-overlay-list">
        {geoListings.slice(0, 8).map((listing) => (
          <article className="map-overlay-card" key={listing.id}>
            <div>
              <strong>{listing.title}</strong>
              <p>
                {listing.city || listing.location} • ${listing.price}/{listing.unit}
              </p>
            </div>
            <div className="map-overlay-actions">
              <button className="ghost compact-btn" onClick={() => onOpenListing(listing.id)}>
                Open listing
              </button>
              <a
                className="ghost compact-btn map-link"
                href={buildOpenStreetMapLink(listing)}
                target="_blank"
                rel="noreferrer"
              >
                Open map
              </a>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
