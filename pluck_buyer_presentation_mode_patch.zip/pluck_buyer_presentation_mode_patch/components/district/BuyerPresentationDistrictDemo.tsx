import React, { useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Polyline, Tooltip } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

type Role = 'District Manager' | 'Regional VP' | 'National Retail';
type StepKey = 'scan' | 'match' | 'execute' | 'summary';

type Node = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'grower' | 'store';
  region: string;
  capacity?: number;
};

type Scenario = {
  id: string;
  label: string;
  center: [number, number];
  zoom: number;
  roleDefaults: Record<Role, { coverage: number; matched: number; eta: number; notified: number; units: number; confidence: number }>;
  store: Node;
  growers: Node[];
};

const scenarios: Scenario[] = [
  {
    id: 'west',
    label: 'West Division · Los Angeles to Central Valley',
    center: [35.6, -119.2],
    zoom: 6,
    store: { id: 'store-west-1', name: 'Store Cluster W-14', lat: 34.0522, lng: -118.2437, type: 'store', region: 'West' },
    growers: [
      { id: 'g1', name: 'Ventura Citrus Collective', lat: 34.2746, lng: -119.229, type: 'grower', region: 'West', capacity: 1800 },
      { id: 'g2', name: 'Fresno Orchard Network', lat: 36.7378, lng: -119.7871, type: 'grower', region: 'West', capacity: 2450 },
      { id: 'g3', name: 'Bakersfield Stone Fruit Co-op', lat: 35.3733, lng: -119.0187, type: 'grower', region: 'West', capacity: 1700 },
      { id: 'g4', name: 'Santa Maria Grower Hub', lat: 34.953, lng: -120.4357, type: 'grower', region: 'West', capacity: 1150 },
    ],
    roleDefaults: {
      'District Manager': { coverage: 84, matched: 12, eta: 5, notified: 18, units: 920, confidence: 89 },
      'Regional VP': { coverage: 89, matched: 34, eta: 7, notified: 46, units: 2480, confidence: 92 },
      'National Retail': { coverage: 93, matched: 118, eta: 9, notified: 164, units: 11840, confidence: 95 },
    },
  },
  {
    id: 'south',
    label: 'South Division · Dallas / Fort Worth',
    center: [32.95, -97.1],
    zoom: 6,
    store: { id: 'store-south-1', name: 'Store Cluster S-22', lat: 32.7767, lng: -96.797, type: 'store', region: 'South' },
    growers: [
      { id: 'g5', name: 'North Texas Produce Ring', lat: 33.2148, lng: -97.1331, type: 'grower', region: 'South', capacity: 2100 },
      { id: 'g6', name: 'Tyler Farm Network', lat: 32.3513, lng: -95.3011, type: 'grower', region: 'South', capacity: 1420 },
      { id: 'g7', name: 'Waco Grower Exchange', lat: 31.5493, lng: -97.1467, type: 'grower', region: 'South', capacity: 980 },
      { id: 'g8', name: 'Sherman Fresh Group', lat: 33.6357, lng: -96.6089, type: 'grower', region: 'South', capacity: 1225 },
    ],
    roleDefaults: {
      'District Manager': { coverage: 81, matched: 10, eta: 6, notified: 16, units: 810, confidence: 87 },
      'Regional VP': { coverage: 88, matched: 28, eta: 8, notified: 41, units: 2190, confidence: 91 },
      'National Retail': { coverage: 92, matched: 106, eta: 10, notified: 150, units: 11020, confidence: 94 },
    },
  },
  {
    id: 'east',
    label: 'East Division · Mid-Atlantic corridor',
    center: [39.6, -76.7],
    zoom: 6,
    store: { id: 'store-east-1', name: 'Store Cluster E-09', lat: 39.2904, lng: -76.6122, type: 'store', region: 'East' },
    growers: [
      { id: 'g9', name: 'Lancaster Produce Farms', lat: 40.0379, lng: -76.3055, type: 'grower', region: 'East', capacity: 1680 },
      { id: 'g10', name: 'Delmarva Harvest Co-op', lat: 38.9108, lng: -75.5277, type: 'grower', region: 'East', capacity: 1380 },
      { id: 'g11', name: 'Richmond Market Growers', lat: 37.5407, lng: -77.436, type: 'grower', region: 'East', capacity: 1260 },
      { id: 'g12', name: 'South Jersey Specialty Farms', lat: 39.4273, lng: -74.4957, type: 'grower', region: 'East', capacity: 1020 },
    ],
    roleDefaults: {
      'District Manager': { coverage: 83, matched: 11, eta: 5, notified: 17, units: 870, confidence: 88 },
      'Regional VP': { coverage: 90, matched: 31, eta: 7, notified: 43, units: 2320, confidence: 92 },
      'National Retail': { coverage: 94, matched: 114, eta: 9, notified: 158, units: 11690, confidence: 95 },
    },
  },
];

const steps: { key: StepKey; label: string; description: string }[] = [
  { key: 'scan', label: 'Market Scan', description: 'Live district capacity and store exposure analyzed.' },
  { key: 'match', label: 'Supplier Match', description: 'Highest-confidence growers prioritized by speed and capacity.' },
  { key: 'execute', label: 'Store Execution', description: 'Fill order launched to store cluster and supplier network.' },
  { key: 'summary', label: 'Value Summary', description: 'Executive-level fulfillment confidence and recovery impact ready.' },
];

function animateValue(target: number, duration = 850) {
  return { target, duration };
}

export default function BuyerPresentationDistrictDemo() {
  const [role, setRole] = useState<Role>('District Manager');
  const [scenarioId, setScenarioId] = useState<string>(scenarios[0].id);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeStep, setActiveStep] = useState<StepKey>('scan');
  const [executed, setExecuted] = useState(false);
  const [coverage, setCoverage] = useState(38);
  const [matched, setMatched] = useState(0);
  const [eta, setEta] = useState(0);
  const [notified, setNotified] = useState(0);
  const [units, setUnits] = useState(0);
  const [confidence, setConfidence] = useState(0);
  const [summaryText, setSummaryText] = useState('Ready to demonstrate district-level execution across the PLUCK network.');
  const timers = useRef<number[]>([]);

  const scenario = useMemo(() => scenarios.find((s) => s.id === scenarioId) || scenarios[0], [scenarioId]);
  const targets = scenario.roleDefaults[role];

  const clearTimers = () => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
  };

  const resetToIdle = () => {
    clearTimers();
    setIsPlaying(false);
    setExecuted(false);
    setActiveStep('scan');
    setCoverage(38);
    setMatched(0);
    setEta(0);
    setNotified(0);
    setUnits(0);
    setConfidence(0);
    setSummaryText('Ready to demonstrate district-level execution across the PLUCK network.');
  };

  useEffect(() => {
    resetToIdle();
    return clearTimers;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role, scenarioId]);

  const stagedSet = (delay: number, fn: () => void) => {
    const id = window.setTimeout(fn, delay);
    timers.current.push(id);
  };

  const runDemo = () => {
    resetToIdle();
    setIsPlaying(true);
    setSummaryText('Scanning district supply, store demand, and recoverable local inventory.');

    stagedSet(350, () => {
      setActiveStep('scan');
      setCoverage(Math.max(64, Math.round(targets.coverage * 0.78)));
      setMatched(Math.round(targets.matched * 0.18));
      setSummaryText('Market scan complete. Nearby growers and store risk surfaced in real time.');
    });

    stagedSet(1400, () => {
      setActiveStep('match');
      setCoverage(Math.max(72, Math.round(targets.coverage * 0.9)));
      setMatched(Math.round(targets.matched * 0.62));
      setNotified(Math.round(targets.notified * 0.55));
      setEta(Math.max(3, Math.round(targets.eta * 0.7)));
      setSummaryText('Top growers matched by capacity, distance, and execution speed.');
    });

    stagedSet(2500, () => {
      setActiveStep('execute');
      setCoverage(targets.coverage);
      setMatched(targets.matched);
      setNotified(targets.notified);
      setEta(targets.eta);
      setUnits(Math.round(targets.units * 0.72));
      setConfidence(Math.round(targets.confidence * 0.82));
      setSummaryText('Execute Local Fill triggered. Supplier notifications and store handoff are underway.');
    });

    stagedSet(3600, () => {
      setActiveStep('summary');
      setExecuted(true);
      setCoverage(targets.coverage);
      setMatched(targets.matched);
      setNotified(targets.notified);
      setEta(targets.eta);
      setUnits(targets.units);
      setConfidence(targets.confidence);
      setSummaryText('District execution completed. PLUCK is now showing enterprise-grade supply response across stores, growers, and regional inventory.');
      setIsPlaying(false);
    });
  };

  const visibleRoutes = useMemo(() => {
    if (activeStep === 'scan') return [] as Node[];
    if (activeStep === 'match') return scenario.growers.slice(0, 2);
    if (activeStep === 'execute') return scenario.growers.slice(0, 3);
    return scenario.growers;
  }, [activeStep, scenario]);

  const buttonLabel = isPlaying ? 'Executing…' : executed ? 'Fill Executed' : 'Execute Local Fill';

  return (
    <section className="pluck-buyer-demo">
      <div className="pluck-buyer-demo__hero">
        <div>
          <div className="pluck-buyer-demo__eyebrow">PLUCK · Enterprise District Execution</div>
          <h1>One click to show how PLUCK executes local fill at district, regional, and national scale.</h1>
          <p>
            A guided executive story that turns live map intelligence into supplier match, store execution,
            and quantified retail readiness.
          </p>
        </div>
        <div className="pluck-buyer-demo__hero-actions">
          <button className="pluck-buyer-demo__primary" onClick={runDemo} disabled={isPlaying}>
            {buttonLabel}
          </button>
          <button className="pluck-buyer-demo__ghost" onClick={resetToIdle}>
            Reset Demo
          </button>
        </div>
      </div>

      <div className="pluck-buyer-demo__controls">
        <div className="pluck-buyer-demo__control-group">
          <label>Buyer Mode</label>
          <div className="pluck-buyer-demo__chips">
            {(['District Manager', 'Regional VP', 'National Retail'] as Role[]).map((item) => (
              <button
                key={item}
                className={item === role ? 'is-active' : ''}
                onClick={() => setRole(item)}
                type="button"
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        <div className="pluck-buyer-demo__control-group">
          <label>Division</label>
          <div className="pluck-buyer-demo__chips">
            {scenarios.map((item) => (
              <button
                key={item.id}
                className={item.id === scenarioId ? 'is-active' : ''}
                onClick={() => setScenarioId(item.id)}
                type="button"
              >
                {item.label.split('·')[0].trim()}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="pluck-buyer-demo__grid">
        <div className="pluck-buyer-demo__map-wrap">
          <div className="pluck-buyer-demo__map-header">
            <div>
              <strong>{scenario.label}</strong>
              <span>{role} view · live district execution narrative</span>
            </div>
            <div className="pluck-buyer-demo__status">{steps.find((s) => s.key === activeStep)?.label}</div>
          </div>

          <MapContainer center={scenario.center} zoom={scenario.zoom} scrollWheelZoom className="pluck-buyer-demo__map">
            <TileLayer
              attribution='&copy; OpenStreetMap contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            <CircleMarker
              center={[scenario.store.lat, scenario.store.lng]}
              radius={12}
              pathOptions={{ color: '#0f172a', fillColor: '#f59e0b', fillOpacity: 0.95, weight: 2 }}
            >
              <Tooltip direction="top" offset={[0, -10]} opacity={1}>
                <div>
                  <strong>{scenario.store.name}</strong>
                  <div>Store execution target</div>
                </div>
              </Tooltip>
            </CircleMarker>

            {scenario.growers.map((grower, idx) => {
              const isVisible = visibleRoutes.some((v) => v.id === grower.id);
              return (
                <React.Fragment key={grower.id}>
                  <CircleMarker
                    center={[grower.lat, grower.lng]}
                    radius={isVisible ? 9 : 7}
                    pathOptions={{
                      color: isVisible ? '#16a34a' : '#94a3b8',
                      fillColor: isVisible ? '#22c55e' : '#cbd5e1',
                      fillOpacity: isVisible ? 0.9 : 0.55,
                      weight: 2,
                    }}
                  >
                    <Tooltip direction="top" offset={[0, -6]} opacity={1}>
                      <div>
                        <strong>{grower.name}</strong>
                        <div>{grower.capacity} units available</div>
                      </div>
                    </Tooltip>
                  </CircleMarker>

                  {isVisible && (
                    <Polyline
                      positions={[
                        [grower.lat, grower.lng],
                        [scenario.store.lat, scenario.store.lng],
                      ]}
                      pathOptions={{
                        color: idx % 2 === 0 ? '#f59e0b' : '#2563eb',
                        weight: 4,
                        opacity: 0.9,
                        dashArray: activeStep === 'summary' ? undefined : '10 10',
                      }}
                    />
                  )}
                </React.Fragment>
              );
            })}
          </MapContainer>
        </div>

        <aside className="pluck-buyer-demo__side">
          <div className="pluck-buyer-demo__story-card">
            <div className="pluck-buyer-demo__story-head">Executive Storyline</div>
            <div className="pluck-buyer-demo__steps">
              {steps.map((step, index) => {
                const isCurrent = step.key === activeStep;
                const isDone = steps.findIndex((s) => s.key === activeStep) > index;
                return (
                  <div key={step.key} className={`pluck-buyer-demo__step ${isCurrent ? 'is-current' : ''} ${isDone ? 'is-done' : ''}`}>
                    <div className="pluck-buyer-demo__step-index">{index + 1}</div>
                    <div>
                      <strong>{step.label}</strong>
                      <p>{step.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="pluck-buyer-demo__summary">{summaryText}</div>
          </div>

          <div className="pluck-buyer-demo__kpis">
            <KpiCard label="Coverage" value={`${coverage}%`} hint="district supply coverage" />
            <KpiCard label="Matched" value={`${matched}`} hint="qualified grower matches" />
            <KpiCard label="ETA" value={eta ? `${eta}h` : '—'} hint="average fulfillment speed" />
            <KpiCard label="Suppliers Notified" value={`${notified}`} hint="network actions launched" />
            <KpiCard label="Units Secured" value={`${units}`} hint="recoverable local inventory" />
            <KpiCard label="Confidence" value={`${confidence}%`} hint="store execution readiness" />
          </div>

          <div className="pluck-buyer-demo__bottom-card">
            <div className="pluck-buyer-demo__bottom-row"><span>Store clusters covered</span><strong>{role === 'District Manager' ? '14' : role === 'Regional VP' ? '48' : '182'}</strong></div>
            <div className="pluck-buyer-demo__bottom-row"><span>Grower network in scope</span><strong>{role === 'District Manager' ? '62' : role === 'Regional VP' ? '184' : '860+'}</strong></div>
            <div className="pluck-buyer-demo__bottom-row"><span>Execution posture</span><strong>{executed ? 'Live' : 'Ready'}</strong></div>
          </div>
        </aside>
      </div>
    </section>
  );
}

function KpiCard({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="pluck-buyer-demo__kpi-card">
      <div className="pluck-buyer-demo__kpi-label">{label}</div>
      <div className="pluck-buyer-demo__kpi-value">{value}</div>
      <div className="pluck-buyer-demo__kpi-hint">{hint}</div>
    </div>
  );
}
