#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/PLUCK}"
CLIENT="$ROOT/client"
SRC="$CLIENT/src"
PATCH_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COMP_SRC="$PATCH_ROOT/components/district/BuyerPresentationDistrictDemo.tsx"
CSS_SRC="$PATCH_ROOT/styles/pluck-buyer-presentation-demo.css"

if [ ! -d "$ROOT" ] || [ ! -d "$CLIENT" ] || [ ! -d "$SRC" ]; then
  echo "Could not find expected PLUCK client source at: $SRC"
  exit 1
fi

mkdir -p "$SRC/components/district" "$SRC/styles"
cp "$COMP_SRC" "$SRC/components/district/BuyerPresentationDistrictDemo.tsx"
cp "$CSS_SRC" "$SRC/styles/pluck-buyer-presentation-demo.css"

APP_FILE=""
for candidate in \
  "$SRC/pages/district/index.tsx" \
  "$SRC/pages/district.tsx" \
  "$SRC/pages/District.tsx" \
  "$SRC/routes/district.tsx" \
  "$SRC/routes/District.tsx" \
  "$SRC/App.tsx"; do
  if [ -f "$candidate" ]; then
    APP_FILE="$candidate"
    break
  fi
done

if [ -z "$APP_FILE" ]; then
  APP_FILE=$(find "$SRC" -maxdepth 4 \( -iname '*district*.tsx' -o -iname 'App.tsx' \) | head -n 1 || true)
fi

if [ -z "$APP_FILE" ] || [ ! -f "$APP_FILE" ]; then
  echo "Could not find district page or App.tsx to patch."
  echo "Files copied into client/src/components/district and client/src/styles."
  exit 1
fi

cp "$APP_FILE" "$APP_FILE.buyer-demo.bak"

python3 - <<PY
from pathlib import Path
path = Path(r'''$APP_FILE''')
text = path.read_text()
component_import = "import BuyerPresentationDistrictDemo from './components/district/BuyerPresentationDistrictDemo';"
css_import = "import './styles/pluck-buyer-presentation-demo.css';"

# relative import correction based on target file location
rel_comp = Path('client/src/components/district/BuyerPresentationDistrictDemo.tsx')
rel_css = Path('client/src/styles/pluck-buyer-presentation-demo.css')
base = path.parent
root = Path(r'''$ROOT''')
actual_comp = Path(r'''$SRC/components/district/BuyerPresentationDistrictDemo.tsx''')
actual_css = Path(r'''$SRC/styles/pluck-buyer-presentation-demo.css''')

def rel_import(frm, to):
    rel = Path(to).relative_to(root) if False else None
    import os
    rp = os.path.relpath(str(to), str(frm))
    rp = rp.replace('\\\\','/')
    if not rp.startswith('.'):
        rp = './' + rp
    rp = rp[:-4] if rp.endswith('.tsx') else rp
    rp = rp[:-4] if rp.endswith('.css') else rp
    return rp

component_import = f"import BuyerPresentationDistrictDemo from '{rel_import(base, actual_comp)}';"
css_import = f"import '{rel_import(base, actual_css)}';"

if 'BuyerPresentationDistrictDemo' not in text:
    import_lines = []
    lines = text.splitlines()
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith('import '):
            insert_at = i + 1
    lines.insert(insert_at, component_import)
    lines.insert(insert_at + 1, css_import)
    text = '\n'.join(lines)

if '<BuyerPresentationDistrictDemo />' not in text:
    if 'return (' in text:
        text = text.replace('return (', 'return (\n    <BuyerPresentationDistrictDemo />\n    <>', 1)
        last = text.rfind(');')
        if last != -1:
            text = text[:last] + '    </>\n' + text[last:]
    else:
        # fallback: append component export wrapper note in a comment
        text += '\n\n/* BuyerPresentationDistrictDemo copied but could not auto-render safely. */\n'

path.write_text(text)
print(f'Patched: {path}')
PY

if [ -f "$CLIENT/package.json" ]; then
  cd "$CLIENT"
  if ! grep -q '"react-leaflet"' package.json; then npm install react-leaflet leaflet; fi
fi

echo "Buyer presentation mode installed."
echo "Patched file: $APP_FILE"
echo "Backup file: $APP_FILE.buyer-demo.bak"
