# PLUCK Buyer Presentation Mode Patch

This patch adds a guided executive buyer mode on top of your district demo.

## Adds
- Buyer-mode toggle: District Manager / Regional VP / National Retail
- Guided story flow: Market Scan → Supplier Match → Store Execution → Value Summary
- Interactive map with live grower-to-store routes
- One-click Execute Local Fill button
- Live KPI updates for coverage, matched, ETA, suppliers notified, units secured, confidence
- National enterprise framing

## Fast install in Codespaces

```bash
cd /path/to/pluck_buyer_presentation_mode_patch
bash scripts/apply-buyer-presentation-mode.sh /workspaces/PLUCK
```

Then restart frontend if needed:

```bash
cd /workspaces/PLUCK/client
npm run dev -- --host 0.0.0.0
```

## What the script does
- Copies component into `client/src/components/district`
- Copies CSS into `client/src/styles`
- Tries to find your district page or `App.tsx`
- Tries to add imports automatically
- Tries to render the component automatically
- Creates a backup of the patched file before changing it
- Installs `react-leaflet` and `leaflet` if they are missing

## Backup
The script creates a `.buyer-demo.bak` file next to the file it patches.

## If you want to restore
Delete the patched file and restore the `.buyer-demo.bak` copy.
