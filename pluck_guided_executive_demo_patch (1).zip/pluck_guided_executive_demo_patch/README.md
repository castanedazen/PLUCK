# PLUCK Guided Executive Demo Mode Patch

This patch adds a boardroom-style guided demo for the Fortune 50 district experience.

## Includes
- Interactive real map integration with Leaflet / OpenStreetMap
- Guided executive flow: Market Scan -> Supplier Match -> Store Execution
- One-click launch button with state transitions
- Animated grower-to-store route lines
- Live execution summary metrics
- National district framing with multiple district presets

## Fast install in Codespaces

```bash
cd /path/to/extracted/pluck_guided_executive_demo_patch
bash scripts/apply-guided-executive-demo.sh /workspaces/PLUCK
cd /workspaces/PLUCK/client
npm install react-leaflet leaflet
```

## Wire into district page

Example import:

```tsx
import '../../styles/pluck-guided-exec-demo.css';
import GuidedExecutiveDistrictDemo from '../../components/district/GuidedExecutiveDistrictDemo';
```

Example render:

```tsx
<GuidedExecutiveDistrictDemo />
```

## What this is for
This is meant to feel like an executive-guided sales demo, not a local toy prototype. It is built to support national retail / enterprise positioning.
