#!/usr/bin/env bash
set -euo pipefail

TARGET_ROOT="${1:-/workspaces/PLUCK}"
CLIENT_ROOT="$TARGET_ROOT/client"
COMPONENT_DIR="$CLIENT_ROOT/src/components/district"
STYLE_DIR="$CLIENT_ROOT/src/styles"

if [ ! -d "$CLIENT_ROOT" ]; then
  echo "Client folder not found at: $CLIENT_ROOT"
  exit 1
fi

mkdir -p "$COMPONENT_DIR" "$STYLE_DIR"
cp "$(dirname "$0")/../components/district/GuidedExecutiveDistrictDemo.tsx" "$COMPONENT_DIR/GuidedExecutiveDistrictDemo.tsx"
cp "$(dirname "$0")/../styles/pluck-guided-exec-demo.css" "$STYLE_DIR/pluck-guided-exec-demo.css"

cat <<MSG
Patch copied.

Next:
1) Ensure packages are installed:
   cd "$CLIENT_ROOT"
   npm install react-leaflet leaflet

2) Import in your district page:
   import '../../styles/pluck-guided-exec-demo.css';
   import GuidedExecutiveDistrictDemo from '../../components/district/GuidedExecutiveDistrictDemo';

3) Render:
   <GuidedExecutiveDistrictDemo />

If your district file lives elsewhere, adjust the import paths accordingly.
MSG
