import React, { useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, Marker, Polyline, TileLayer, Tooltip, CircleMarker } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const storeIcon = new L.DivIcon({
  className: 'pluck-store-icon',
  html: `<div class="pluck-store-dot"><span></span></div>`,
  iconSize: [24, 24],
  iconAnchor: [12, 12],
});

const growerIcon = new L.DivIcon({
  className: 'pluck-grower-icon',
  html: `<div class="pluck-grower-dot"><span></span></div>`,
  iconSize: [18, 18],
  iconAnchor: [9, 9],
});

type StageKey = 'scan' | 'match' | 'execute';

type DistrictConfig = {
  id: string;
  name: string;
  region: string;
  nationalRank: string;
  store: { name: string; lat: number; lng: number };
  growers: Array<{ id: string; name: string; lat: number; lng: number; capacity: string }>;
  targets: {
    scanCoverage: number;
    matched: number;
    eta: number;
    notified: number;
    units: number;
    confidence: number;
  };
};

const DISTRICTS: DistrictConfig[] = [
  {
    id: 'west-01',
    name: 'Pacific Fresh District',
    region: 'Western Region',
    nationalRank: 'Top 5 district response lane',
    store: { name: 'Los Angeles Flagship Store', lat: 34.0522, lng: -118.2437 },
    growers: [
      { id: 'g1', name: 'Ventura Citrus Co-op', lat: 34.2805, lng: -119.2945, capacity: '12.4k lbs' },
      { id: 'g2', name: 'Bakersfield Valley Growers', lat: 35.3733, lng: -119.0187, capacity: '18.1k lbs' },
      { id: 'g3', name: 'Salinas Premium Fields', lat: 36.6777, lng: -121.6555, capacity: '21.6k lbs' },
      { id: 'g4', name: 'Fresno Orchard Network', lat: 36.7378, lng: -119.7871, capacity: '16.9k lbs' },
    ],
    targets: { scanCoverage: 92, matched: 34, eta: 6, notified: 41, units: 18600, confidence: 97 },
  },
  {
    id: 'central-02',
    name: 'Heartland District',
    region: 'Central Region',
    nationalRank: 'Top 10 replenishment corridor',
    store: { name: 'Dallas Metro Store Cluster', lat: 32.7767, lng: -96.797 },
    growers: [
      { id: 'g1', name: 'Tyler Orchard Alliance', lat: 32.3513, lng: -95.3011, capacity: '10.2k lbs' },
      { id: 'g2', name: 'Waco Fresh Collective', lat: 31.5493, lng: -97.1467, capacity: '9.7k lbs' },
      { id: 'g3', name: 'College Station Harvest Group', lat: 30.6279, lng: -96.3344, capacity: '11.8k lbs' },
      { id: 'g4', name: 'North Texas Grower Pool', lat: 33.2148, lng: -97.1331, capacity: '15.3k lbs' },
    ],
    targets: { scanCoverage: 88, matched: 27, eta: 8, notified: 33, units: 14900, confidence: 94 },
  },
  {
    id: 'east-03',
    name: 'Atlantic Market District',
    region: 'Eastern Region',
    nationalRank: 'Fastest store-fill pilot lane',
    store: { name: 'Atlanta Regional Hub Store', lat: 33.749, lng: -84.388 },
    growers: [
      { id: 'g1', name: 'Macon Produce Exchange', lat: 32.8407, lng: -83.6324, capacity: '8.4k lbs' },
      { id: 'g2', name: 'Athens Greenhouse Group', lat: 33.9519, lng: -83.3576, capacity: '7.8k lbs' },
      { id: 'g3', name: 'Augusta Orchard Network', lat: 33.4735, lng: -82.0105, capacity: '13.6k lbs' },
      { id: 'g4', name: 'Savannah Coastal Farms', lat: 32.0809, lng: -81.0912, capacity: '9.9k lbs' },
    ],
    targets: { scanCoverage: 90, matched: 29, eta: 7, notified: 36, units: 16100, confidence: 95 },
  },
];

const STAGES: Array<{ key: StageKey; label: string; durationMs: number; headline: string; detail: string }> = [
  {
    key: 'scan',
    label: 'Market Scan',
    durationMs: 2600,
    headline: 'National inventory scan initiated',
    detail: 'PLUCK reads district-level supply, store demand, and grower availability in one executive view.',
  },
  {
    key: 'match',
    label: 'Supplier Match',
    durationMs: 2600,
    headline: 'Best-fit growers routed to store demand',
    detail: 'Priority growers are ranked by readiness, distance, response probability, and district fill impact.',
  },
  {
    key: 'execute',
    label: 'Store Execution',
    durationMs: 2800,
    headline: 'Execution package pushed to district operators',
    detail: 'Suppliers are notified, ETA windows lock in, and store-level confidence updates live for leadership.',
  },
];

function animateNumber(current: number, target: number, factor: number) {
  if (current === target) return current;
  const delta = target - current;
  const step = Math.max(1, Math.ceil(Math.abs(delta) / factor));
  return current + Math.sign(delta) * step;
}

export default function GuidedExecutiveDistrictDemo() {
  const [districtId, setDistrictId] = useState(DISTRICTS[0].id);
  const district = useMemo(() => DISTRICTS.find((d) => d.id === districtId) ?? DISTRICTS[0], [districtId]);

  const [isRunning, setIsRunning] = useState(false);
  const [stageIndex, setStageIndex] = useState(0);
  const [executionState, setExecutionState] = useState<'ready' | 'running' | 'complete'>('ready');
  const [summary, setSummary] = useState({
    coverage: 0,
    matched: 0,
    eta: 0,
    notified: 0,
    units: 0,
    confidence: 0,
  });

  const timers = useRef<number[]>([]);

  const resetTimers = () => {
    timers.current.forEach((timer) => window.clearTimeout(timer));
    timers.current = [];
  };

  const resetDemo = () => {
    resetTimers();
    setIsRunning(false);
    setStageIndex(0);
    setExecutionState('ready');
    setSummary({ coverage: 0, matched: 0, eta: 0, notified: 0, units: 0, confidence: 0 });
  };

  useEffect(() => resetDemo(), [districtId]);

  useEffect(() => {
    if (executionState !== 'running') return;

    const interval = window.setInterval(() => {
      setSummary((prev) => ({
        coverage: Math.min(district.targets.scanCoverage, animateNumber(prev.coverage, district.targets.scanCoverage, 10)),
        matched: Math.min(district.targets.matched, animateNumber(prev.matched, district.targets.matched, 9)),
        eta: Math.min(district.targets.eta, animateNumber(prev.eta, district.targets.eta, 7)),
        notified: Math.min(district.targets.notified, animateNumber(prev.notified, district.targets.notified, 9)),
        units: Math.min(district.targets.units, animateNumber(prev.units, district.targets.units, 10)),
        confidence: Math.min(district.targets.confidence, animateNumber(prev.confidence, district.targets.confidence, 10)),
      }));
    }, 180);

    return () => window.clearInterval(interval);
  }, [district, executionState]);

  const beginGuidedDemo = () => {
    resetDemo();
    setIsRunning(true);
    setExecutionState('running');

    let elapsed = 0;
    STAGES.forEach((stage, index) => {
      const timer = window.setTimeout(() => {
        setStageIndex(index);
      }, elapsed);
      timers.current.push(timer);
      elapsed += stage.durationMs;
    });

    const finish = window.setTimeout(() => {
      setStageIndex(STAGES.length - 1);
      setIsRunning(false);
      setExecutionState('complete');
    }, elapsed + 300);
    timers.current.push(finish);
  };

  useEffect(() => () => resetTimers(), []);

  const activeStage = STAGES[stageIndex];
  const visibleRoutes = executionState === 'ready' ? 0 : stageIndex === 0 ? 1 : stageIndex === 1 ? 3 : district.growers.length;
  const visibleGrowers = executionState === 'ready' ? 2 : stageIndex === 0 ? 3 : district.growers.length;

  const heroButtonLabel = executionState === 'ready' ? 'Launch Executive Guided Demo' : executionState === 'running' ? 'Executing District Flow…' : 'District Flow Complete';

  return (
    <section className="pluck-exec-shell">
      <div className="pluck-exec-hero">
        <div>
          <p className="pluck-kicker">Fortune 50 District Execution Mode</p>
          <h1>Show buyers how PLUCK turns regional supply into store-ready execution.</h1>
          <p className="pluck-subcopy">
            A guided, boardroom-grade demo for national retail, district operators, and enterprise partners.
            One click walks leadership through scan, match, and execution using a live map and district metrics.
          </p>
        </div>
        <div className="pluck-hero-actions">
          <select
            className="pluck-select"
            value={districtId}
            onChange={(e) => setDistrictId(e.target.value)}
          >
            {DISTRICTS.map((option) => (
              <option key={option.id} value={option.id}>
                {option.name} · {option.region}
              </option>
            ))}
          </select>
          <button
            className={`pluck-exec-button ${executionState}`}
            onClick={beginGuidedDemo}
            disabled={executionState === 'running'}
          >
            {heroButtonLabel}
          </button>
          <button className="pluck-reset-button" onClick={resetDemo}>
            Reset Demo
          </button>
        </div>
      </div>

      <div className="pluck-top-stats">
        <article>
          <span>District</span>
          <strong>{district.name}</strong>
          <small>{district.nationalRank}</small>
        </article>
        <article>
          <span>Store Network</span>
          <strong>148 stores</strong>
          <small>Nationally available in enterprise mode</small>
        </article>
        <article>
          <span>Grower Network</span>
          <strong>4,200+ growers</strong>
          <small>District routed in real time</small>
        </article>
        <article>
          <span>Execution Mode</span>
          <strong>{activeStage.label}</strong>
          <small>{executionState === 'complete' ? 'Ready for buyer close' : 'Guided narrative active'}</small>
        </article>
      </div>

      <div className="pluck-exec-grid">
        <div className="pluck-map-card">
          <div className="pluck-card-head">
            <div>
              <p className="pluck-card-kicker">Live district map</p>
              <h2>{district.region} supply routing</h2>
            </div>
            <span className={`pluck-status-pill ${executionState}`}>{executionState}</span>
          </div>

          <MapContainer
            center={[district.store.lat, district.store.lng]}
            zoom={6}
            scrollWheelZoom={true}
            className="pluck-map"
          >
            <TileLayer
              attribution='&copy; OpenStreetMap contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            <Marker position={[district.store.lat, district.store.lng]} icon={storeIcon}>
              <Tooltip direction="top" offset={[0, -10]} permanent>
                {district.store.name}
              </Tooltip>
            </Marker>

            {district.growers.slice(0, visibleGrowers).map((grower, idx) => (
              <React.Fragment key={grower.id}>
                <Marker position={[grower.lat, grower.lng]} icon={growerIcon}>
                  <Tooltip>
                    {grower.name} · {grower.capacity}
                  </Tooltip>
                </Marker>
                {executionState !== 'ready' && (
                  <CircleMarker
                    center={[grower.lat, grower.lng]}
                    radius={executionState === 'complete' || idx < visibleRoutes ? 14 : 8}
                    pathOptions={{ className: executionState === 'complete' || idx < visibleRoutes ? 'pluck-pulse-circle active' : 'pluck-pulse-circle' }}
                  />
                )}
              </React.Fragment>
            ))}

            {district.growers.slice(0, visibleRoutes).map((grower, idx) => (
              <Polyline
                key={`${grower.id}-route`}
                positions={[
                  [grower.lat, grower.lng],
                  [district.store.lat, district.store.lng],
                ]}
                pathOptions={{ className: `pluck-route-line stage-${idx + 1}` }}
              />
            ))}
          </MapContainer>
        </div>

        <div className="pluck-side-panel">
          <div className="pluck-stage-card">
            <p className="pluck-card-kicker">Guided executive narrative</p>
            <h3>{activeStage.headline}</h3>
            <p>{activeStage.detail}</p>

            <div className="pluck-stage-list">
              {STAGES.map((stage, index) => {
                const state = index < stageIndex ? 'done' : index === stageIndex ? 'active' : 'upcoming';
                return (
                  <div key={stage.key} className={`pluck-stage-row ${state}`}>
                    <div className="pluck-stage-index">0{index + 1}</div>
                    <div>
                      <strong>{stage.label}</strong>
                      <span>{stage.detail}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pluck-summary-card">
            <div className="pluck-card-head compact">
              <div>
                <p className="pluck-card-kicker">Execution summary</p>
                <h3>Live district KPIs</h3>
              </div>
            </div>

            <div className="pluck-summary-grid">
              <div>
                <span>Coverage</span>
                <strong>{summary.coverage}%</strong>
              </div>
              <div>
                <span>Matched</span>
                <strong>{summary.matched}</strong>
              </div>
              <div>
                <span>ETA</span>
                <strong>{summary.eta} hrs</strong>
              </div>
              <div>
                <span>Suppliers notified</span>
                <strong>{summary.notified}</strong>
              </div>
              <div>
                <span>Units secured</span>
                <strong>{summary.units.toLocaleString()}</strong>
              </div>
              <div>
                <span>Store readiness</span>
                <strong>{summary.confidence}%</strong>
              </div>
            </div>
          </div>

          <div className="pluck-close-card">
            <p className="pluck-card-kicker">Why this closes deals</p>
            <ul>
              <li>Shows national retail framing instead of a local mockup.</li>
              <li>Demonstrates action, not just analytics.</li>
              <li>Turns grower supply into district-ready operator decisions in one screen.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
