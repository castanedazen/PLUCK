from pathlib import Path
import shutil
import re

root = Path('.').resolve()
index = root / 'client' / 'index.html'
main = root / 'client' / 'src' / 'main.tsx'
styles = root / 'client' / 'src' / 'styles.css'
debug_dir = root / 'client' / 'src' / 'debug'
debug_dir.mkdir(parents=True, exist_ok=True)

src_ts = root / 'client' / 'src' / 'debug' / 'pluckHardReset.ts'
src_css = root / 'client' / 'src' / 'debug' / 'pluckHardReset.css'

if index.exists():
    shutil.copy2(index, root / 'client' / 'index.html.hardreset.bak')
if main.exists():
    shutil.copy2(main, root / 'client' / 'src' / 'main.tsx.hardreset.bak')
if styles.exists():
    shutil.copy2(styles, root / 'client' / 'src' / 'styles.css.hardreset.bak')

def strip_old(text: str) -> str:
    patterns = [
        r"\n?<script type=\"module\">\s*import '/src/debug/pluckSurgicalUiPatch\.ts';\s*import '/src/debug/pluckSurgicalUiPatch\.css';\s*</script>\s*",
        r"\n?\s*import './debug/pluckSurgicalUiPatch\.css';",
        r"\n?\s*import './debug/pluckSurgicalUiPatch';",
        r"\n?<script type=\"module\">\s*import '/src/debug/pluckNuclearReset\.ts';\s*import '/src/debug/pluckNuclearReset\.css';\s*</script>\s*",
        r"\n?\s*@import\s+['\"]\./debug/pluckNuclearReset\.css['\"]\s*;",
        r"\n?\s*@import\s+['\"]\./debug/pluckHardReset\.css['\"]\s*;",
    ]
    for p in patterns:
        text = re.sub(p, "\n", text, flags=re.MULTILINE)
    return text

if index.exists():
    txt = strip_old(index.read_text())
    snippet = '\n<script type="module">\n  import \'/src/debug/pluckHardReset.ts\';\n  import \'/src/debug/pluckHardReset.css\';\n</script>\n'
    if "/src/debug/pluckHardReset.ts" not in txt:
        txt = txt.replace('</head>', f'{snippet}</head>')
    index.write_text(txt)

if main.exists():
    txt = strip_old(main.read_text())
    main.write_text(txt)

if styles.exists():
    txt = strip_old(styles.read_text())
    if "./debug/pluckHardReset.css" not in txt:
        txt = f"@import './debug/pluckHardReset.css';\n" + txt
    styles.write_text(txt)

print('PLUCK hard reset applied successfully.')