const bannerId = 'pluck-hard-banner';

function routeName() {
  const p = (location.pathname || '/').toLowerCase();
  if (p.includes('map')) return 'map';
  if (p.includes('board')) return 'board';
  if (p.includes('message')) return 'messages';
  if (p.includes('store') || p.includes('shop')) return 'store';
  if (p.includes('profile') || p.includes('account')) return 'profile';
  return 'home';
}

function svgFor(kind: string) {
  const commonStart = `<svg viewBox="0 0 1400 320" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="PLUCK banner">
  <defs>
    <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#fff4df"/>
      <stop offset="52%" stop-color="#ffe3aa"/>
      <stop offset="100%" stop-color="#ffc868"/>
    </linearGradient>
    <linearGradient id="leaf" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#679d3e"/>
      <stop offset="100%" stop-color="#3a6a1f"/>
    </linearGradient>
  </defs>
  <rect width="1400" height="320" fill="url(#g1)"/>`;
  const commonEnd = `</svg>`;
  const title = {
    home: 'Fresh local fruit, not giant filler art.',
    map: 'Map local citrus and fruit growers.',
    board: 'Fruit board updates from the orchard.',
    messages: 'Fruit-first messages and grower chat.',
    store: 'Shop approved local fruit.',
    profile: 'Grower profile.'
  }[kind] || 'PLUCK';
  let fruit = '';
  if (kind === 'messages') {
    fruit = `
      <ellipse cx="1120" cy="175" rx="88" ry="65" fill="#79a84d"/>
      <ellipse cx="1120" cy="175" rx="62" ry="44" fill="#97c46a"/>
      <circle cx="320" cy="210" r="64" fill="#f29a2e"/><path d="M320 152c20-24 42-30 60-26-17 8-28 18-36 35Z" fill="url(#leaf)"/>
      <circle cx="520" cy="200" r="58" fill="#d64538"/><path d="M520 143c18-21 38-27 54-24-14 7-26 17-31 31Z" fill="url(#leaf)"/>
      <circle cx="690" cy="205" r="54" fill="#9d345a"/><path d="M690 153c16-20 34-26 48-22-12 6-22 15-28 28Z" fill="url(#leaf)"/>
    `;
  } else if (kind === 'profile') {
    fruit = `
      <circle cx="1020" cy="180" r="72" fill="#f29a2e"/><path d="M1020 108c22-26 45-33 64-29-18 8-30 20-38 39Z" fill="url(#leaf)"/>
      <circle cx="1185" cy="195" r="60" fill="#b73d52"/><path d="M1185 136c18-22 38-29 54-24-14 7-25 17-31 31Z" fill="url(#leaf)"/>
      <circle cx="1285" cy="205" r="42" fill="#6ea144"/><path d="M1285 158c12-14 25-19 36-17-10 5-17 11-22 21Z" fill="url(#leaf)"/>
    `;
  } else {
    fruit = `
      <circle cx="980" cy="180" r="72" fill="#f29a2e"/><path d="M980 108c22-26 45-33 64-29-18 8-30 20-38 39Z" fill="url(#leaf)"/>
      <circle cx="1140" cy="205" r="64" fill="#d64538"/><path d="M1140 145c18-22 38-29 54-24-14 7-25 17-31 31Z" fill="url(#leaf)"/>
      <circle cx="1285" cy="175" r="52" fill="#b73d52"/><path d="M1285 121c16-20 34-26 48-22-12 6-22 15-28 28Z" fill="url(#leaf)"/>
      <ellipse cx="1210" cy="240" rx="52" ry="38" fill="#79a84d"/>
    `;
  }
  return `${commonStart}
    <g opacity=".12">
      <circle cx="170" cy="70" r="110" fill="#fff"/>
      <circle cx="280" cy="245" r="130" fill="#fff"/>
      <circle cx="760" cy="35" r="96" fill="#fff"/>
    </g>
    <text x="78" y="126" font-size="44" font-family="Inter, Arial, sans-serif" font-weight="800" fill="#1f2b3a">${title}</text>
    <text x="80" y="172" font-size="22" font-family="Inter, Arial, sans-serif" fill="#4f6177">Citrus, avocados, stone fruits, figs, guavas, pomegranates.</text>
    ${fruit}
  ${commonEnd}`;
}

function findTopAnchor() {
  return document.querySelector('main') ||
    document.querySelector('#root > div') ||
    document.querySelector('#root');
}

function upsertBanner() {
  const kind = routeName();
  const root = findTopAnchor();
  if (!root) return;
  let banner = document.getElementById(bannerId);
  if (!banner) {
    banner = document.createElement('div');
    banner.id = bannerId;
    banner.className = 'pluck-hard-banner';
  }
  banner.innerHTML = svgFor(kind);

  const firstBigImage = document.querySelector('main img, #root img');
  if (firstBigImage && firstBigImage.parentElement) {
    if (banner.parentElement !== firstBigImage.parentElement.parentElement) {
      firstBigImage.parentElement.before(banner);
    }
  } else if (root.firstChild !== banner) {
    root.prepend(banner);
  }

  // Hide obvious giant top fruit image on home and route screens if present
  const imgs = Array.from(document.querySelectorAll('img'));
  imgs.forEach((img, idx) => {
    const src = (img.getAttribute('src') || '').toLowerCase();
    const alt = (img.getAttribute('alt') || '').toLowerCase();
    const rect = img.getBoundingClientRect();
    const looksFruit = /fruit|straw|berry|citrus|orange|avocado|guava|pomegranate|fig/.test(src + ' ' + alt);
    const giant = rect.width > 700 || rect.height > 320 || idx === 0;
    if (looksFruit && giant) {
      (img as HTMLElement).style.maxHeight = '320px';
      (img as HTMLElement).style.objectFit = 'cover';
      (img as HTMLElement).style.width = '100%';
      (img as HTMLElement).style.borderRadius = '24px';
    }
  });
}

const run = () => { try { upsertBanner(); } catch {} };
new MutationObserver(run).observe(document.documentElement, { childList: true, subtree: true });
window.addEventListener('load', run);
window.addEventListener('popstate', run);
setInterval(run, 1200);
run();
console.log('[PLUCK] hard reset installed');