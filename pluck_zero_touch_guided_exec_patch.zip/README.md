PLUCK zero-touch guided executive demo patch

This version is built for your workflow:
- download
- unzip into Codespaces
- run one terminal command
- no manual wiring

Command:
bash scripts/apply-zero-touch-guided-exec.sh /workspaces/PLUCK

What the installer does:
1. copies the guided executive demo component into client/src/components/district
2. copies the CSS into client/src/styles
3. finds a likely district file or App.tsx
4. auto-injects the imports
5. auto-injects <GuidedExecutiveDistrictDemo />
6. installs leaflet packages if missing

After install:
cd /workspaces/PLUCK/client
npm run dev -- --host 0.0.0.0

If you ever want to undo it:
find the .bak_guided_exec backup file created next to the patched page and restore it
