#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/PLUCK}"
CLIENT="$ROOT/client"

echo "== PLUCK zero-touch guided executive demo installer =="
echo "Repo: $ROOT"

if [ ! -d "$CLIENT" ]; then
  echo "ERROR: client directory not found at $CLIENT"
  exit 1
fi

mkdir -p "$CLIENT/src/components/district"
mkdir -p "$CLIENT/src/styles"

cp "$(dirname "$0")/../components/district/GuidedExecutiveDistrictDemo.tsx" "$CLIENT/src/components/district/GuidedExecutiveDistrictDemo.tsx"
cp "$(dirname "$0")/../styles/pluck-guided-exec-demo.css" "$CLIENT/src/styles/pluck-guided-exec-demo.css"

echo "Copied component and styles."

DISTRICT_FILE=""
while IFS= read -r f; do
  if grep -qi "/district" "$f" || grep -qi "district" "$f"; then
    DISTRICT_FILE="$f"
    break
  fi
done < <(find "$CLIENT/src" -type f \( -name "*.tsx" -o -name "*.jsx" \) | sort)

if [ -z "$DISTRICT_FILE" ]; then
  DISTRICT_FILE="$(find "$CLIENT/src" -type f -name "App.tsx" | head -n 1 || true)"
fi

if [ -z "$DISTRICT_FILE" ]; then
  echo "ERROR: could not find a district or App.tsx file to patch."
  exit 1
fi

echo "Patching: $DISTRICT_FILE"
cp "$DISTRICT_FILE" "$DISTRICT_FILE.bak_guided_exec_$(date +%s)"

python3 - "$DISTRICT_FILE" <<'PY'
import re, sys, pathlib
p = pathlib.Path(sys.argv[1])
text = p.read_text()

css_import = "import '../styles/pluck-guided-exec-demo.css';"
alt_css_import = "import '../../styles/pluck-guided-exec-demo.css';"
comp_import = "import GuidedExecutiveDistrictDemo from '../components/district/GuidedExecutiveDistrictDemo';"
alt_comp_import = "import GuidedExecutiveDistrictDemo from '../../components/district/GuidedExecutiveDistrictDemo';"

depth = len(p.relative_to(p.parents[2] / 'src').parts) - 1 if 'src' in p.parts else 1
# Heuristic import path based on whether file sits in src root or nested pages folder
if '/src/' in str(p).replace('\\','/'):
    rel = str(p).replace('\\','/').split('/src/')[1]
    nested = rel.count('/') >= 1
else:
    nested = False

css = alt_css_import if nested else css_import
comp = alt_comp_import if nested else comp_import

if "GuidedExecutiveDistrictDemo" not in text:
    # Place imports after existing import block
    m = list(re.finditer(r'^\s*import .*?;\s*$', text, flags=re.M))
    if m:
        idx = m[-1].end()
        text = text[:idx] + "\n" + css + "\n" + comp + text[idx:]
    else:
        text = css + "\n" + comp + "\n" + text

marker = "<GuidedExecutiveDistrictDemo />"
if marker not in text:
    # try to inject before last closing main/div/fragment return tag
    patterns = [r'(</main>)', r'(</div>\s*\);\s*$)', r'(</>\s*\);\s*$)']
    inserted = False
    for pat in patterns:
        m = re.search(pat, text, flags=re.S|re.M)
        if m:
            text = text[:m.start()] + "  " + marker + "\n" + text[m.start():]
            inserted = True
            break
    if not inserted:
        # fallback append export-safe wrapper comment
        text += "\n\n{/* guided exec demo */}\n" + marker + "\n"

p.write_text(text)
print("patched")
PY

cd "$CLIENT"

if [ -f package.json ]; then
  if ! grep -q '"leaflet"' package.json; then
    echo "Installing leaflet packages..."
    npm install react-leaflet leaflet
  else
    echo "leaflet already present."
  fi
fi

echo
echo "Done."
echo "Patched file: $DISTRICT_FILE"
echo
echo "Now run:"
echo "cd $ROOT/client && npm run dev -- --host 0.0.0.0"
