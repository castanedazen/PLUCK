import React, { useEffect, useMemo, useRef, useState } from 'react';
import { MapContainer, Marker, Polyline, TileLayer, Tooltip, CircleMarker } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

type Grower = {
  id: string;
  name: string;
  lat: number;
  lng: number;
  volume: number;
  eta: number;
};

type District = {
  id: string;
  label: string;
  region: string;
  center: [number, number];
  zoom: number;
  store: { name: string; lat: number; lng: number };
  growers: Grower[];
};

type Stats = {
  coverage: number;
  matched: number;
  eta: number;
  notified: number;
  secured: number;
  confidence: number;
};

const districts: District[] = [
  {
    id: 'west-la',
    label: 'Los Angeles District',
    region: 'West',
    center: [34.0522, -118.2437],
    zoom: 8,
    store: { name: 'West LA Retail Node', lat: 34.0469, lng: -118.2478 },
    growers: [
      { id: 'g1', name: 'Ventura Citrus Co-op', lat: 34.2746, lng: -119.229, volume: 1100, eta: 46 },
      { id: 'g2', name: 'Santa Paula Orchard Network', lat: 34.3542, lng: -119.0593, volume: 850, eta: 51 },
      { id: 'g3', name: 'Bakersfield Stone Fruit', lat: 35.3733, lng: -119.0187, volume: 1300, eta: 93 },
      { id: 'g4', name: 'Oxnard Berry Cluster', lat: 34.1975, lng: -119.1771, volume: 760, eta: 42 },
    ],
  },
  {
    id: 'dfw',
    label: 'Dallas–Fort Worth District',
    region: 'South',
    center: [32.7767, -96.797],
    zoom: 7,
    store: { name: 'DFW Retail Node', lat: 32.7767, lng: -96.797 },
    growers: [
      { id: 'g5', name: 'East Texas Produce Collective', lat: 32.3513, lng: -95.3011, volume: 940, eta: 59 },
      { id: 'g6', name: 'Waco Farm Hub', lat: 31.5493, lng: -97.1467, volume: 720, eta: 68 },
      { id: 'g7', name: 'North Texas Greens Network', lat: 33.2148, lng: -97.1331, volume: 610, eta: 39 },
      { id: 'g8', name: 'Tyler Orchard Alliance', lat: 32.3513, lng: -95.3011, volume: 880, eta: 64 },
    ],
  },
  {
    id: 'atl',
    label: 'Atlanta District',
    region: 'Southeast',
    center: [33.749, -84.388],
    zoom: 7,
    store: { name: 'Atlanta Retail Node', lat: 33.749, lng: -84.388 },
    growers: [
      { id: 'g9', name: 'North Georgia Orchard Group', lat: 34.5326, lng: -83.9849, volume: 890, eta: 54 },
      { id: 'g10', name: 'Macon Fresh Supply', lat: 32.8407, lng: -83.6324, volume: 650, eta: 78 },
      { id: 'g11', name: 'Athens Produce Ring', lat: 33.9519, lng: -83.3576, volume: 730, eta: 51 },
      { id: 'g12', name: 'Columbus Grower Exchange', lat: 32.4609, lng: -84.9877, volume: 580, eta: 91 },
    ],
  },
];

const stageOrder = ['Ready', 'Market Scan', 'Supplier Match', 'Store Execution', 'Complete'];

function makeStoreIcon() {
  return L.divIcon({
    className: 'pluck-store-icon',
    html: '<div class="pluck-store-node"><span></span></div>',
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  });
}

function makeGrowerIcon() {
  return L.divIcon({
    className: 'pluck-grower-icon',
    html: '<div class="pluck-grower-node"><span></span></div>',
    iconSize: [18, 18],
    iconAnchor: [9, 9],
  });
}

const storeIcon = makeStoreIcon();
const growerIcon = makeGrowerIcon();

export default function GuidedExecutiveDistrictDemo() {
  const [districtIndex, setDistrictIndex] = useState(0);
  const [stage, setStage] = useState('Ready');
  const [executing, setExecuting] = useState(false);
  const [complete, setComplete] = useState(false);
  const [activeRoutes, setActiveRoutes] = useState<string[]>([]);
  const timers = useRef<number[]>([]);

  const district = districts[districtIndex];

  const baseStats = useMemo<Stats>(() => ({
    coverage: 64,
    matched: 0,
    eta: 0,
    notified: 0,
    secured: 0,
    confidence: 72,
  }), [districtIndex]);

  const [stats, setStats] = useState<Stats>(baseStats);

  useEffect(() => {
    setStage('Ready');
    setExecuting(false);
    setComplete(false);
    setActiveRoutes([]);
    setStats(baseStats);
    timers.current.forEach(clearTimeout);
    timers.current = [];
  }, [districtIndex, baseStats]);

  useEffect(() => () => {
    timers.current.forEach(clearTimeout);
  }, []);

  const runDemo = () => {
    if (executing) return;
    timers.current.forEach(clearTimeout);
    timers.current = [];
    setExecuting(true);
    setComplete(false);
    setStage('Market Scan');
    setActiveRoutes([]);
    setStats({ coverage: 71, matched: 0, eta: 0, notified: 2, secured: 0, confidence: 78 });

    timers.current.push(window.setTimeout(() => {
      setStage('Supplier Match');
      setStats({
        coverage: 86,
        matched: 3,
        eta: 52,
        notified: district.growers.length,
        secured: 1840,
        confidence: 89,
      });
      setActiveRoutes(district.growers.slice(0, 2).map((g) => g.id));
    }, 1200));

    timers.current.push(window.setTimeout(() => {
      setStats({
        coverage: 93,
        matched: 4,
        eta: 47,
        notified: district.growers.length,
        secured: district.growers.reduce((a, g) => a + g.volume, 0),
        confidence: 95,
      });
      setActiveRoutes(district.growers.map((g) => g.id));
    }, 2400));

    timers.current.push(window.setTimeout(() => {
      setStage('Store Execution');
      setStats({
        coverage: 97,
        matched: district.growers.length,
        eta: 41,
        notified: district.growers.length,
        secured: district.growers.reduce((a, g) => a + g.volume, 0),
        confidence: 98,
      });
    }, 3600));

    timers.current.push(window.setTimeout(() => {
      setStage('Complete');
      setExecuting(false);
      setComplete(true);
    }, 5000));
  };

  const buttonLabel = executing ? 'Executing…' : complete ? 'Fill Executed' : 'Execute Local Fill';

  return (
    <section className="pluck-exec-shell">
      <div className="pluck-exec-hero">
        <div>
          <div className="pluck-chip">National Retail Execution Demo</div>
          <h1>District supply response that looks live, fast, and buyable.</h1>
          <p>
            Show national-ready store execution with live market scan, supplier matching,
            interactive route visualization, and execution confidence in one click.
          </p>
        </div>

        <div className="pluck-hero-actions">
          <select
            className="pluck-select"
            value={districtIndex}
            onChange={(e) => setDistrictIndex(Number(e.target.value))}
            disabled={executing}
          >
            {districts.map((d, i) => (
              <option key={d.id} value={i}>
                {d.label} · {d.region}
              </option>
            ))}
          </select>

          <button
            className={`pluck-exec-btn ${executing ? 'is-running' : ''} ${complete ? 'is-complete' : ''}`}
            onClick={runDemo}
            disabled={executing}
          >
            {buttonLabel}
          </button>
        </div>
      </div>

      <div className="pluck-stage-row">
        {stageOrder.map((s) => {
          const isActive = s === stage;
          const isDone = stageOrder.indexOf(s) < stageOrder.indexOf(stage);
          return (
            <div key={s} className={`pluck-stage ${isActive ? 'active' : ''} ${isDone ? 'done' : ''}`}>
              <span className="dot" />
              <span>{s}</span>
            </div>
          );
        })}
      </div>

      <div className="pluck-grid">
        <div className="pluck-map-card">
          <div className="pluck-card-head">
            <div>
              <h3>{district.label}</h3>
              <p>Store-level fulfillment mapped to regional grower response.</p>
            </div>
            <div className="pluck-card-meta">{stage}</div>
          </div>

          <div className="pluck-map-wrap">
            <MapContainer
              center={district.center}
              zoom={district.zoom}
              scrollWheelZoom={true}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                attribution='&copy; OpenStreetMap contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />

              <Marker position={[district.store.lat, district.store.lng]} icon={storeIcon}>
                <Tooltip direction="top" offset={[0, -10]} permanent>
                  {district.store.name}
                </Tooltip>
              </Marker>

              {district.growers.map((g) => {
                const active = activeRoutes.includes(g.id);
                return (
                  <React.Fragment key={g.id}>
                    <Marker position={[g.lat, g.lng]} icon={growerIcon}>
                      <Tooltip>
                        {g.name}<br />
                        Capacity: {g.volume.toLocaleString()} units<br />
                        ETA: {g.eta} min
                      </Tooltip>
                    </Marker>
                    {active && (
                      <>
                        <Polyline
                          positions={[
                            [g.lat, g.lng],
                            [district.store.lat, district.store.lng],
                          ]}
                          pathOptions={{ className: 'pluck-route-line' }}
                        />
                        <CircleMarker
                          center={[g.lat, g.lng]}
                          radius={18}
                          pathOptions={{ className: 'pluck-pulse-ring' }}
                        />
                      </>
                    )}
                  </React.Fragment>
                );
              })}
            </MapContainer>
          </div>
        </div>

        <div className="pluck-side">
          <div className="pluck-summary-card">
            <div className="pluck-card-head">
              <div>
                <h3>Execution Summary</h3>
                <p>Live district metrics updating during the run.</p>
              </div>
            </div>

            <div className="pluck-kpi-grid">
              <div className="pluck-kpi"><span>Coverage</span><strong>{stats.coverage}%</strong></div>
              <div className="pluck-kpi"><span>Matched</span><strong>{stats.matched}</strong></div>
              <div className="pluck-kpi"><span>ETA</span><strong>{stats.eta ? `${stats.eta} min` : '—'}</strong></div>
              <div className="pluck-kpi"><span>Suppliers Notified</span><strong>{stats.notified}</strong></div>
              <div className="pluck-kpi"><span>Units Secured</span><strong>{stats.secured.toLocaleString()}</strong></div>
              <div className="pluck-kpi"><span>Confidence</span><strong>{stats.confidence}%</strong></div>
            </div>
          </div>

          <div className="pluck-summary-card">
            <div className="pluck-card-head">
              <div>
                <h3>National Framing</h3>
                <p>Language designed for enterprise retail conversations.</p>
              </div>
            </div>

            <ul className="pluck-points">
              <li>District-level execution, not just local sourcing.</li>
              <li>Store node is fed by a broader regional supply graph.</li>
              <li>One-click action simulates real supplier activation.</li>
              <li>Presentation-ready flow for buyers, operators, and retail leadership.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
