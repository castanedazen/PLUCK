#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-/workspaces/PLUCK}"
mkdir -p "$ROOT/client/src"
cp "$ROOT/client/src/App.tsx" "$ROOT/client/src/App.tsx.before-enterprise.bak"
cp "$ROOT/client/src/styles.css" "$ROOT/client/src/styles.css.before-enterprise.bak"
cp "$(dirname "$0")/client/src/App.tsx" "$ROOT/client/src/App.tsx"
cp "$(dirname "$0")/client/src/styles.css" "$ROOT/client/src/styles.css"
echo "PLUCK enterprise version applied."
