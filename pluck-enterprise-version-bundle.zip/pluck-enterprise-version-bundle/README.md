PLUCK Enterprise Version Bundle

What it changes:
- Adds a Retail / Enterprise mode to the app
- Adds a retail-facing teaser section to the homepage
- Adds a full /enterprise route focused on local supply intelligence, ESG, and retail bridge positioning
- Adds a Retail link to bottom navigation
- Forces light pills/chips/badges to use black text for readability

Apply:
  bash apply_pluck_enterprise_version.sh /workspaces/PLUCK

Rollback:
  cp /workspaces/PLUCK/client/src/App.tsx.before-enterprise.bak /workspaces/PLUCK/client/src/App.tsx
  cp /workspaces/PLUCK/client/src/styles.css.before-enterprise.bak /workspaces/PLUCK/client/src/styles.css
