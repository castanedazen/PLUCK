import {
  ChangeEvent,
  FormEvent,
  type Dispatch,
  type ReactNode,
  type SetStateAction,
  useEffect,
  useMemo,
  useState,
} from 'react'
import {
  NavLink,
  Navigate,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from 'react-router-dom'
import {
  createAlert,
  createListing,
  createOrGetConversation,
  deleteListing,
  detectFruitFromImage,
  getAlerts,
  getConversations,
  getFavorites,
  getFollows,
  getListings,
  getMessagesByConversation,
  getNotifications,
  getSeller,
  getSellerById,
  getSocialPosts,
  login,
  markNotificationRead,
  requestPasswordReset,
  resetPassword,
  reservePickup,
  sendMessage,
  signup,
  toggleAlert,
  toggleFavorite,
  toggleFollow,
  updateListing,
  uploadListingImage,
} from './api'
import type {
  AlertItem,
  AuthUser,
  Conversation,
  Favorite,
  Follow,
  Listing,
  Message,
  NotificationItem,
  SellerProfile,
  SocialPost,
} from './types'
import CommunityBoard from './components/CommunityBoard'

type QuickFilter = 'all' | 'just-added' | 'under-5' | 'citrus' | 'high-stock'

const fallbackListings: Listing[] = [
  {
    id: '1',
    title: 'Fresh Backyard Lemons',
    fruit: 'Lemons',
    price: 4,
    unit: 'bag',
    image:
      'https://images.unsplash.com/photo-1590502593747-42a996133562?auto=format&fit=crop&w=1200&q=80',
    location: 'Mission Hills, CA',
    city: 'Los Angeles',
    state: 'CA',
    zip: '91345',
    distance: 'Just dropped',
    inventory: 12,
    sellerId: 'seller-1',
    sellerName: "Maria's Garden",
    description: 'Fresh picked backyard lemons from a local home grower.',
    pickupWindows: ['Today 5–7 PM', 'Tomorrow 9–11 AM'],
    status: 'active',
    tags: ['citrus', 'fresh', 'local'],
    harvestLabel: 'Just dropped',
    freshnessLabel: 'Fresh harvest',
    availabilityLabel: 'Available now',
    harvestNote: 'Picked this morning for same-day pickup.',
    sellerVerified: true,
    sellerRating: 4.8,
    geo: { lat: 34.2766, lng: -118.4671 },
  },
  {
    id: '2',
    title: 'Organic Avocados',
    fruit: 'Avocados',
    price: 3,
    unit: 'each',
    image:
      'https://images.unsplash.com/photo-1601039641847-7857b994d704?auto=format&fit=crop&w=1200&q=80',
    location: 'Pasadena, CA',
    city: 'Pasadena',
    state: 'CA',
    zip: '91104',
    distance: 'Just dropped',
    inventory: 20,
    sellerId: 'seller-2',
    sellerName: 'Green Grove',
    description: 'Creamy organic avocados, perfect for toast or guacamole.',
    pickupWindows: ['Today 6–8 PM', 'Saturday 10 AM–1 PM'],
    status: 'active',
    tags: ['avocados', 'organic', 'creamy'],
    harvestLabel: 'New nearby',
    freshnessLabel: 'Fresh harvest',
    availabilityLabel: 'Available now',
    harvestNote: 'Picked at peak ripeness.',
    sellerVerified: true,
    sellerRating: 4.7,
    geo: { lat: 34.1478, lng: -118.1445 },
  },
]

const fallbackSeller: SellerProfile = {
  id: 'me',
  name: 'Christian',
  handle: '@pluckgrower',
  city: 'Mission Hills',
  state: 'CA',
  zip: '91345',
  locationLabel: 'Mission Hills, CA',
  bio: 'Neighborhood grower sharing backyard harvests with nearby buyers.',
  avatar:
    'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80',
  heroFruit:
    'https://images.unsplash.com/photo-1490818387583-1baba5e638af?auto=format&fit=crop&w=1400&q=80',
  verified: true,
  rating: 4.9,
  ratingCount: 31,
  followers: 126,
  responseScore: '98% reply rate',
  repeatBuyerScore: '41% repeat buyers',
  orchardName: 'Mission Hills Backyard Grove',
  specialties: ['Citrus', 'Seasonal bundles', 'Same-day pickup'],
}

type ListingFormState = {
  title: string
  fruit: string
  price: string
  unit: string
  imagePreview: string
  location: string
  city: string
  state: string
  zip: string
  inventory: string
  description: string
  pickup1: string
  pickup2: string
  tags: string
  harvestNote: string
  harvestLabel: string
  freshnessLabel: string
  availabilityLabel: string
}

const emptyForm: ListingFormState = {
  title: '',
  fruit: '',
  price: '',
  unit: 'basket',
  imagePreview: '',
  location: '',
  city: '',
  state: '',
  zip: '',
  inventory: '',
  description: '',
  pickup1: '',
  pickup2: '',
  tags: '',
  harvestNote: '',
  harvestLabel: 'Just dropped',
  freshnessLabel: 'Fresh harvest',
  availabilityLabel: 'Available now',
}

const quickFilters: { key: QuickFilter; label: string }[] = [
  { key: 'all', label: 'All harvests' },
  { key: 'just-added', label: 'Just dropped' },
  { key: 'under-5', label: 'Under $5' },
  { key: 'citrus', label: 'Citrus' },
  { key: 'high-stock', label: 'High stock' },
]


type ShellLink = {
  label: string
  route?: string
  targetId?: string
  primary?: boolean
}

type ShellTheme = {
  eyebrow: string
  title: string
  subtitle: string
  kicker: string
  links: ShellLink[]
}

const shellThemes: { match: RegExp; theme: ShellTheme }[] = [
  {
    match: /^\/$/,
    theme: {
      eyebrow: 'Neighborhood fruit exchange',
      title: 'Build the local market they cannot own.',
      subtitle: 'Backyard harvests. Same-day pickup. Direct trade that stays human.',
      kicker: 'For the everyman. For the neighborhood.',
      links: [
        { label: 'See the market', targetId: 'market-listings', primary: true },
        { label: 'Open the board', route: '/board', targetId: 'board-shell' },
        { label: 'Start your stand', route: '/store/new' },
      ],
    },
  },
  {
    match: /^\/map/,
    theme: {
      eyebrow: 'Ground game map',
      title: 'Know what is growing close enough to carry home.',
      subtitle: 'Fruit, growers, and pickup points worth leaving the house for.',
      kicker: 'Ground truth for local fruit.',
      links: [
        { label: 'See nearby fruit', targetId: 'map-panel', primary: true },
        { label: 'Open the board', route: '/board', targetId: 'board-shell' },
        { label: 'List your harvest', route: '/store/new' },
      ],
    },
  },
  {
    match: /^\/board/,
    theme: {
      eyebrow: 'Community signal board',
      title: 'Post what matters. Bring the block in.',
      subtitle: 'Barter, help, events, and neighborhood signal in one place.',
      kicker: 'Not followers. Neighbors.',
      links: [
        { label: 'Post a signal', targetId: 'board-create', primary: true },
        { label: 'See the market', route: '/', targetId: 'market-listings' },
        { label: 'Check the map', route: '/map', targetId: 'map-panel' },
      ],
    },
  },
  {
    match: /^\/store/,
    theme: {
      eyebrow: 'Sovereign storefront',
      title: 'Make your stand worth stopping for.',
      subtitle: 'List what is ripe. Set the terms. Build local demand.',
      kicker: 'Small scale. Serious presence.',
      links: [
        { label: 'New listing', route: '/store/new', primary: true },
        { label: 'See your market', route: '/', targetId: 'market-listings' },
        { label: 'Open the board', route: '/board', targetId: 'board-shell' },
      ],
    },
  },
  {
    match: /^\/messages/,
    theme: {
      eyebrow: 'Direct line',
      title: 'Lock the details. Make the pickup happen.',
      subtitle: 'Clear notes, real times, no crossed wires.',
      kicker: 'Direct beats complicated.',
      links: [
        { label: 'Open threads', targetId: 'messages-shell', primary: true },
        { label: 'See the market', route: '/', targetId: 'market-listings' },
        { label: 'Open the board', route: '/board', targetId: 'board-shell' },
      ],
    },
  },
  {
    match: /^\/profile/,
    theme: {
      eyebrow: 'Earned reputation',
      title: 'Let your reputation travel ahead of you.',
      subtitle: 'Show your ground, your harvest, and why neighbors come back.',
      kicker: 'Known locally beats polished globally.',
      links: [
        { label: 'View profile', targetId: 'profile-shell', primary: true },
        { label: 'Open your stand', route: '/store' },
        { label: 'Open messages', route: '/messages', targetId: 'messages-shell' },
      ],
    },
  },
  {
    match: /^\/listing\//,
    theme: {
      eyebrow: 'Real listing',
      title: 'See the fruit. Know the terms.',
      subtitle: 'Photos, pickup windows, and the real person behind the harvest.',
      kicker: 'No mystery. No marketplace theater.',
      links: [
        { label: 'View details', targetId: 'listing-detail-shell', primary: true },
        { label: 'Message grower', targetId: 'listing-detail-shell' },
      ],
    },
  },
]

function getShellTheme(pathname: string): ShellTheme {
  return shellThemes.find((item) => item.match.test(pathname))?.theme ?? shellThemes[0].theme
}

function formatTime(value?: string) {
  if (!value) return ''
  return new Date(value).toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  })
}

function formatShortDate(value?: string) {
  if (!value) return ''
  return new Date(value).toLocaleDateString([], {
    month: 'short',
    day: 'numeric',
  })
}

function sellerLabel(listing: Listing) {
  const rating = listing.sellerRating ? listing.sellerRating.toFixed(1) : null
  return rating ? `${listing.sellerName} • ★ ${rating}` : listing.sellerName
}

function prettyLocation(listing: Listing) {
  const parts = [listing.city || '', listing.state || ''].filter(Boolean)
  if (parts.length) return parts.join(', ')
  return listing.location
}

function hasGeo(listing: Listing) {
  return (
    typeof listing.geo?.lat === 'number' &&
    Number.isFinite(listing.geo.lat) &&
    typeof listing.geo?.lng === 'number' &&
    Number.isFinite(listing.geo.lng)
  )
}

function normalizeListing(listing: Listing): Listing {
  const fruit = listing.fruit || 'Fruit'
  const city = listing.city || ''
  const state = listing.state || ''
  const location =
    listing.location || [city, state].filter(Boolean).join(', ') || 'Local pickup available'

  return {
    ...listing,
    fruit,
    unit: listing.unit || 'each',
    image:
      listing.image ||
      'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?auto=format&fit=crop&w=1200&q=80',
    location,
    city,
    state,
    zip: listing.zip || '',
    distance: listing.distance || 'Just dropped',
    inventory: Number.isFinite(listing.inventory) ? listing.inventory : 0,
    sellerId: listing.sellerId || 'seller-unknown',
    sellerName: listing.sellerName || 'Local Grower',
    description: listing.description || 'Fresh local fruit available for pickup.',
    pickupWindows:
      listing.pickupWindows && listing.pickupWindows.length
        ? listing.pickupWindows
        : ['Pickup by message'],
    status: listing.status || 'active',
    tags: listing.tags && listing.tags.length ? listing.tags : [fruit.toLowerCase()],
    harvestLabel: listing.harvestLabel || 'Just dropped',
    freshnessLabel: listing.freshnessLabel || 'Fresh harvest',
    availabilityLabel: listing.availabilityLabel || 'Available now',
    harvestNote: listing.harvestNote || '',
    sellerVerified: listing.sellerVerified ?? false,
    sellerRating: listing.sellerRating ?? 0,
    geo: listing.geo || null,
  }
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      resolve(typeof reader.result === 'string' ? reader.result : '')
    }
    reader.onerror = () => reject(new Error('Unable to read image file.'))
    reader.readAsDataURL(file)
  })
}

function mergeTagCsv(existingCsv: string, incomingTags: string[]) {
  const existing = existingCsv
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean)

  const merged = [...existing]
  for (const tag of incomingTags) {
    const clean = tag.trim()
    if (!clean) continue
    if (!merged.some((item) => item.toLowerCase() === clean.toLowerCase())) {
      merged.push(clean)
    }
  }

  return merged.join(', ')
}

function ActionGrid({
  children,
  columns = 2,
}: {
  children: ReactNode
  columns?: 1 | 2 | 3 | 4
}) {
  return <div className={`action-grid action-grid--${columns}`}>{children}</div>
}

function ReserveModal({
  listing,
  onClose,
  onConfirm,
}: {
  listing: Listing
  onClose: () => void
  onConfirm: (pickupWindow: string) => Promise<void>
}) {
  const [selectedWindow, setSelectedWindow] = useState(listing.pickupWindows?.[0] || 'Pickup by message')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-shell" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <p className="eyebrow">Reserve pickup</p>
            <h3>{listing.title}</h3>
            <p className="modal-subcopy">
              Choose the pickup window that works best. You can message the grower immediately after.
            </p>
          </div>
          <button className="ghost compact-btn" onClick={onClose}>
            Close
          </button>
        </div>

        <div className="modal-window-list">
          {listing.pickupWindows.map((slot) => (
            <button
              key={slot}
              className={selectedWindow === slot ? 'window-pill active' : 'window-pill'}
              onClick={() => setSelectedWindow(slot)}
            >
              {slot}
            </button>
          ))}
        </div>

        {error ? <div className="status-banner error">{error}</div> : null}

        <div className="action-row">
          <button
            className="primary"
            disabled={busy}
            onClick={async () => {
              try {
                setBusy(true)
                setError('')
                await onConfirm(selectedWindow)
              } catch (err) {
                const message = err instanceof Error ? err.message : 'Unable to reserve pickup.'
                setError(message)
              } finally {
                setBusy(false)
              }
            }}
          >
            {busy ? 'Reserving...' : 'Confirm pickup'}
          </button>
          <button className="ghost" disabled={busy} onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  )
}

function AuthShell({
  mode,
  onAuthSuccess,
}: {
  mode: 'login' | 'signup' | 'reset'
  onAuthSuccess: (user: AuthUser) => void
}) {
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [resetCode, setResetCode] = useState('')
  const [resetRequested, setResetRequested] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [info, setInfo] = useState('')

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError('')
    setInfo('')

    try {
      if (mode === 'signup') {
        if (!name.trim() || !email.trim() || !password.trim()) throw new Error('Name, email, and password are required')
        const user = await signup({ name: name.trim(), email: email.trim(), role: 'buyer', password })
        onAuthSuccess(user)
        navigate('/')
      } else if (mode === 'login') {
        const user = await login({ email: email.trim(), password })
        onAuthSuccess(user)
        navigate('/')
      } else {
        if (!resetRequested) {
          const result = await requestPasswordReset({ email: email.trim() })
          setInfo(`Reset code sent. Use: ${result.resetToken}`)
          setResetRequested(true)
        } else {
          if (!resetCode.trim() || !password.trim()) throw new Error('Reset code and new password are required')
          await resetPassword({ email: email.trim(), resetToken: resetCode.trim(), password })
          setInfo('Password updated. You can log in now.')
          window.setTimeout(() => navigate('/login'), 800)
        }
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unable to continue.'
      setError(message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className="auth-page">
      <div className="auth-hero">
        <p className="eyebrow">PLUCK account</p>
        <h1>{mode === 'signup' ? 'Start using PLUCK' : mode === 'reset' ? 'Reset your password' : 'Welcome back'}</h1>
        <p>{mode === 'reset' ? 'Reset your password and get back into the market.' : 'Create an account, save fruit, and keep pickup direct.'}</p>
      </div>

      <form className="auth-card" onSubmit={handleSubmit}>
        <div className="form-header">
          <div>
            <p className="eyebrow">{mode === 'signup' ? 'New account' : mode === 'reset' ? 'Password reset' : 'Login'}</p>
            <h2>{mode === 'signup' ? 'Create your account' : mode === 'reset' ? 'Forgot your password?' : 'Sign into your account'}</h2>
          </div>
        </div>

        <div className="listing-form">
          <div className="form-grid">
            {mode === 'signup' ? (
              <label className="full">
                Full name
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Christian Castaneda" />
              </label>
            ) : null}

            <label className="full">
              Email
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
            </label>

            <label className="full">
              Password
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder={mode === 'reset' ? 'New password' : 'Enter your password'} required={mode !== 'reset' || resetRequested} />
            </label>

            {mode === 'signup' ? (
              <label className="full">
                Confirm password
                <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm password" />
              </label>
            ) : null}

            {mode === 'reset' && resetRequested ? (
              <label className="full">
                Reset code
                <input value={resetCode} onChange={(e) => setResetCode(e.target.value)} placeholder="Paste reset code" required />
              </label>
            ) : null}
          </div>

          {info ? <div className="status-banner success">{info}</div> : null}
          {error ? <div className="status-banner error">{error}</div> : null}

          <div className="action-row auth-action-row">
            <button className="primary" type="submit" disabled={busy}>
              {busy ? 'Please wait...' : mode === 'signup' ? 'Create account' : mode === 'reset' ? (resetRequested ? 'Save new password' : 'Send reset code') : 'Log in'}
            </button>
            {mode === 'login' ? (
              <>
                <button type="button" className="ghost" onClick={() => navigate('/signup')}>Create account</button>
                <button type="button" className="ghost" onClick={() => navigate('/reset-password')}>Forgot password?</button>
              </>
            ) : mode === 'signup' ? (
              <button type="button" className="ghost" onClick={() => navigate('/login')}>Have an account?</button>
            ) : (
              <button type="button" className="ghost" onClick={() => navigate('/login')}>Back to login</button>
            )}
          </div>
        </div>
      </form>
    </section>
  )
}

type ListingFormProps = {
  seller: SellerProfile
  initialValues?: Listing
  submitLabel: string
  onSubmitListing: (payload: Omit<Listing, 'id'>, existingId?: string) => Promise<void>
  existingId?: string
}

function ListingForm({
  seller,
  initialValues,
  submitLabel,
  onSubmitListing,
  existingId,
}: ListingFormProps) {
  const navigate = useNavigate()
  const [form, setForm] = useState<ListingFormState>(() => {
    if (!initialValues) return emptyForm
    return {
      title: initialValues.title,
      fruit: initialValues.fruit,
      price: String(initialValues.price),
      unit: initialValues.unit,
      imagePreview: initialValues.image,
      location: initialValues.location,
      city: initialValues.city || '',
      state: initialValues.state || '',
      zip: initialValues.zip || '',
      inventory: String(initialValues.inventory),
      description: initialValues.description,
      pickup1: initialValues.pickupWindows?.[0] || '',
      pickup2: initialValues.pickupWindows?.[1] || '',
      tags: (initialValues.tags || []).join(', '),
      harvestNote: initialValues.harvestNote || '',
      harvestLabel: initialValues.harvestLabel || 'Just dropped',
      freshnessLabel: initialValues.freshnessLabel || 'Fresh harvest',
      availabilityLabel: initialValues.availabilityLabel || 'Available now',
    }
  })
  const [isSaving, setIsSaving] = useState(false)
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false)
  const [saveError, setSaveError] = useState('')
  const [saveSuccess, setSaveSuccess] = useState('')
  const [imageStatus, setImageStatus] = useState('')

  function updateForm<K extends keyof ListingFormState>(key: K, value: ListingFormState[K]) {
    setForm((current) => ({ ...current, [key]: value }))
  }

  async function handleImageUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return

    setSaveError('')
    setSaveSuccess('')
    setImageStatus('')
    setIsAnalyzingImage(true)

    try {
      const preview = await readFileAsDataUrl(file)
      updateForm('imagePreview', preview)
      setImageStatus('Uploading image and detecting fruit...')

      let uploadPayload: { imageUrl?: string; originalName?: string; fileName?: string } = {
        originalName: file.name,
      }

      try {
        const uploaded = await uploadListingImage(file)
        uploadPayload = {
          imageUrl: uploaded.absoluteUrl,
          originalName: uploaded.originalName,
          fileName: uploaded.fileName,
        }
      } catch {
        uploadPayload = {
          originalName: file.name,
        }
      }

      const detection = await detectFruitFromImage(uploadPayload)

      setForm((current) => ({
        ...current,
        imagePreview: current.imagePreview || preview,
        fruit: current.fruit.trim() ? current.fruit : detection.fruit,
        title: current.title.trim() ? current.title : detection.title,
        tags: mergeTagCsv(current.tags, detection.tags || []),
      }))

      setImageStatus(
        `Detected ${detection.fruit} • ${Math.round((detection.confidence || 0) * 100)}% confidence`,
      )
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to process image.'
      setSaveError(message)
      setImageStatus('')
    } finally {
      setIsAnalyzingImage(false)
      if (e.target) {
        e.target.value = ''
      }
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setIsSaving(true)
    setSaveError('')
    setSaveSuccess('')

    try {
      const pickupWindows = [form.pickup1, form.pickup2].map((x) => x.trim()).filter(Boolean)
      const locationLabel =
        form.location.trim() ||
        [form.city.trim(), form.state.trim()].filter(Boolean).join(', ') ||
        'Anywhere, USA'

      const payload: Omit<Listing, 'id'> = {
        title: form.title.trim() || `${form.fruit.trim()} Listing`,
        fruit: form.fruit.trim() || 'Fruit',
        price: Number(form.price) || 0,
        unit: form.unit.trim() || 'basket',
        image:
          form.imagePreview ||
          'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?auto=format&fit=crop&w=1200&q=80',
        location: locationLabel,
        city: form.city.trim(),
        state: form.state.trim(),
        zip: form.zip.trim(),
        distance: initialValues?.distance || 'Just dropped',
        inventory: Number(form.inventory) || 1,
        sellerId: seller.id,
        sellerName: seller.name,
        description: form.description.trim() || 'Fresh local fruit available for pickup.',
        pickupWindows: pickupWindows.length ? pickupWindows : ['Pickup by message'],
        isFavorite: initialValues?.isFavorite || false,
        status: initialValues?.status || 'active',
        tags: form.tags
          .split(',')
          .map((x) => x.trim())
          .filter(Boolean),
        harvestNote: form.harvestNote.trim(),
        harvestLabel: form.harvestLabel,
        freshnessLabel: form.freshnessLabel,
        availabilityLabel: form.availabilityLabel,
        sellerVerified: seller.verified,
        sellerRating: seller.rating,
        geo: initialValues?.geo || null,
      }

      await onSubmitListing(payload, existingId)
      setSaveSuccess(existingId ? 'Listing updated successfully.' : 'Listing created successfully.')

      setTimeout(() => {
        navigate('/store/listings')
      }, 450)
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to save listing right now.'
      setSaveError(message)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <section className="stack form-stack premium-form-shell">
      <div className="form-header">
        <div>
          <p className="eyebrow">{existingId ? 'Edit listing' : 'New listing'}</p>
          <h2>{existingId ? 'Update listing details' : 'Create a premium fruit listing'}</h2>
          <p>
            Stronger titles, clearer pickup windows, trust badges, and nationwide-ready location fields.
          </p>
        </div>
      </div>

      <form className="listing-form" onSubmit={handleSubmit}>
        <div className="form-grid">
          <label>
            Title
            <input
              value={form.title}
              onChange={(e) => updateForm('title', e.target.value)}
              placeholder="Golden backyard avocados"
            />
          </label>

          <label>
            Fruit
            <input
              value={form.fruit}
              onChange={(e) => updateForm('fruit', e.target.value)}
              placeholder="Avocados"
            />
          </label>

          <label>
            Price
            <input
              type="number"
              min="0"
              step="0.01"
              value={form.price}
              onChange={(e) => updateForm('price', e.target.value)}
              placeholder="8"
            />
          </label>

          <label>
            Unit
            <input
              value={form.unit}
              onChange={(e) => updateForm('unit', e.target.value)}
              placeholder="bag"
            />
          </label>

          <label>
            City
            <input
              value={form.city}
              onChange={(e) => updateForm('city', e.target.value)}
              placeholder="Austin"
            />
          </label>

          <label>
            State
            <input
              value={form.state}
              onChange={(e) => updateForm('state', e.target.value)}
              placeholder="TX"
            />
          </label>

          <label>
            ZIP code
            <input
              value={form.zip}
              onChange={(e) => updateForm('zip', e.target.value)}
              placeholder="78704"
            />
          </label>

          <label>
            Location label
            <input
              value={form.location}
              onChange={(e) => updateForm('location', e.target.value)}
              placeholder="South Austin, TX"
            />
          </label>

          <label>
            Inventory
            <input
              type="number"
              min="1"
              step="1"
              value={form.inventory}
              onChange={(e) => updateForm('inventory', e.target.value)}
              placeholder="6"
            />
          </label>

          <label className="full upload-zone">
            Upload photo
            <input type="file" accept="image/*" capture="environment" onChange={handleImageUpload} />
            <span className="upload-hint">
              Upload a fruit photo. PLUCK will try to detect the fruit and auto-fill your form.
            </span>
          </label>

          {imageStatus ? (
            <div className="status-banner success full">
              {isAnalyzingImage ? `${imageStatus} Please wait...` : imageStatus}
            </div>
          ) : null}

          {form.imagePreview && (
            <div className="image-preview-wrap full">
              <img className="image-preview" src={form.imagePreview} alt="Preview" />
              <button type="button" className="ghost compact-btn" onClick={() => updateForm('imagePreview', '')}>
                Remove image
              </button>
            </div>
          )}

          <label className="full">
            Description
            <textarea
              value={form.description}
              onChange={(e) => updateForm('description', e.target.value)}
              placeholder="Tell buyers what makes this fruit special."
              rows={4}
            />
          </label>

          <label className="full">
            Tags
            <input
              value={form.tags}
              onChange={(e) => updateForm('tags', e.target.value)}
              placeholder="sweet, citrus, juice"
            />
          </label>

          <label className="full">
            Harvest note
            <textarea
              value={form.harvestNote}
              onChange={(e) => updateForm('harvestNote', e.target.value)}
              placeholder="Picked at dawn. Best same-day."
              rows={3}
            />
          </label>

          <label>
            Harvest badge
            <input
              value={form.harvestLabel}
              onChange={(e) => updateForm('harvestLabel', e.target.value)}
              placeholder="Just dropped"
            />
          </label>

          <label>
            Freshness badge
            <input
              value={form.freshnessLabel}
              onChange={(e) => updateForm('freshnessLabel', e.target.value)}
              placeholder="Fresh harvest"
            />
          </label>

          <label className="full">
            Availability badge
            <input
              value={form.availabilityLabel}
              onChange={(e) => updateForm('availabilityLabel', e.target.value)}
              placeholder="Available now"
            />
          </label>

          <label>
            Pickup window 1
            <input
              value={form.pickup1}
              onChange={(e) => updateForm('pickup1', e.target.value)}
              placeholder="Today 5–7 PM"
            />
          </label>

          <label>
            Pickup window 2
            <input
              value={form.pickup2}
              onChange={(e) => updateForm('pickup2', e.target.value)}
              placeholder="Tomorrow 10 AM–12 PM"
            />
          </label>
        </div>

        {(saveError || saveSuccess) && (
          <div className={saveError ? 'status-banner error' : 'status-banner success'}>
            {saveError || saveSuccess}
          </div>
        )}

        <div className="action-row">
          <button type="submit" className="primary" disabled={isSaving || isAnalyzingImage}>
            {isSaving ? 'Saving...' : isAnalyzingImage ? 'Analyzing image...' : submitLabel}
          </button>
          <button type="button" className="ghost" disabled={isSaving || isAnalyzingImage} onClick={() => navigate('/store/listings')}>
            Cancel
          </button>
        </div>
      </form>
    </section>
  )
}

function GrowerTrust({
  seller,
  isFollowing,
  onToggleFollow,
}: {
  seller: SellerProfile
  isFollowing: boolean
  onToggleFollow: () => Promise<void>
}) {
  return (
    <div className="grower-trust-card">
      <div className="grower-head">
        <img className="avatar" src={seller.avatar} alt={seller.name} />
        <div>
          <div className="grower-name-row">
            <h3>{seller.name}</h3>
            {seller.verified ? <span className="trust-pill verified">Verified grower</span> : null}
          </div>
          <p className="meta">
            {seller.handle} • {[seller.city, seller.state].filter(Boolean).join(', ')}
          </p>
        </div>
      </div>

      <p className="desc">{seller.bio}</p>

      <div className="trust-metrics">
        <div className="metric-chip">
          ★ {(seller.rating || 0).toFixed(1)} {seller.ratingCount ? `(${seller.ratingCount})` : ''}
        </div>
        <div className="metric-chip">{seller.followers || 0} followers</div>
        {seller.responseScore ? <div className="metric-chip">{seller.responseScore}</div> : null}
        {seller.repeatBuyerScore ? <div className="metric-chip">{seller.repeatBuyerScore}</div> : null}
      </div>

      {seller.specialties?.length ? (
        <div className="pill-row">
          {seller.specialties.map((item) => (
            <span className="pill" key={item}>
              {item}
            </span>
          ))}
        </div>
      ) : null}

      <div className="action-row">
        <button className="primary" onClick={onToggleFollow}>
          {isFollowing ? 'Following' : 'Follow grower'}
        </button>
      </div>
    </div>
  )
}

function NationwideGeoMap({
  listings,
  onOpenListing,
}: {
  listings: Listing[]
  onOpenListing: (listingId: string) => void
}) {
  const geoListings = listings.filter(hasGeo)
  const [zoom, setZoom] = useState(1)
  const [compact, setCompact] = useState(false)

  const bounds = { minLat: 24, maxLat: 49, minLng: -125, maxLng: -66 }

  function xFromLng(lng: number) {
    return ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100
  }

  function yFromLat(lat: number) {
    return 100 - ((lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * 100
  }

  return (
    <div className={`nationwide-map ${compact ? 'compact' : ''}`}>
      <div className="nationwide-map__top">
        <div>
          <div className="nationwide-map__eyebrow">Live geo layer</div>
          <div className="nationwide-map__title">United States listing coverage</div>
        </div>
        <div className="nationwide-map__actions">
          <button className="ghost compact-btn" onClick={() => setZoom((z) => Math.max(0.8, +(z - 0.1).toFixed(1)))}>-</button>
          <button className="ghost compact-btn" onClick={() => setZoom((z) => Math.min(1.5, +(z + 0.1).toFixed(1)))}>+</button>
          <button className="ghost compact-btn" onClick={() => setCompact((c) => !c)}>{compact ? 'Expand' : 'Compact'}</button>
          <div className="nationwide-map__count">{geoListings.length} pinned</div>
        </div>
      </div>

      <div className="nationwide-map__canvas" style={{ transform: `scale(${zoom})` }}>
        <div className="nationwide-map__usa" />
        {geoListings.map((item) => {
          const left = `${xFromLng(item.geo!.lng)}%`
          const top = `${yFromLat(item.geo!.lat)}%`
          return (
            <button
              key={item.id}
              className="nationwide-map__pin"
              onClick={() => onOpenListing(item.id)}
              title={`${item.title} • ${prettyLocation(item)}`}
              style={{ left, top }}
            />
          )
        })}
      </div>

      {!compact ? (
        <div className="nationwide-map__list">
          {geoListings.slice(0, 3).map((item) => (
            <button key={item.id} className="nationwide-map__row" onClick={() => onOpenListing(item.id)}>
              <div>
                <div className="nationwide-map__rowTitle">{item.title}</div>
                <div className="nationwide-map__rowMeta">{prettyLocation(item)} • {item.sellerName}</div>
              </div>
              <div className="nationwide-map__rowPrice">${item.price}/{item.unit}</div>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  )
}

function AppLayout({
  listings,
  setListings,
  seller,
  favorites,
  setFavorites,
  conversations,
  setConversations,
  threadMessages,
  setThreadMessages,
  socialPosts,
  notifications,
  setNotifications,
  alerts,
  setAlerts,
  follows,
  setFollows,
  authUser,
  onAuthSuccess,
}: AppLayoutProps) {
  const navigate = useNavigate()
  const location = useLocation()
  const [query, setQuery] = useState('')
  const [activeFilter, setActiveFilter] = useState<QuickFilter>('all')
  const [reserveTarget, setReserveTarget] = useState<Listing | null>(null)
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null)

  const favoriteListingIds = new Set(favorites.map((fav) => fav.listingId))
  const favoriteListings = listings.filter((item) => favoriteListingIds.has(item.id))
  const myListings = listings.filter((item) => item.sellerName === seller.name)
  const justAdded = listings.filter((item) => item.distance === 'Just dropped')
  const totalInventory = myListings.reduce((sum, item) => sum + item.inventory, 0)
  const averagePrice =
    myListings.length > 0
      ? (myListings.reduce((sum, item) => sum + item.price, 0) / myListings.length).toFixed(2)
      : '0.00'

  const unreadNotifications = notifications.filter((item) => !item.read)
  const followingSellerIds = new Set(follows.map((item) => item.sellerId))

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()

    let result = listings.filter((item) =>
      [
        item.title,
        item.fruit,
        item.location,
        item.city || '',
        item.state || '',
        item.zip || '',
        item.sellerName,
        item.description,
        ...(item.tags || []),
      ]
        .join(' ')
        .toLowerCase()
        .includes(q),
    )

    if (activeFilter === 'just-added') {
      result = result.filter((item) => item.distance === 'Just dropped')
    }

    if (activeFilter === 'under-5') {
      result = result.filter((item) => item.price <= 5)
    }

    if (activeFilter === 'citrus') {
      result = result.filter((item) =>
        ['orange', 'oranges', 'lemon', 'lemons', 'lime', 'limes', 'grapefruit'].includes(
          item.fruit.toLowerCase(),
        ),
      )
    }

    if (activeFilter === 'high-stock') {
      result = result.filter((item) => item.inventory >= 6)
    }

    return result
  }, [listings, query, activeFilter])

  useEffect(() => {
    if (!selectedConversationId && conversations.length > 0) {
      setSelectedConversationId(conversations[0].id)
    }
  }, [conversations, selectedConversationId])

  async function handleCreate(payload: Omit<Listing, 'id'>) {
    const saved = normalizeListing(await createListing(payload))
    setListings((current) => [saved, ...current])
  }

  async function handleUpdate(payload: Omit<Listing, 'id'>, listingId?: string) {
    if (!listingId) {
      const saved = normalizeListing(await createListing(payload))
      setListings((current) => [saved, ...current])
      return
    }

    const updated = normalizeListing(await updateListing(listingId, payload))
    setListings((current) => current.map((item) => (item.id === listingId ? updated : item)))
  }

  async function handleArchive(listingId: string) {
    const confirmed = window.confirm('Archive this listing?')
    if (!confirmed) return
    await deleteListing(listingId)
    setListings((current) => current.filter((item) => item.id !== listingId))
  }

  async function handleToggleFavorite(listingId: string) {
    const result = await toggleFavorite({ userId: seller.id, listingId })

    if (result.active) {
      setFavorites((current) => [{ id: crypto.randomUUID(), userId: seller.id, listingId }, ...current])
    } else {
      setFavorites((current) => current.filter((fav) => fav.listingId !== listingId))
    }
  }

  async function handleToggleFollow(sellerId: string) {
    if (sellerId === seller.id) return
    const result = await toggleFollow({ userId: seller.id, sellerId })

    if (result.active) {
      setFollows((current) => [{ id: crypto.randomUUID(), userId: seller.id, sellerId }, ...current])
    } else {
      setFollows((current) => current.filter((item) => item.sellerId !== sellerId))
    }

    const refreshedListings = await getListings()
    setListings(refreshedListings.map(normalizeListing))
  }

  async function handleConfirmReserve(listing: Listing, pickupWindow: string) {
    const result = await reservePickup({
      listingId: listing.id,
      buyerId: seller.id,
      buyerName: seller.name,
      sellerId: listing.sellerId,
      pickupWindow,
    })

    setListings((current) =>
      current.map((item) => (item.id === listing.id ? normalizeListing(result.listing) : item)),
    )
    setReserveTarget(null)

    const conversation = await createOrGetConversation({
      listingId: listing.id,
      listingTitle: listing.title,
      sellerId: listing.sellerId,
      sellerName: listing.sellerName,
      buyerId: seller.id,
      buyerName: seller.name,
    })

    const refreshed = await getConversations()
    setConversations(refreshed)
    setSelectedConversationId(conversation.id)

    const thread = await getMessagesByConversation(conversation.id)
    setThreadMessages(thread)

    navigate('/messages')
  }

  async function handleStartConversation(listing: Listing) {
    const conversation = await createOrGetConversation({
      listingId: listing.id,
      listingTitle: listing.title,
      sellerId: listing.sellerId,
      sellerName: listing.sellerName,
      buyerId: seller.id,
      buyerName: seller.name,
    })

    const refreshed = await getConversations()
    setConversations(refreshed)
    setSelectedConversationId(conversation.id)

    const thread = await getMessagesByConversation(conversation.id)
    setThreadMessages(thread)

    navigate('/messages')
  }

  async function handleSelectConversation(conversationId: string) {
    const thread = await getMessagesByConversation(conversationId)
    setThreadMessages(thread)
    setSelectedConversationId(conversationId)

    const selected = conversations.find((item) => item.id === conversationId)
    if (selected) {
      const ordered = [selected, ...conversations.filter((item) => item.id !== conversationId)]
      setConversations(ordered)
    }
  }

  async function handleSendMessage(conversationId: string, content: string) {
    await sendMessage({
      conversationId,
      senderId: seller.id,
      senderName: seller.name,
      content,
    })

    const refreshedConversations = await getConversations()
    const thread = await getMessagesByConversation(conversationId)

    setConversations(refreshedConversations)
    setThreadMessages(thread)
    setSelectedConversationId(conversationId)
  }

  async function handleCreateAlert(payload: Omit<AlertItem, 'id'>) {
    const created = await createAlert(payload)
    setAlerts((current) => [created, ...current])
  }

  async function handleToggleAlert(id: string) {
    const updated = await toggleAlert(id)
    setAlerts((current) => current.map((item) => (item.id === id ? updated : item)))
  }

  async function handleReadNotification(id: string) {
    const updated = await markNotificationRead(id)
    setNotifications((current) => current.map((item) => (item.id === id ? updated : item)))
  }

  function isActivePath(path: string) {
    return location.pathname === path
  }

  const shellTheme = getShellTheme(location.pathname)

  function jumpTo(targetId?: string, route?: string) {
    if (route && route !== location.pathname) {
      navigate(route)
      window.setTimeout(() => {
        if (!targetId) return
        document.getElementById(targetId)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      }, 120)
      return
    }
    if (targetId) {
      document.getElementById(targetId)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      return
    }
    if (route) navigate(route)
  }

  return (
    <div className="app-shell">
      <header className="topbar topbar--route">
        <div className="topbar-copy">
          <p className="eyebrow">{shellTheme.eyebrow}</p>
          <p className="topbar-mini">{shellTheme.kicker}</p>
        </div>
        <div className="topbar-actions">
          {!authUser ? (
            <>
              <button className="ghost" onClick={() => navigate('/login')}>
                Log in
              </button>
              <button className="primary" onClick={() => navigate('/signup')}>
                Create account
              </button>
            </>
          ) : (
            <>
              <button className="ghost" onClick={() => navigate('/alerts')}>
                Alerts {unreadNotifications.length ? `(${unreadNotifications.length})` : ''}
              </button>
              <button className="ghost" onClick={() => navigate('/profile')}>
                {[seller.city, seller.state].filter(Boolean).join(', ') || 'Profile'}
              </button>
              <button className="primary" onClick={() => navigate('/store/new')}>
                + New listing
              </button>
            </>
          )}
        </div>
      </header>

      <section className={`hero-band hero-band--route hero-band--${location.pathname.split('/')[1] || 'home'}`}>
        <div className="hero-copy hero-copy--route">
          <p className="eyebrow">{shellTheme.kicker}</p>
          <h2>{shellTheme.title}</h2>
          <p>{shellTheme.subtitle}</p>
          <div className="hero-cta-row">
            {shellTheme.links.map((link) => (
              <button
                key={link.label}
                className={link.primary ? 'primary' : 'ghost'}
                onClick={() => jumpTo(link.targetId, link.route)}
              >
                {link.label}
              </button>
            ))}
          </div>
        </div>

        <div className="hero-aside hero-aside--route">
          <div className="hero-note-strip">
            <span className="hero-stamp">Resilient</span>
            <span className="hero-stamp">Local</span>
            <span className="hero-stamp">Independent</span>
          </div>
          <div className="stats-grid stats-grid--manifesto">
            <button className="stat-card stat-link" onClick={() => navigate('/')}>
              <span>Nearby</span>
              <strong>{listings.length}</strong>
            </button>
            <button className="stat-card stat-link" onClick={() => navigate('/favorites')}>
              <span>Saved</span>
              <strong>{favoriteListings.length}</strong>
            </button>
            <button className="stat-card stat-link" onClick={() => navigate('/store/inventory')}>
              <span>In stock</span>
              <strong>{totalInventory}</strong>
            </button>
            <button className="stat-card stat-link" onClick={() => navigate('/messages')}>
              <span>Threads</span>
              <strong>{conversations.length}</strong>
            </button>
          </div>
        </div>
      </section>

      <div className="search-wrap" id="market-search">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search fruit, growers, city, state, or ZIP..."
        />

        <div className="search-bottom-row">
          <div className="toggle-row">
            <button className={isActivePath('/') ? 'toggle active' : 'toggle'} onClick={() => navigate('/')}>
              List
            </button>
            <button className={isActivePath('/map') ? 'toggle active' : 'toggle'} onClick={() => navigate('/map')}>
              Map
            </button>
          </div>

          <div className="filter-chip-row">
            {quickFilters.map((filter) => (
              <button
                key={filter.key}
                className={activeFilter === filter.key ? 'filter-chip active' : 'filter-chip'}
                onClick={() => setActiveFilter(filter.key)}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <main className="content">
        <Routes>
          <Route path="/login" element={<AuthShell mode="login" onAuthSuccess={onAuthSuccess} />} />
          <Route path="/signup" element={<AuthShell mode="signup" onAuthSuccess={onAuthSuccess} />} />
          <Route path="/reset-password" element={<AuthShell mode="reset" onAuthSuccess={onAuthSuccess} />} />
          <Route path="/board" element={<CommunityBoard />} />

          <Route
            path="/"
            element={
              <>
                <section className="hero-card">
                  <div>
                    <p className="eyebrow">Today nearby</p>
                    <h2>Backyard harvests, same-day pickup</h2>
                    <p>Browse fruit from local growers, reserve by message, and coordinate a clear pickup window.</p>
                  </div>
                  <button className="primary" onClick={() => navigate('/store/new')}>
                    Create listing
                  </button>
                </section>

                {unreadNotifications.length ? (
                  <section className="signal-strip">
                    {unreadNotifications.slice(0, 2).map((item) => (
                      <button className="signal-pill" key={item.id} onClick={() => navigate('/alerts')}>
                        {item.title}
                      </button>
                    ))}
                  </section>
                ) : null}

                <section className="section-heading">
                  <div>
                    <p className="eyebrow">Picked nearby</p>
                    <h2>Fruit worth leaving home for</h2>
                  </div>
                  <span className="section-meta">{filtered.length} listings</span>
                </section>

                <section className="grid" id="market-listings">
                  {filtered.map((item) => {
                    const isFavorite = favoriteListingIds.has(item.id)
                    const isFollowing = followingSellerIds.has(item.sellerId)

                    return (
                      <article className="card premium-card listing-card-v2" key={item.id}>
                        <div className="card-image-wrap">
                          <img src={item.image} alt={item.title} />
                          <span className="card-badge">{item.distance}</span>
                        </div>
                        <div className="card-body">
                          <div className="price-row">
                            <h3>{item.title}</h3>
                            <span>
                              ${item.price}/{item.unit}
                            </span>
                          </div>

                          <div className="listing-badge-row">
                            {item.harvestLabel ? <span className="trust-pill harvest">{item.harvestLabel}</span> : null}
                            {item.freshnessLabel ? <span className="trust-pill freshness">{item.freshnessLabel}</span> : null}
                            {item.availabilityLabel ? <span className="trust-pill available">{item.availabilityLabel}</span> : null}
                          </div>

                          <p className="meta">
                            {prettyLocation(item)} • {item.inventory} left
                          </p>

                          <button className="seller-inline-link" onClick={() => navigate('/grower/' + item.sellerId)}>
                            {item.sellerVerified ? '✓ ' : ''}
                            {sellerLabel(item)}
                          </button>

                          <p className="desc">{item.description}</p>

                          {item.harvestNote ? <div className="harvest-note small">{item.harvestNote}</div> : null}

                          {(item.tags || []).length ? (
                            <div className="pill-row">
                              {item.tags?.map((tag) => (
                                <span className="pill" key={tag}>
                                  {tag}
                                </span>
                              ))}
                            </div>
                          ) : null}

                          <div className="pill-row">
                            {item.pickupWindows.map((slot, index) => (
                              <span className="pill" key={`${item.id}-${slot}-${index}`}>
                                {slot}
                              </span>
                            ))}
                          </div>

                          <ActionGrid columns={2}>
                            <button className="primary fill-btn" onClick={() => handleStartConversation(item)}>
                              Message
                            </button>
                            <button className="ghost fill-btn" onClick={() => navigate('/listing/' + item.id)}>
                              View
                            </button>
                            <button className="ghost fill-btn" onClick={() => handleToggleFavorite(item.id)}>
                              {isFavorite ? 'Saved' : 'Save'}
                            </button>
                            <button className="ghost fill-btn" onClick={() => handleToggleFollow(item.sellerId)}>
                              {isFollowing ? 'Following' : 'Follow'}
                            </button>
                          </ActionGrid>
                        </div>
                      </article>
                    )
                  })}
                </section>

                {socialPosts.length ? (
                  <>
                    <section className="section-heading section-gap-top">
                      <div>
                        <p className="eyebrow">Local signal</p>
                        <h2>From the neighborhood</h2>
                      </div>
                    </section>

                    <section className="social-grid">
                      {socialPosts.slice(0, 3).map((post) => (
                        <article className="social-card" key={post.id}>
                          <div className="social-head">
                            <img className="avatar small" src={post.sellerAvatar} alt={post.sellerName} />
                            <div>
                              <strong>{post.sellerName}</strong>
                              <p>
                                {post.sellerHandle} • {post.location}
                              </p>
                            </div>
                          </div>

                          {post.image ? <img className="social-image" src={post.image} alt={post.title} /> : null}

                          <div className="social-body">
                            <span className="trust-pill social-type">{post.type}</span>
                            <h3>{post.title}</h3>
                            <p>{post.body}</p>
                            <ActionGrid columns={1}>
                              <button className="ghost fill-btn" onClick={() => navigate('/grower/' + post.sellerId)}>
                                View grower
                              </button>
                            </ActionGrid>
                          </div>
                        </article>
                      ))}
                    </section>
                  </>
                ) : null}

                <section className="section-heading section-gap-top">
                  <div>
                    <p className="eyebrow">Fresh activity</p>
                    <h2>Just dropped</h2>
                  </div>
                </section>

                <section className="mini-grid">
                  {(justAdded.length ? justAdded : listings.slice(0, 2)).map((item) => (
                    <div className="activity-card" key={item.id}>
                      <img src={item.image} alt={item.title} />
                      <div>
                        <strong>{item.title}</strong>
                        <p>
                          {prettyLocation(item)} • ${item.price}/{item.unit}
                        </p>
                      </div>
                    </div>
                  ))}
                </section>
              </>
            }
          />

          <Route
            path="/map"
            element={
              <section className="map-panel" id="map-panel">
                <div className="map-fallback premium-map">
                  <div className="map-header-row">
                    <div>
                      <p className="eyebrow">Discovery map</p>
                      <h3>Location-first neighborhood browsing</h3>
                    </div>
                    <button className="ghost" onClick={() => navigate('/store/new')}>
                      Add your harvest
                    </button>
                  </div>

                  <p>
                    This map view is now geo-aware and nationwide-ready. Listings with coordinates render as live pins on a U.S. board.
                  </p>

                  <NationwideGeoMap
                    listings={filtered}
                    onOpenListing={(listingId) => navigate('/listing/' + listingId)}
                  />

                  <div className="pin-list">
                    {filtered.map((item) => (
                      <div className="pin-row premium-pin-row" key={item.id}>
                        <div>
                          <strong>{item.fruit}</strong>
                          <p>
                            {item.title} • {prettyLocation(item)}
                          </p>
                          <div className="listing-badge-row">
                            {item.harvestLabel ? <span className="trust-pill harvest">{item.harvestLabel}</span> : null}
                            {item.sellerVerified ? <span className="trust-pill verified">Verified</span> : null}
                            {hasGeo(item) ? <span className="trust-pill available">Geo-ready</span> : null}
                          </div>
                        </div>
                        <span>
                          ${item.price}/{item.unit}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            }
          />

          <Route
            path="/listing/:id"
            element={
              <ListingDetailRoute
                listings={listings}
                favorites={favorites}
                follows={follows}
                onEdit={(id) => navigate('/store/edit/' + id)}
                onToggleFavorite={handleToggleFavorite}
                onToggleFollow={handleToggleFollow}
                onOpenReserve={setReserveTarget}
                onStartConversation={handleStartConversation}
              />
            }
          />

          <Route
            path="/grower/:id"
            element={
              <GrowerPage
                listings={listings}
                currentSeller={seller}
                follows={follows}
                onToggleFollow={handleToggleFollow}
              />
            }
          />

          <Route
            path="/favorites"
            element={
              <section className="stack" id="store-shell">
                <div className="section-heading compact-heading no-top-gap">
                  <div>
                    <p className="eyebrow">Saved for later</p>
                    <h2>Favorites</h2>
                  </div>
                  <span className="section-meta">{favoriteListings.length} saved</span>
                </div>

                {favoriteListings.length ? (
                  <div className="stack-list">
                    {favoriteListings.map((item) => (
                      <div className="mini-card premium-mini-card" key={item.id}>
                        <img src={item.image} alt={item.title} />
                        <div className="mini-card-copy">
                          <strong>{item.title}</strong>
                          <p>
                            {prettyLocation(item)} • ${item.price}/{item.unit}
                          </p>
                          <span>{item.pickupWindows[0]}</span>
                        </div>
                        <button className="ghost" onClick={() => navigate('/listing/' + item.id)}>
                          View
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="empty-panel">No saved listings yet.</div>
                )}
              </section>
            }
          />

          <Route
            path="/alerts"
            element={
              <AlertsPage
                seller={seller}
                alerts={alerts}
                notifications={notifications}
                onCreateAlert={handleCreateAlert}
                onToggleAlert={handleToggleAlert}
                onReadNotification={handleReadNotification}
              />
            }
          />

          <Route
            path="/messages"
            element={
              <MessagesPage
                conversations={conversations}
                selectedConversationId={selectedConversationId}
                threadMessages={threadMessages}
                seller={seller}
                onSelectConversation={handleSelectConversation}
                onSendMessage={handleSendMessage}
              />
            }
          />

          <Route
            path="/store"
            element={
              <section className="stack">
                <div className="section-heading compact-heading no-top-gap">
                  <div>
                    <p className="eyebrow">Seller dashboard</p>
                    <h2>My Store</h2>
                  </div>
                  <button className="primary" onClick={() => navigate('/store/new')}>
                    New listing
                  </button>
                </div>

                <div className="dashboard-stats">
                  <button className="dashboard-card dashboard-link" onClick={() => navigate('/store/listings')}>
                    <span>Active listings</span>
                    <strong>{myListings.length}</strong>
                  </button>
                  <button className="dashboard-card dashboard-link" onClick={() => navigate('/store/inventory')}>
                    <span>Total inventory</span>
                    <strong>{totalInventory}</strong>
                  </button>
                  <button className="dashboard-card dashboard-link" onClick={() => navigate('/store/analytics')}>
                    <span>Average price</span>
                    <strong>${averagePrice}</strong>
                  </button>
                </div>

                <div className="tool-grid">
                  <button className="tool-card" onClick={() => navigate('/store/new')}>
                    <strong>+ New listing</strong>
                    <span>Create a new product card</span>
                  </button>
                  <button className="tool-card" onClick={() => navigate('/store/listings')}>
                    <strong>Manage listings</strong>
                    <span>View and edit your active items</span>
                  </button>
                  <button className="tool-card" onClick={() => navigate('/store/inventory')}>
                    <strong>Inventory</strong>
                    <span>Adjust stock across listings</span>
                  </button>
                  <button className="tool-card" onClick={() => navigate('/store/analytics')}>
                    <strong>Analytics</strong>
                    <span>See pricing and seller metrics</span>
                  </button>
                </div>

                <GrowerTrust
                  seller={seller}
                  isFollowing={false}
                  onToggleFollow={async () => Promise.resolve()}
                />
              </section>
            }
          />

          <Route
            path="/store/listings"
            element={
              <section className="stack">
                <div className="section-heading compact-heading no-top-gap">
                  <div>
                    <p className="eyebrow">Seller listings</p>
                    <h2>Manage Listings</h2>
                  </div>
                  <button className="primary" onClick={() => navigate('/store/new')}>
                    New listing
                  </button>
                </div>

                {myListings.length ? (
                  <div className="stack-list">
                    {myListings.map((item) => (
                      <div className="listing-row" key={item.id}>
                        <img className="listing-row-image" src={item.image} alt={item.title} />
                        <div className="listing-row-copy">
                          <strong>{item.title}</strong>
                          <p>
                            {prettyLocation(item)} • {item.inventory} left • ${item.price}/{item.unit}
                          </p>
                          <span>{item.pickupWindows[0]}</span>
                          <div className="listing-badge-row">
                            {item.harvestLabel ? <span className="trust-pill harvest">{item.harvestLabel}</span> : null}
                            {item.availabilityLabel ? <span className="trust-pill available">{item.availabilityLabel}</span> : null}
                          </div>
                        </div>
                        <div className="listing-row-actions">
                          <button className="ghost" onClick={() => navigate('/listing/' + item.id)}>
                            View
                          </button>
                          <button className="ghost" onClick={() => navigate('/store/edit/' + item.id)}>
                            Edit
                          </button>
                          <button className="ghost" onClick={() => handleArchive(item.id)}>
                            Archive
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="empty-panel">You do not have any listings yet.</div>
                )}
              </section>
            }
          />

          <Route
            path="/store/inventory"
            element={
              <section className="stack">
                <div className="section-heading compact-heading no-top-gap">
                  <div>
                    <p className="eyebrow">Inventory</p>
                    <h2>Inventory Overview</h2>
                  </div>
                  <button className="ghost" onClick={() => navigate('/store/listings')}>
                    Back to listings
                  </button>
                </div>

                <div className="inventory-table">
                  {myListings.length ? (
                    myListings.map((item) => (
                      <div className="inventory-row" key={item.id}>
                        <span>{item.title}</span>
                        <strong>{item.inventory} in stock</strong>
                      </div>
                    ))
                  ) : (
                    <div className="empty-panel">You do not have inventory yet.</div>
                  )}
                </div>
              </section>
            }
          />

          <Route
            path="/store/analytics"
            element={
              <section className="stack">
                <div className="section-heading compact-heading no-top-gap">
                  <div>
                    <p className="eyebrow">Seller analytics</p>
                    <h2>Performance Snapshot</h2>
                  </div>
                </div>

                <div className="dashboard-stats">
                  <div className="dashboard-card">
                    <span>Active listings</span>
                    <strong>{myListings.length}</strong>
                  </div>
                  <div className="dashboard-card">
                    <span>Total inventory</span>
                    <strong>{totalInventory}</strong>
                  </div>
                  <div className="dashboard-card">
                    <span>Average price</span>
                    <strong>${averagePrice}</strong>
                  </div>
                </div>

                <div className="analytics-note">
                  <strong>Next build target:</strong>
                  <p>Live map pins, editable profiles, and richer pickup coordination flow.</p>
                </div>
              </section>
            }
          />

          <Route
            path="/store/new"
            element={
              <ListingForm
                seller={seller}
                submitLabel="Save listing"
                onSubmitListing={async (payload) => handleCreate(payload)}
              />
            }
          />

          <Route
            path="/store/edit/:id"
            element={
              <EditListingRoute
                listings={listings}
                seller={seller}
                onSubmitListing={async (payload, existingId) => handleUpdate(payload, existingId)}
              />
            }
          />

          <Route
            path="/profile"
            element={
              <section className="profile-card premium-profile">
                <img className="hero-fruit" src={seller.heroFruit} alt="Lead fruit" />
                <div className="profile-row">
                  <img className="avatar" src={seller.avatar} alt={seller.name} />
                  <div>
                    <h2>{seller.name}</h2>
                    <p>
                      {seller.handle} • {[seller.city, seller.state].filter(Boolean).join(', ')}
                    </p>
                  </div>
                </div>

                {!authUser ? (
                  <>
                    <p>Create an account or log in to make this profile live across devices.</p>
                    <div className="action-row">
                      <button className="primary" onClick={() => navigate('/signup')}>
                        Create account
                      </button>
                      <button className="ghost" onClick={() => navigate('/login')}>
                        Log in
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <p>{seller.bio}</p>

                    <div className="dashboard-stats profile-stats">
                      <div className="dashboard-card">
                        <span>Listings</span>
                        <strong>{myListings.length}</strong>
                      </div>
                      <div className="dashboard-card">
                        <span>Favorites</span>
                        <strong>{favoriteListings.length}</strong>
                      </div>
                      <div className="dashboard-card">
                        <span>Messages</span>
                        <strong>{conversations.length}</strong>
                      </div>
                    </div>

                    <div className="trust-metrics">
                      {seller.verified ? <div className="metric-chip">Verified grower</div> : null}
                      {seller.rating ? <div className="metric-chip">★ {seller.rating.toFixed(1)}</div> : null}
                      {seller.followers ? <div className="metric-chip">{seller.followers} followers</div> : null}
                      {seller.responseScore ? <div className="metric-chip">{seller.responseScore}</div> : null}
                      {seller.repeatBuyerScore ? <div className="metric-chip">{seller.repeatBuyerScore}</div> : null}
                    </div>

                    {seller.specialties?.length ? (
                      <div className="pill-row">
                        {seller.specialties.map((item) => (
                          <span className="pill" key={item}>
                            {item}
                          </span>
                        ))}
                      </div>
                    ) : null}

                    <div className="action-row">
                      <button className="ghost" onClick={() => navigate('/store/listings')}>
                        Manage listings
                      </button>
                      <button className="ghost" onClick={() => navigate('/store/new')}>
                        Add new listing
                      </button>
                    </div>
                  </>
                )}
              </section>
            }
          />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <nav className="bottom-nav">
        <NavLink to="/" className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}>
          Home
        </NavLink>
        <NavLink to="/map" className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}>
          Map
        </NavLink>
        <NavLink to="/board" className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}>
          Board
        </NavLink>
        <NavLink to="/messages" className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}>
          Messages
        </NavLink>
        <NavLink to="/store" className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}>
          Store
        </NavLink>
        <NavLink to="/profile" className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}>
          Profile
        </NavLink>
      </nav>

      {reserveTarget ? (
        <ReserveModal
          listing={reserveTarget}
          onClose={() => setReserveTarget(null)}
          onConfirm={async (pickupWindow) => handleConfirmReserve(reserveTarget, pickupWindow)}
        />
      ) : null}
    </div>
  )
}

function EditListingRoute({
  listings,
  seller,
  onSubmitListing,
}: {
  listings: Listing[]
  seller: SellerProfile
  onSubmitListing: (payload: Omit<Listing, 'id'>, existingId?: string) => Promise<void>
}) {
  const { id } = useParams()
  const listing = listings.find((item) => item.id === id)

  if (!listing) {
    return (
      <section className="stack">
        <h2>Listing not found</h2>
        <p>This listing may have been created before persistence was enabled. Create a fresh listing instead.</p>
      </section>
    )
  }

  return (
    <ListingForm
      seller={seller}
      initialValues={listing}
      existingId={listing.id}
      submitLabel="Update listing"
      onSubmitListing={onSubmitListing}
    />
  )
}

function App() {
  const [listings, setListings] = useState<Listing[]>([])
  const [seller, setSeller] = useState<SellerProfile>(fallbackSeller)
  const [favorites, setFavorites] = useState<Favorite[]>([])
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [threadMessages, setThreadMessages] = useState<Message[]>([])
  const [socialPosts, setSocialPosts] = useState<SocialPost[]>([])
  const [notifications, setNotifications] = useState<NotificationItem[]>([])
  const [alerts, setAlerts] = useState<AlertItem[]>([])
  const [follows, setFollows] = useState<Follow[]>([])
  const [authUser, setAuthUser] = useState<AuthUser | null>(null)

  useEffect(() => {
    getListings()
      .then((data) => setListings(data.map(normalizeListing)))
      .catch(() => setListings(fallbackListings))

    getSeller().then(setSeller).catch(() => setSeller(fallbackSeller))
    getFavorites().then(setFavorites).catch(() => setFavorites([]))
    getConversations().then(setConversations).catch(() => setConversations([]))
    getSocialPosts().then(setSocialPosts).catch(() => setSocialPosts([]))
    getNotifications().then(setNotifications).catch(() => setNotifications([]))
    getAlerts().then(setAlerts).catch(() => setAlerts([]))
    getFollows('me').then(setFollows).catch(() => setFollows([]))
  }, [])

  return (
    <AppLayout
      listings={listings}
      setListings={setListings}
      seller={seller}
      favorites={favorites}
      setFavorites={setFavorites}
      conversations={conversations}
      setConversations={setConversations}
      threadMessages={threadMessages}
      setThreadMessages={setThreadMessages}
      socialPosts={socialPosts}
      notifications={notifications}
      setNotifications={setNotifications}
      alerts={alerts}
      setAlerts={setAlerts}
      follows={follows}
      setFollows={setFollows}
      authUser={authUser}
      onAuthSuccess={setAuthUser}
    />
  )
}

export default App